import json, re, time, urllib.request, urllib.parse, ssl, sys
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
M = json.load(open(W + r'\mapping.json', encoding='utf-8'))
bib = json.load(open(W + r'\bib.json', encoding='utf-8'))
R = M['R']
UA = {'User-Agent': 'SLR-reference-check/1.0'}
ctx = ssl.create_default_context()
def get(url):
    for a in range(3):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 404: return {'_err': 404}
            time.sleep(2)
        except Exception as e:
            time.sleep(2)
    return {'_err': 'fail'}
def summ(m):
    return dict(doi=m.get('DOI'), title=(m.get('title') or [''])[0], container=(m.get('container-title') or [''])[0],
                year=(m.get('issued', {}).get('date-parts') or [[None]])[0][0], volume=m.get('volume'), issue=m.get('issue'),
                page=m.get('page') or m.get('article-number'), type=m.get('type'),
                authors=[(a.get('family') or a.get('name') or '') for a in m.get('author', [])][:40],
                published_print=(m.get('published-print', {}).get('date-parts') or [[None]])[0][0],
                published_online=(m.get('published-online', {}).get('date-parts') or [[None]])[0][0],
                subtype=m.get('subtype'), relation=list((m.get('relation') or {}).keys()))
out = {}
try: out = json.load(open(W + r'\crossref.json', encoding='utf-8'))
except Exception: pass
# manuscript refs
items = [('ref' + n, r['doi'], r['title'], r['authors'], r['year']) for n, r in R.items()]
# bib entries for excluded records (not in refs) — check their DOIs too
for b in bib:
    items.append(('bib' + b['key'], (b.get('doi') or '').lower(), b.get('title', ''), b.get('author', ''), b.get('year', '')))
for key, doi, title, auth, year in items:
    if key in out: continue
    rec = {'doi_given': doi}
    if doi:
        d = get('https://api.crossref.org/works/' + urllib.parse.quote(doi, safe='/'))
        if 'message' in d: rec['cr'] = summ(d['message'])
        else: rec['err'] = d.get('_err')
    if 'cr' not in rec:
        q = urllib.parse.quote(re.sub(r'(\w)- (\w)', r'\1\2', title)[:250] + ' ' + auth.split(',')[0][:40])
        d = get('https://api.crossref.org/works?rows=3&query.bibliographic=' + q)
        if 'message' in d:
            rec['search'] = [summ(m) for m in d['message']['items']]
    out[key] = rec
    if len(out) % 20 == 0:
        json.dump(out, open(W + r'\crossref.json', 'w', encoding='utf-8'), ensure_ascii=False)
        print(len(out), flush=True)
    time.sleep(0.25)
json.dump(out, open(W + r'\crossref.json', 'w', encoding='utf-8'), ensure_ascii=False)
print('done', len(out))
