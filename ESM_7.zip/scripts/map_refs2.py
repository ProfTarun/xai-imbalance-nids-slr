import re, json, difflib
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
M = json.load(open(W+r'\mapping.json', encoding='utf-8'))
R = {int(k): v for k, v in M['R'].items()}
T = M['rec_titles']; D = M['rec_dois']
recs = json.load(open(W+r'\recs.json', encoding='utf-8'))
def dehy(s): return re.sub(r'(\w)- (\w)', r'\1\2', s)
STOP = set('a an the of for in on and with using via to by from based its into toward towards'.split())
def toks(s):
    s = re.sub(r'[^a-z0-9 ]', ' ', dehy(s).lower())
    return [w for w in s.split() if w not in STOP]
def sim(a, b):
    ta, tb = toks(a), toks(b)
    if not ta or not tb: return 0
    sa, sb = set(ta), set(tb)
    jac = len(sa & sb) / len(sa | sb)
    cov = len(sa & sb) / min(len(sa), len(sb))
    seq = difflib.SequenceMatcher(None, ' '.join(ta), ' '.join(tb)).ratio()
    return max(seq, 0.5*jac + 0.5*cov)
def surname_hit(ref, rec):
    a = dehy(ref['authors']).split(',')[0].strip().split(' ')[0].lower()
    body = recs[rec]['body'][:4000].lower()
    return 1 if a and len(a) > 2 and a in body else 0
pairs = []
for n, ref in R.items():
    rt = dehy(ref['title'])
    for k in T:
        s = sim(rt, T[k])
        if ref["doi"] and any(ref["doi"]==x.lower() for x in recs[k]["doi_field"]): s += 0.3
        s += 0.15 * surname_hit(ref, k)
        if ref['year'] and ref['year'][:4] in recs[k]['body'][:3000]: s += 0.05
        pairs.append((s, n, k))
pairs.sort(reverse=True)
assign, taken = {}, set()
for s, n, k in pairs:
    if n in assign or k in taken: continue
    assign[n] = (k, round(s, 3)); taken.add(k)
json.dump({str(n): v for n, v in assign.items()}, open(W+r'\assign.json','w'), indent=0)
low = sorted([(v[1], n, v[0]) for n, v in assign.items() if v[1] < 0.9])
print('assigned', len(assign), 'low', len(low))
for s, n, k in low:
    print(f'[{n}] {s:.2f} P{k}: REF="{dehy(R[n]["authors"])[:25]} {R[n]["year"]} {dehy(R[n]["title"])[:70]}" | MD="{T[k][:70]}"')
un = sorted(int(k) for k in T if k not in taken)
print('unassigned md', len(un), un)
for k in un: print(' P%d: %s' % (k, T[str(k)][:110]))
