# Map manuscript reference numbers -> BibTeX entries (Paper IDs) -> extraction records
import json, re, difflib
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
M = json.load(open(W + r'\mapping.json', encoding='utf-8'))
R = {int(k): v for k, v in M['R'].items()}
bib = json.load(open(W + r'\bib.json', encoding='utf-8'))
b2m = json.load(open(W + r'\bib2md.json'))


def dehy(s): return re.sub(r'(\w)- (\w)', r'\1\2', s)
def norm(s): return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', dehy(s).lower().replace('{', '').replace('}', ''))).strip()


pairs = []
for n, r in R.items():
    for b in bib:
        s = difflib.SequenceMatcher(None, norm(r['title']), norm(b.get('title', ''))).ratio()
        if r['doi'] and r['doi'] == (b.get('doi') or '').lower().strip():
            s += 1.0
        pairs.append((s, n, b['key']))
pairs.sort(reverse=True)
ref2bib, taken = {}, set()
for s, n, k in pairs:
    if n in ref2bib or k in taken:
        continue
    ref2bib[n] = (k, round(s, 3)); taken.add(k)
low = [(n, v) for n, v in ref2bib.items() if v[1] < 1.5]
print('refs', len(ref2bib), 'not matched by DOI+title', len(low))
bk = {b['key']: b for b in bib}
for n, (k, s) in sorted(low):
    print(f'  [{n}] {s} {k}: REF="{dehy(R[n]["title"])[:70]}" BIB="{bk[k].get("title","")[:70]}" refdoi={R[n]["doi"]} bibdoi={bk[k].get("doi")}')
notcited = sorted((b['pid'], b['key']) for b in bib if b['key'] not in taken)
print('bib entries not cited in manuscript:', len(notcited))
out = {n: dict(ref=n, bibkey=k, pid=bk[k]['pid'], md=b2m[k][0]) for n, (k, s) in ref2bib.items()}
json.dump(out, open(W + r'\ref2bib.json', 'w'), indent=0)
json.dump(notcited, open(W + r'\notcited.json', 'w'))
for p, k in notcited:
    print('  ', p, k, '|', bk[k].get('title', '')[:90])
