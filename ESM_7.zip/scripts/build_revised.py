# Build the revised study-level evidence dataset (Online Resource 1) from the original manuscript's classification
# plus documented corrections, and compute every statistic used in the revised manuscript.
import json, re, sys
sys.path.insert(0, r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\scripts')
from fields import split_record
import indicators as I
sys.stdout.reconfigure(encoding='utf-8')
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
rows = {r['ref']: r for r in json.load(open(W + r'\audit_rows.json', encoding='utf-8'))}
r2b = {int(k): v for k, v in json.load(open(W + r'\ref2bib.json')).items()}
D = json.load(open(W + r'\ms_data.json'))
T = json.load(open(W + r'\ms_tiers.json'))

# ---------------- corrections (documented in the change log) ----------------
REMOVE_TO_REVIEWS = {77: 'Systematic review of 200 papers (bibliographic and long-form record); short-form summary describes a study cited inside the review'}
REMOVE_EXCLUDED = {51: 'EC3: dataset-generation and benchmark paper (long-form record); short-form summary describes a different study (federated CVAE)'}
FALSE_POSITIVE_LABELS = {43: [('arch', 'GAN-based'), ('mit', 'Generative synthesis')]}  # "X-GANet" is a graph-attention network; no GAN is described
FULLTEXT_EXCLUDED = {31: 'EC2: deep models are 2 of 7 evaluated models', 32: 'EC2: deep models are 2 of 7 evaluated models', 33: 'EC2: deep models are 2 of 7; Xplique applied to the DNN only',
                     56: 'EC2: NGBoost; no deep model central', 105: 'EC2: Random Forest and XGBoost only'}
NOT_RETRIEVED = {1: 'Full text not obtained (publisher web page only); no extraction exists'}
FULLTEXT_INCLUDED = {
    60: dict(arch=['Transformer/attention', 'Autoencoder/VAE'], ds=['ICS/SCADA/power'], mit_tier='N', mit=[], exp_tier='A1', exp=['SHAP', 'Attention'], fmt='long',
             note='Multi-head attention classifier with autoencoder; water-system ICS testbed network flows; SHAP; no imbalance method'),
    82: dict(arch=['Transformer/attention'], ds=['UNSW-NB15'], mit_tier='N', mit=[], exp_tier='A1', exp=['SHAP', 'LIME'], fmt='short', quality=True,
             note='XGBoost and TabNet (1 of 2 models deep); SHAP and LIME compared on ten instances with the Jaccard index; no imbalance method'),
    117: dict(arch=['MLP/DNN/ANN', 'Federated'], ds=['CIC-IDS2017', 'UNSW-NB15', 'Bot-IoT'], mit_tier='M', mit=['Loss/cost-sensitive', 'Federated-specific'], exp_tier='none', exp=[], fmt='short',
              note='Federated deep model with F1-based cost-sensitive loss weights; architecture not stated in the paper'),
    120: dict(arch=['RNN/LSTM/GRU', 'CNN'], ds=['NSL-KDD', 'CSE-CIC-IDS2018'], mit_tier='M', mit=['Random/other resampling'], exp_tier='none', exp=[], fmt='short', train_only=True,
              note='DSSTE resampling on the training split; RF, SVM, XGBoost, LSTM, AlexNet, Mini-VGGNet (3 of 6 deep)'),
    177: dict(arch=['RNN/LSTM/GRU', 'Transformer/attention'], ds=['Other named'], mit_tier='M', mit=['SMOTE family', 'Loss/cost-sensitive'], exp_tier='A2', exp=['Attention'], fmt='both',
              train_only=True, leakage=True, genOnly=True,
              note='Attention-LSTM encoder feeding a gradient-boosting ensemble (deep part encodes features); SMOTE on training split only; focal loss; attention-based explanation'),
    205: dict(arch=['CNN', 'Meta/few-shot/contrastive'], ds=['CIC-IDS2017', 'Edge-IIoTset', 'Other IoT/IIoT'], mit_tier='M', mit=['Few-shot/contrastive', 'Ensemble/boosting'], exp_tier='none', exp=[],
              fmt='both', cross=True, note='Few-shot meta-learning with negative learning and bagging; 1D-CNN, ResNet, Inception backbones; CICIDS-2017, Edge-IIoTset, IoT-23'),
}
U = lambda d: set().union(*d.values())
elig_orig = U(D['arch'])
M_orig = U(D['mit'])
studies = {}
for ref in sorted(elig_orig):
    s = dict(old_ref=ref, bibkey=r2b[ref]['bibkey'], pid=r2b[ref]['pid'], md=r2b[ref]['md'], title=rows[ref]['title'])
    s['arch'] = sorted(k for k, v in D['arch'].items() if ref in v)
    s['ds'] = sorted(k for k, v in D['ds'].items() if ref in v)
    s['mit'] = sorted(k for k, v in D['mit'].items() if ref in v)
    s['exp'] = sorted(k for k, v in D['exp'].items() if ref in v)
    s['mit_tier'] = 'M' if ref in M_orig else 'U' if ref in D['mitU'] else 'W' if ref in D['mitW'] else 'N'
    s['exp_tier'] = 'A1' if ref in T['A1'] else 'A2' if ref in T['A2'] else 'B' if ref in T['B'] else 'U' if ref in D['expU'] else 'none'
    s['dsConflict'] = ref in D['dsConflict']; s['noNumeric'] = ref in D['noNumeric']; s['genOnly'] = ref in D['genOnly']
    s['quality'] = ref in D['expQuality']
    s['minority'] = 'explicit' if ref in D['minorityExplicit'] else 'indirect' if ref in D['minorityIndirect'] else 'none'
    s['fulltext'] = False
    s['corrections'] = []
    studies[ref] = s
for ref, labels in FALSE_POSITIVE_LABELS.items():
    for sec, lab in labels:
        studies[ref][sec].remove(lab)
        studies[ref]['corrections'].append(f'removed false-positive label {sec}:{lab}')
# Explanation-quality evidence missed by the original hand curation; each meets the definition in Section 2.8
QUALITY_ADD = {14: 'SHAP-LIME agreement metric reported', 81: 'fidelity score, Jaccard similarity and explanation stability reported',
               122: 'Grad-CAM cross-layer verification with inconsistency index and spatial-consistency kappa',
               168: 'feature-ranking consistency verified across SHAP, LIME, Morris and permutation importance',
               191: 'explanation-fidelity score measured for post-hoc and intrinsic explainers', 200: 'local and global attribution-consistency validation stated'}
for ref, why in QUALITY_ADD.items():
    studies[ref]['quality'] = True
    studies[ref]['corrections'].append('explanation-quality evidence added in revision audit: ' + why)
removed = {}
for ref, why in list(REMOVE_TO_REVIEWS.items()) + list(REMOVE_EXCLUDED.items()):
    removed[ref] = dict(studies.pop(ref), reason=why)
for ref, c in FULLTEXT_INCLUDED.items():
    s = dict(old_ref=ref, bibkey=r2b[ref]['bibkey'], pid=r2b[ref]['pid'], md=r2b[ref]['md'], title=rows[ref]['title'], arch=sorted(c['arch']), ds=sorted(c['ds']),
             mit=sorted(c['mit']), exp=sorted(c['exp']), mit_tier=c['mit_tier'], exp_tier=c['exp_tier'], dsConflict=False, noNumeric=False, genOnly=c.get('genOnly', False),
             quality=c.get('quality', False), minority='none', fulltext=True, corrections=['eligibility and classification from full-text reading (change-requirements document)'], ft_note=c['note'])
    studies[ref] = s

# ---------------- indicators from extraction text ----------------
def evidence_text(body, fmt='both'):
    f = split_record(body)
    i = body.find('### 1. Bibliographic')
    short, long = (body[:i], body[i:]) if i > 0 else (body, '')
    txt = {'both': body, 'short': short, 'long': long}[fmt]
    for k in ('s_future', 'l_future', 's_limitations', 'l_limitations'):
        if f.get(k):
            for piece in re.split(r'\n', f[k]):
                if piece.strip():
                    txt = txt.replace(piece.strip(), ' ')
    return txt, f


EVAL = {k: I.WORDING[k] for k in ('cross_dataset', 'zero_day', 'leakage', 'train_only_resampling', 'stat_rigor', 'adversarial', 'code', 'edge_testbed')}
EVAL['adversarial'] = r'(?<!generative )adversarial (?:attack|example|robust|perturb|evasion|training|sample|machine learning|manipulation|input|threat|setting|scenario)|evasion attack|poisoning|FGSM|\bPGD\b|DeepFool|Carlini|\bC&W\b|robustness (?:to|against) (?:adversarial|attack)'
EVAL['edge_testbed'] = r'Raspberry|Jetson|edge device|edge deployment|edge hardware|deployed on|FPGA|embedded (?:device|system|board|platform)|microcontroller|on-device|real[- ]time deployment|hardware[- ]in[- ]the[- ]loop|(?:evaluated|tested|validated|deployed) (?:on|in) (?:a |an )?(?:physical |live |real )?testbed|resource-constrained (?:device|hardware)'
EVAL['stat_rigor'] = r'repeated (?:runs|experiments|trials)|(?:multiple|several|independent|\d+) (?:independent |random )?(?:runs|seeds|trials|repetitions)\b|averaged over \d+|confidence interval|standard deviation|\u00b1|t-test|Wilcoxon|statistical(?:ly)? signific|p-value|Friedman|McNemar|ANOVA|\d+-fold|k-fold|cross-validation'
EVAL['code'] = r'github|code (?:is |are )?(?:made )?(?:publicly )?available|open[- ]source(?:d)? (?:code|implementation)|source code (?:is )?(?:publicly )?(?:available|released)|code repository|publicly released code'
for ref, s in studies.items():
    body = recs[s['md']]['body']
    fmt = FULLTEXT_INCLUDED.get(ref, {}).get('fmt', 'both')
    ev, f = evidence_text(body, fmt)
    pre = {'short': 's_', 'long': 'l_', 'both': ''}[fmt]
    pick = lambda name: ' '.join(v for k, v in f.items() if k.endswith(name) and k.startswith(pre or ('s_', 'l_')))
    metrics, findings, limits = pick('metrics'), pick('findings'), pick('limitations')
    ind = {k: bool(re.search(p, ev, re.I)) for k, p in EVAL.items()}
    ind['cost_measured'] = bool(re.search(I.COST_MEASURED, metrics + ' ' + findings, re.I))
    ind['class_sensitive'] = [k for k, p in I.CLASS_SENSITIVE.items() if re.search(p, metrics, re.I)]
    ind['limitations'] = [k for k, p in I.LIMITS.items() if re.search(p, limits, re.I)]
    c = FULLTEXT_INCLUDED.get(ref, {})
    if c.get('train_only'): ind['train_only_resampling'] = True
    if c.get('leakage'): ind['leakage'] = True
    if c.get('cross'): ind['cross_dataset'] = True
    s['ind'] = ind
# Hand-checked indicators: every keyword hit was read in context; hits in future-work, limitation, relevance or
# dataset-provenance statements, and other senses of the word (privacy leakage, ARP poisoning), were rejected.
HAND = {
    'transfer_eval': [85, 136, 145, 173, 205],          # trained on one dataset and tested on another
    'unseen_attack_eval': [42, 72, 87, 91, 111, 133, 145, 180, 187, 203, 208, 209],   # held-out / unseen attack types evaluated
    'eval_leakage': [15, 16, 62, 81, 139, 145, 177],   # train-test (evaluation) leakage discussed or guarded against
    'leak_safe_resampling': [16, 71, 120, 145, 177],    # resampling stated to be training-only or leakage-safe
    'adversarial_eval': [22, 70, 110, 131, 138, 142, 172, 183, 200],
    'hardware_eval': [37, 76, 110],                      # emulated SDN testbed or embedded edge hardware
    'code_release': [20, 62, 170],
}
for ref, s in studies.items():
    for k, L in HAND.items():
        s['ind'][k] = ref in L
json.dump(dict(studies=studies, removed=removed, fulltext_excluded=FULLTEXT_EXCLUDED, not_retrieved=NOT_RETRIEVED), open(W + r'\revised_studies.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('eligible', len(studies), 'removed', list(removed), 'full-text included', [r for r in studies if studies[r]['fulltext']])
