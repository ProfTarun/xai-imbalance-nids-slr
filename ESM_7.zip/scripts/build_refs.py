# Build the final, renumbered reference list (Springer basic style, alphabetical numbering)
import json, re, sys, unicodedata
sys.stdout.reconfigure(encoding='utf-8')
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
M = json.load(open(W + r'\mapping.json', encoding='utf-8'))
R = {int(k): v for k, v in M['R'].items()}
bib = {b['key']: b for b in json.load(open(W + r'\bib.json', encoding='utf-8'))}
r2b = {int(k): v for k, v in json.load(open(W + r'\ref2bib.json')).items()}
CR = json.load(open(W + r'\crossref.json', encoding='utf-8'))


sys.path.insert(0, r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\scripts')
from diacritics import fix_diacritics


def clean(n, s):
    s = fix_diacritics(s.split(' Statements and Declarations')[0].strip())
    s = s.replace('\u00ad', '')
    # repair URLs broken across lines
    s = re.sub(r'https?:\s*//', 'https://', s)
    s = re.sub(r'(https://\S*?)\s+(\S)', lambda m: m.group(1) + m.group(2) if not m.group(1).endswith(('.', ',')) or re.match(r'[0-9a-zA-Z/]', m.group(2)) else m.group(0), s)
    for _ in range(3):
        s = re.sub(r'(https://doi\.org/\S*?)\s+([0-9A-Za-z][^\s]*)', r'\1\2', s) if re.search(r'https://doi\.org/\S*\s+[0-9A-Za-z]', s) and not re.search(r'https://doi\.org/\S+$', s) else s
    # hyphenation from line breaks: check against clean titles
    refs_titles = ' '.join(filter(None, [bib[r2b[n]['bibkey']].get('title', ''), bib[r2b[n]['bibkey']].get('journal', ''), bib[r2b[n]['bibkey']].get('booktitle', ''),
                                          ((CR.get('ref%d' % n) or {}).get('cr') or {}).get('title', ''), ((CR.get('ref%d' % n) or {}).get('cr') or {}).get('container', '')])).lower()

    def fix(m):
        a, b = m.group(1), m.group(2)
        joined, hyph = (a + b).lower(), (a + '-' + b).lower()
        if hyph in refs_titles and joined not in refs_titles:
            return a + '-' + b
        if joined in refs_titles:
            return a + b
        if a[-1].isupper() or a[-1].isdigit() or b[0].isupper():
            return a + '-' + b
        return a + b
    s = re.sub(r'([A-Za-z0-9]+)- ([A-Za-z0-9]+)', fix, s)
    s = re.sub(r'arXiv preprint arXiv:(\d{4})(\d{4,5})', r'arXiv preprint arXiv:\1.\2', s)
    s = re.sub(r', URL https://arxiv\.org/abs/\S+, arXiv:\S+ \[cs\.CR\]', '', s)
    s = re.sub(r'\s+', ' ', s).strip()
    s = re.sub(r'(\d)\u2013\s+(\d)', '\\1\u2013\\2', s)
    if not s.endswith('.') and not re.search(r'https?://\S+$', s):
        s += ''
    return s


CORR = {
    14: [('(2025) DistilXIDS', '(2026) DistilXIDS')],
    31: [('Framework for enhancing network intrusion detection systems', 'XAI-IDS: Toward proposing an explainable artificial intelligence framework for enhancing network intrusion detection systems')],
    47: [('Scientific Reports https://', 'Scientific Reports 16:32031. https://')],
    64: [('Ferdiana R (2020)', 'Amarudin, Ferdiana R, Widyawan (2020)')],
    77: [('https://doi.org/10.58496/MJCS/2025/063', 'https://doi.org/10.58496//MJCS/2025/063')],
    89: [('Archives of Computational Methods in Engineering https://', 'Archives of Computational Methods in Engineering 33(7):10353\u201310381. https://')],
    96: None,  # replaced below
    169: [('Discover Artificial Intelligence https://', 'Discover Artificial Intelligence 6:1258. https://')],
    193: [('Scientific Reports https://', 'Scientific Reports 16:32576. https://')],
    61: [(' https://doi.org/10.64235/ntebwf71', '')],
}
REPLACE = {
    182: 'Subasi O, Cree J, Manzano J, et al (2024) A critical assessment of interpretable and explainable machine learning for intrusion detection. arXiv preprint arXiv:2407.04009. https://doi.org/10.48550/arXiv.2407.04009',
    112: 'Lee GC, Li JH, Li ZY (2023) A Wasserstein generative adversarial network–gradient penalty-based model with imbalanced data enhancement for network intrusion detection. Applied Sciences 13(14):8132. https://doi.org/10.3390/app13148132',
    96: 'Kalakoti R, Vaarandi R, Bah\u015fi H, et al (2025) Evaluating explainable AI for deep learning-based network intrusion detection system alert classification. In: Proceedings of the 11th International Conference on Information Systems Security and Privacy (ICISSP). SciTePress, pp 47\u201358. https://doi.org/10.5220/0013180700003899',
}
BG = {
    'page2021': 'Page MJ, McKenzie JE, Bossuyt PM, et al (2021) The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 372:n71. https://doi.org/10.1136/bmj.n71',
    'campbell2020': 'Campbell M, McKenzie JE, Sowden A, et al (2020) Synthesis without meta-analysis (SWiM) in systematic reviews: reporting guideline. BMJ 368:l6890. https://doi.org/10.1136/bmj.l6890',
    'kitchenham2007':'Kitchenham B, Charters S (2007) Guidelines for performing systematic literature reviews in software engineering. Technical Report EBSE-2007-01, Keele University and Durham University',
    'chawla2002': 'Chawla NV, Bowyer KW, Hall LO, Kegelmeyer WP (2002) SMOTE: synthetic minority over-sampling technique. Journal of Artificial Intelligence Research 16:321\u2013357. https://doi.org/10.1613/jair.953',
    'he2008': 'He H, Bai Y, Garcia EA, Li S (2008) ADASYN: adaptive synthetic sampling approach for imbalanced learning. In: 2008 IEEE International Joint Conference on Neural Networks. IEEE, pp 1322\u20131328. https://doi.org/10.1109/IJCNN.2008.4633969',
    'he2009': 'He H, Garcia EA (2009) Learning from imbalanced data. IEEE Transactions on Knowledge and Data Engineering 21(9):1263\u20131284. https://doi.org/10.1109/TKDE.2008.239',
    'lin2017': 'Lin TY, Goyal P, Girshick R, et al (2017) Focal loss for dense object detection. In: 2017 IEEE International Conference on Computer Vision (ICCV). IEEE, pp 2999\u20133007. https://doi.org/10.1109/ICCV.2017.324',
    'buda2018': 'Buda M, Maki A, Mazurowski MA (2018) A systematic study of the class imbalance problem in convolutional neural networks. Neural Networks 106:249\u2013259. https://doi.org/10.1016/j.neunet.2018.07.011',
    'johnson2019': 'Johnson JM, Khoshgoftaar TM (2019) Survey on deep learning with class imbalance. Journal of Big Data 6:27. https://doi.org/10.1186/s40537-019-0192-5',
    'lundberg2017': 'Lundberg SM, Lee SI (2017) A unified approach to interpreting model predictions. In: Advances in Neural Information Processing Systems 30 (NeurIPS 2017). Curran Associates, pp 4765\u20134774',
    'ribeiro2016': 'Ribeiro MT, Singh S, Guestrin C (2016) \u201cWhy should I trust you?\u201d: explaining the predictions of any classifier. In: Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining. ACM, pp 1135\u20131144. https://doi.org/10.1145/2939672.2939778',
    'selvaraju2017': 'Selvaraju RR, Cogswell M, Das A, et al (2017) Grad-CAM: visual explanations from deep networks via gradient-based localization. In: 2017 IEEE International Conference on Computer Vision (ICCV). IEEE, pp 618\u2013626. https://doi.org/10.1109/ICCV.2017.74',
    'sundararajan2017': 'Sundararajan M, Taly A, Yan Q (2017) Axiomatic attribution for deep networks. In: Proceedings of the 34th International Conference on Machine Learning (ICML), PMLR 70, pp 3319\u20133328',
    'bach2015': 'Bach S, Binder A, Montavon G, et al (2015) On pixel-wise explanations for non-linear classifier decisions by layer-wise relevance propagation. PLOS ONE 10(7):e0130140. https://doi.org/10.1371/journal.pone.0130140',
    'jain2019': 'Jain S, Wallace BC (2019) Attention is not explanation. In: Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies. ACL, pp 3543\u20133556. https://doi.org/10.18653/v1/N19-1357',
    'wiegreffe2019': 'Wiegreffe S, Pinter Y (2019) Attention is not not explanation. In: Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing and the 9th International Joint Conference on Natural Language Processing (EMNLP-IJCNLP). ACL, pp 11\u201320. https://doi.org/10.18653/v1/D19-1002',
    'chicco2020': 'Chicco D, Jurman G (2020) The advantages of the Matthews correlation coefficient (MCC) over F1 score and accuracy in binary classification evaluation. BMC Genomics 21:6. https://doi.org/10.1186/s12864-019-6413-7',
    'saito2015': 'Saito T, Rehmsmeier M (2015) The precision-recall plot is more informative than the ROC plot when evaluating binary classifiers on imbalanced datasets. PLOS ONE 10(3):e0118432. https://doi.org/10.1371/journal.pone.0118432',
    'sommer2010': 'Sommer R, Paxson V (2010) Outside the closed world: on using machine learning for network intrusion detection. In: 2010 IEEE Symposium on Security and Privacy. IEEE, pp 305\u2013316. https://doi.org/10.1109/SP.2010.25',
    'arp2022': 'Arp D, Quiring E, Pendlebury F, et al (2022) Dos and don\u2019ts of machine learning in computer security. In: Proceedings of the 31st USENIX Security Symposium. USENIX Association, pp 3971\u20133988',
    'warnecke2020': 'Warnecke A, Arp D, Wressnegger C, Rieck K (2020) Evaluating explanation methods for deep learning in security. In: 2020 IEEE European Symposium on Security and Privacy (EuroS&P). IEEE, pp 158\u2013174. https://doi.org/10.1109/EuroSP48549.2020.00018',
    'kapoor2023': 'Kapoor S, Narayanan A (2023) Leakage and the reproducibility crisis in machine-learning-based science. Patterns 4(9):100804. https://doi.org/10.1016/j.patter.2023.100804',
    'engelen2021': 'Engelen G, Rimmer V, Joosen W (2021) Troubleshooting an intrusion detection dataset: the CICIDS2017 case study. In: 2021 IEEE Security and Privacy Workshops (SPW). IEEE, pp 7\u201312. https://doi.org/10.1109/SPW53761.2021.00009',
    'tavallaee2009': 'Tavallaee M, Bagheri E, Lu W, Ghorbani AA (2009) A detailed analysis of the KDD CUP 99 data set. In: 2009 IEEE Symposium on Computational Intelligence for Security and Defense Applications. IEEE, pp 1\u20136. https://doi.org/10.1109/CISDA.2009.5356528',
    'mchugh2000': 'McHugh J (2000) Testing intrusion detection systems: a critique of the 1998 and 1999 DARPA intrusion detection system evaluations as performed by Lincoln Laboratory. ACM Transactions on Information and System Security 3(4):262\u2013294. https://doi.org/10.1145/382912.382923',
    'moustafa2015': 'Moustafa N, Slay J (2015) UNSW-NB15: a comprehensive data set for network intrusion detection systems (UNSW-NB15 network data set). In: 2015 Military Communications and Information Systems Conference (MilCIS). IEEE, pp 1\u20136. https://doi.org/10.1109/MilCIS.2015.7348942',
    'sharafaldin2018': 'Sharafaldin I, Habibi Lashkari A, Ghorbani AA (2018) Toward generating a new intrusion detection dataset and intrusion traffic characterization. In: Proceedings of the 4th International Conference on Information Systems Security and Privacy (ICISSP). SciTePress, pp 108\u2013116. https://doi.org/10.5220/0006639801080116',
    'rudin2019': 'Rudin C (2019) Stop explaining black box machine learning models for high stakes decisions and use interpretable models instead. Nature Machine Intelligence 1(5):206\u2013215. https://doi.org/10.1038/s42256-019-0048-x',
    'thakkar2023': 'Thakkar A, Lohiya R (2023) A review on challenges and future research directions for machine learning-based intrusion detection system. Archives of Computational Methods in Engineering 30(7):4245\u20134269. https://doi.org/10.1007/s11831-023-09943-8',
    'geetha2021': 'Geetha R, Thilagam T (2021) A review on the effectiveness of machine learning and deep learning algorithms for cyber security. Archives of Computational Methods in Engineering 28(4):2861\u20132879. https://doi.org/10.1007/s11831-020-09478-2',
    'tama2022': 'Tama BA, Lee SY, Lee S (2022) A systematic mapping study and empirical comparison of data-driven intrusion detection techniques in industrial control networks. Archives of Computational Methods in Engineering 29(7):5353\u20135380. https://doi.org/10.1007/s11831-022-09767-y',
}
DROP = {1}
entries = []
for n in sorted(R):
    if n in DROP:
        continue
    s = REPLACE.get(n) or clean(n, R[n]['raw'])
    for a, b in (CORR.get(n) or []):
        assert a in s, (n, a, s)
        s = s.replace(a, b)
    entries.append(dict(old=n, bg=None, text=s))
for k, s in BG.items():
    entries.append(dict(old=None, bg=k, text=s))


def key(e):
    t = unicodedata.normalize('NFKD', e['text']).encode('ascii', 'ignore').decode().lower()
    t = re.sub(r'[^a-z0-9 ,()]', '', t)
    return t
entries.sort(key=key)
for i, e in enumerate(entries, 1):
    e['new'] = i
json.dump(entries, open(W + r'\refs_final.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('references', len(entries))
oldmap = {e['old']: e['new'] for e in entries if e['old']}
moved = sum(1 for a, b in zip(sorted(oldmap), [oldmap[k] for k in sorted(oldmap)]) if False)
seq = [oldmap[k] for k in sorted(oldmap)]
print('corpus order preserved:', all(x < y for x, y in zip(seq, seq[1:])))
for e in entries[:4] + entries[-3:]:
    print(e['new'], e['old'], e['bg'], e['text'][:150])
# hyphen check
for e in entries:
    if re.search(r'[a-z]- [a-z]', e['text']):
        print('HYPHEN?', e['new'], re.findall(r'\S+- \S+', e['text']))
    if re.search(r'doi\.org/\S*\s', e['text']) and not e['text'].rstrip().endswith(re.findall(r'doi\.org/\S*', e['text'])[0]):
        pass
