# Re-derive the OpenAlex coverage sets (which included DOIs are indexed, and which the documented query finds).
# Same method as the 3 Nov 2026 check (filter=doi:..., then the same filter plus title_and_abstract.search:<query>).
# Re-run in full on 17 Nov 2026 because the work folder of the 3 Nov run (4,447 hits) was lost; OpenAlex has grown since,
# so the hit count and the per-DOI sets are taken from this run and dated accordingly.
import json, sys, time, urllib.parse, urllib.request
sys.stdout.reconfigure(encoding='utf-8')
W = r'C:\Users\tarun\Desktop\MtechPurva\Build_Pipeline\work'
Q = ('("intrusion detection" OR NIDS) AND ("deep learning" OR "neural network" OR CNN OR LSTM OR transformer OR autoencoder) AND '
     '(imbalance OR imbalanced OR "minority class" OR SMOTE OR oversampling OR "focal loss" OR "cost-sensitive" OR explainable OR '
     'explainability OR interpretable OR XAI OR SHAP OR LIME)')
H = {'User-Agent': 'SLR-coverage-check/1.0'}
dois = list(json.load(open(W + r'\included_dois.json')).values())


def get(url):
    for a in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=H), timeout=90) as r:
                return json.load(r)
        except Exception as e:
            print('retry', a, e); time.sleep(3 * (a + 1))
    raise SystemExit('OpenAlex not reachable')


indexed, found = [], []
for i in range(0, len(dois), 40):
    f = 'doi:' + '|'.join(urllib.parse.quote('https://doi.org/' + d, safe='') for d in dois[i:i + 40])
    a = get(f'https://api.openalex.org/works?filter={f}&per-page=50&select=doi')
    indexed += [x['doi'].replace('https://doi.org/', '').lower() for x in a['results'] if x.get('doi')]
    b = get(f'https://api.openalex.org/works?filter={f},title_and_abstract.search:{urllib.parse.quote(Q, safe="")}&per-page=50&select=doi')
    found += [x['doi'].replace('https://doi.org/', '').lower() for x in b['results'] if x.get('doi')]
    time.sleep(0.5)
tot = get('https://api.openalex.org/works?filter=publication_year:2016-2026,title_and_abstract.search:' + urllib.parse.quote(Q, safe='') + '&per-page=1&select=id')
out = dict(query=Q, run_at=time.strftime('%Y-%m-%d %H:%M IST'), hits=tot['meta']['count'], indexed=sorted(set(indexed)), found=sorted(set(found)))
json.dump(out, open(W + r'\openalex_coverage.json', 'w', encoding='utf-8'), indent=0)
print('hits', out['hits'], '| with DOI', len(dois), '| indexed', len(set(indexed) & set(dois)), '| found', len(set(found) & set(dois)))
