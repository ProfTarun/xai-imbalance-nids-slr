# Word renderer for the revised manuscript: citations, native equations, tables, figures, references
import json, re, copy
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement, parse_xml
from lxml import etree
import latex2mathml.converter

W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
XSL = etree.XSLT(etree.parse(r'C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL'))
REFS = json.load(open(W + r'\refs_final.json', encoding='utf-8'))
OLD2NEW = {e['old']: e['new'] for e in REFS if e['old']}
BG2NEW = {e['bg']: e['new'] for e in REFS if e['bg']}
CITED = set()


def compress(nums):
    nums = sorted(set(nums))
    out, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(str(nums[i]) if j == i else (f'{nums[i]}, {nums[j]}' if j == i + 1 else f'{nums[i]}\u2013{nums[j]}'))
        i = j + 1
    return '[' + ', '.join(out) + ']'


def resolve(tok):
    nums = []
    for part in tok.split(','):
        part = part.strip()
        if not part:
            continue
        if part.startswith('bg:'):
            nums.append(BG2NEW[part[3:]])
        else:
            nums.append(OLD2NEW[int(part)])
    CITED.update(nums)
    return compress(nums)


def omml(latex, display=False):
    mml = latex2mathml.converter.convert(latex)
    tree = etree.fromstring(mml.encode('utf-8'))
    om = XSL(tree)
    el = parse_xml(etree.tostring(om.getroot()))
    return el


class Builder:
    def __init__(self):
        self.doc = Document()
        d = self.doc
        sec = d.sections[0]
        sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
        for side in ('left_margin', 'right_margin'):
            setattr(sec, side, Cm(2.5))
        sec.top_margin = sec.bottom_margin = Cm(2.5)
        st = d.styles['Normal']
        st.font.name = 'Times New Roman'; st.font.size = Pt(11)
        st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
        pf = st.paragraph_format
        pf.line_spacing = 1.5; pf.space_after = Pt(6); pf.space_before = Pt(0)
        for lvl, size in ((1, 13), (2, 12), (3, 11)):
            hs = d.styles[f'Heading {lvl}']
            hs.font.name = 'Times New Roman'; hs.font.size = Pt(size); hs.font.bold = True; hs.font.italic = (lvl == 3)
            hs.font.color.rgb = RGBColor(0, 0, 0)
            hs.element.rPr.rFonts.set(qn('w:asciiTheme'), '') if False else None
            rf = hs.element.get_or_add_rPr().get_or_add_rFonts()
            for a in ('w:ascii', 'w:hAnsi', 'w:cs', 'w:eastAsia'):
                rf.set(qn(a), 'Times New Roman')
            for a in ('w:asciiTheme', 'w:hAnsiTheme', 'w:eastAsiaTheme', 'w:cstheme'):
                if rf.get(qn(a)) is not None:
                    del rf.attrib[qn(a)]
            hs.paragraph_format.space_before = Pt(12 if lvl == 1 else 9); hs.paragraph_format.space_after = Pt(6)
            hs.paragraph_format.keep_with_next = True
        self._page_numbers()
        self.eqno = 0
        self.tables = 0
        self.figs = 0

    def _page_numbers(self):
        p = self.doc.sections[0].footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run()
        for t, txt in (('begin', None), (None, 'PAGE'), ('end', None)):
            if t:
                fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), t); r._r.append(fc)
            else:
                it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = txt; r._r.append(it)

    # ---- inline text with markup: [[cites]], $math$, **bold**, *italic*
    def _runs(self, p, text, size=None, color=None):
        pos = 0
        pat = re.compile(r'\[\[(.+?)\]\]|\$(.+?)\$|\*\*(.+?)\*\*|\*(.+?)\*')
        for m in pat.finditer(text):
            if m.start() > pos:
                self._add_run(p, text[pos:m.start()], size=size, color=color)
            if m.group(1) is not None:
                self._add_run(p, resolve(m.group(1)), size=size, color=color)
            elif m.group(2) is not None:
                p._p.append(omml(m.group(2)))
            elif m.group(3) is not None:
                self._add_run(p, m.group(3), bold=True, size=size, color=color)
            else:
                self._add_run(p, m.group(4), italic=True, size=size, color=color)
            pos = m.end()
        if pos < len(text):
            self._add_run(p, text[pos:], size=size, color=color)

    def _add_run(self, p, t, bold=False, italic=False, size=None, color=None):
        r = p.add_run(t)
        r.bold = bold or None; r.italic = italic or None
        if size: r.font.size = Pt(size)
        if color: r.font.color.rgb = RGBColor.from_string(color)
        return r

    def title(self, text):
        p = self.doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        r = p.add_run(text); r.bold = True; r.font.size = Pt(16)
        p.paragraph_format.space_after = Pt(12); p.paragraph_format.line_spacing = 1.15

    def h(self, level, text):
        self.doc.add_heading(text, level=level)

    def p(self, text, align='justify', size=None, indent_first=False, keep=False, space_after=None):
        par = self.doc.add_paragraph()
        par.alignment = {'justify': WD_ALIGN_PARAGRAPH.JUSTIFY, 'left': WD_ALIGN_PARAGRAPH.LEFT, 'center': WD_ALIGN_PARAGRAPH.CENTER}[align]
        if keep: par.paragraph_format.keep_with_next = True
        if space_after is not None: par.paragraph_format.space_after = Pt(space_after)
        self._runs(par, text, size=size)
        return par

    def lead(self, lead, text):
        """Paragraph with a bold run-in heading."""
        return self.p(f'**{lead}** {text}')

    def bullets(self, items, numbered=False):
        for i, it in enumerate(items, 1):
            par = self.doc.add_paragraph()
            par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            par.paragraph_format.left_indent = Cm(0.75); par.paragraph_format.first_line_indent = Cm(-0.5)
            par.paragraph_format.space_after = Pt(3)
            self._runs(par, (f'{i}.\u2002' if numbered else '\u2022\u2002') + it)

    def eq(self, latex):
        """Display equation in a borderless two-cell row: centred equation, right-aligned number."""
        self.eqno += 1
        t = self.doc.add_table(rows=1, cols=2)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        tblPr = t._tbl.tblPr
        b = OxmlElement('w:tblBorders')
        for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
            e = OxmlElement(f'w:{edge}'); e.set(qn('w:val'), 'nil'); b.append(e)
        tblPr.append(b)
        c0, c1 = t.rows[0].cells
        c0.width, c1.width = Cm(14.6), Cm(1.4)
        p0 = c0.paragraphs[0]; p0.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p0.paragraph_format.space_before = Pt(3); p0.paragraph_format.space_after = Pt(3)
        mml = latex2mathml.converter.convert(latex, display='block')
        om = parse_xml(etree.tostring(XSL(etree.fromstring(mml.encode('utf-8'))).getroot()))
        p0._p.append(om)
        p1 = c1.paragraphs[0]; p1.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p1.add_run(f'({self.eqno})')
        c1.vertical_alignment = 1
        c0.vertical_alignment = 1
        return self.eqno

    def caption_table(self, text):
        self.tables += 1
        par = self.doc.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.LEFT
        par.paragraph_format.keep_with_next = True; par.paragraph_format.line_spacing = 1.15; par.paragraph_format.space_before = Pt(8)
        self._add_run(par, f'Table {self.tables}', bold=True, size=9.5)
        self._add_run(par, ' ', size=9.5)
        self._runs(par, text, size=9.5)
        return self.tables

    def table(self, caption, header, rows, widths=None, footnote=None, size=8.5):
        self.caption_table(caption)
        t = self.doc.add_table(rows=1, cols=len(header))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.style = self.doc.styles['Table Grid']
        self._borders(t)
        for i, h in enumerate(header):
            c = t.rows[0].cells[i]; c.text = ''
            par = c.paragraphs[0]; par.paragraph_format.line_spacing = 1.0; par.paragraph_format.space_after = Pt(1)
            self._add_run(par, h, bold=True, size=size)
        self._repeat_header(t.rows[0])
        for row in rows:
            cells = t.add_row().cells
            for i, v in enumerate(row):
                cells[i].text = ''
                par = cells[i].paragraphs[0]; par.paragraph_format.line_spacing = 1.0; par.paragraph_format.space_after = Pt(1)
                par.alignment = WD_ALIGN_PARAGRAPH.LEFT
                self._runs(par, str(v), size=size)
        if widths:
            for row in t.rows:
                for i, w in enumerate(widths):
                    row.cells[i].width = Cm(w)
        if footnote:
            par = self.doc.add_paragraph(); par.paragraph_format.line_spacing = 1.0; par.paragraph_format.space_before = Pt(2)
            self._runs(par, footnote, size=8)
        else:
            self.doc.add_paragraph().paragraph_format.space_after = Pt(2)
        return self.tables

    def _repeat_header(self, row):
        trPr = row._tr.get_or_add_trPr()
        el = OxmlElement('w:tblHeader'); el.set(qn('w:val'), 'true'); trPr.append(el)

    def _borders(self, t):
        tbl = t._tbl
        tblPr = tbl.tblPr
        b = OxmlElement('w:tblBorders')
        for edge, val in (('top', 'single'), ('bottom', 'single'), ('insideH', 'single'), ('left', 'nil'), ('right', 'nil'), ('insideV', 'nil')):
            e = OxmlElement(f'w:{edge}'); e.set(qn('w:val'), val); e.set(qn('w:sz'), '4' if val != 'nil' else '0'); e.set(qn('w:color'), '808080')
            b.append(e)
        tblPr.append(b)

    def figure(self, path, caption, width_cm=16.0):
        self.figs += 1
        par = self.doc.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        par.paragraph_format.keep_with_next = True
        par.add_run().add_picture(path, width=Cm(width_cm))
        cap = self.doc.add_paragraph(); cap.paragraph_format.line_spacing = 1.15
        self._add_run(cap, f'Fig. {self.figs}', bold=True, size=9.5)
        self._add_run(cap, ' ', size=9.5)
        self._runs(cap, caption.rstrip('.'), size=9.5)
        return self.figs

    def page_break(self):
        self.doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    def references(self):
        for e in REFS:
            par = self.doc.add_paragraph()
            pf = par.paragraph_format
            pf.left_indent = Cm(0.9); pf.first_line_indent = Cm(-0.9); pf.line_spacing = 1.15; pf.space_after = Pt(3)
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT
            self._add_run(par, f'[{e["new"]}]\u2002', size=9.5)
            self._add_run(par, e['text'], size=9.5)

    def save(self, path):
        self.doc.save(path)
