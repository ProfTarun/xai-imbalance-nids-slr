# Generate all figures of the revised manuscript from stats_revised.json (evidence-derived) or as conceptual schematics
import json, sys, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
sys.stdout.reconfigure(encoding='utf-8')
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
OUT = sys.argv[1] if len(sys.argv) > 1 else W + r'\figs'
os.makedirs(OUT, exist_ok=True)
st = json.load(open(W + r'\stats_revised.json'))
plt.rcParams.update({'font.family': 'Arial', 'font.size': 8.5, 'axes.edgecolor': '#52514e', 'axes.linewidth': 0.6, 'xtick.color': '#52514e', 'ytick.color': '#0b0b0b',
                     'axes.labelcolor': '#0b0b0b', 'svg.fonttype': 'none'})
BLUE = '#2a78d6'
CAT = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300']
HATCH = ['', '////', '....', 'xxxx', '\\\\\\\\', '++']
INK, INK2, MUTED = '#0b0b0b', '#52514e', '#8a8984'


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + '.png'), dpi=600, bbox_inches='tight', facecolor='white')
    fig.savefig(os.path.join(OUT, name + '.tif'), dpi=600, bbox_inches='tight', facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
    plt.close(fig)


def hbar(ax, labels, values, xlabel, title=None):
    y = range(len(labels))[::-1]
    ax.barh(list(y), values, color=BLUE, height=0.62, edgecolor='white', linewidth=0.8)
    for yi, v in zip(y, values):
        ax.text(v + max(values) * 0.012, yi, str(v), va='center', ha='left', fontsize=8, color=INK)
    ax.set_yticks(list(y)); ax.set_yticklabels(labels)
    ax.set_xlabel(xlabel)
    ax.set_xlim(0, max(values) * 1.15)
    ax.grid(axis='x', color='#e6e5e0', linewidth=0.5); ax.set_axisbelow(True)
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    ax.tick_params(length=0)
    if title: ax.set_title(title, loc='left', fontsize=9, fontweight='bold', color=INK)


def box(ax, x, y, w, h, text, fc='#ffffff', ec=INK2, lw=0.8, fs=7.5, bold=False, ls='-'):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.004,rounding_size=0.008', fc=fc, ec=ec, lw=lw, ls=ls))
    ax.text(x + w / 2, y + h / 2, text, ha='center', va='center', fontsize=fs, color=INK, wrap=True, fontweight='bold' if bold else 'normal', linespacing=1.25)


def arrow(ax, x1, y1, x2, y2, ls='-'):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='-|>', color=INK2, lw=0.8, ls=ls, shrinkA=0, shrinkB=0, mutation_scale=8))


# ---------------- Fig. 1 conceptual pipeline ----------------
fig, ax = plt.subplots(figsize=(6.85, 2.6)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
xs = [0.01, 0.255, 0.50, 0.745]; names = ['Traffic capture\n(packets or flows)', 'Feature extraction\nand preprocessing', 'Deep model\ntraining', 'Alert and\nprediction']
for x, n in zip(xs, names): box(ax, x, 0.62, 0.22, 0.24, n, fc='#f3f2ee')
for a, b in zip(xs[:-1], xs[1:]): arrow(ax, a + 0.22, 0.74, b, 0.74)
box(ax, 0.20, 0.08, 0.33, 0.26, 'Imbalance mitigation\ndata level: resampling, synthesis\nloss level: class weights, focal loss\ndecision level: thresholds', fc='#cde2fb')
box(ax, 0.62, 0.08, 0.36, 0.26, 'Explanation and analyst review\npost hoc: SHAP, LIME, gradients\nin-model: attention, rules', fc='#cde2fb')
arrow(ax, 0.365, 0.34, 0.365, 0.62)
arrow(ax, 0.80, 0.62, 0.80, 0.34)
ax.annotate('', xy=(0.53, 0.18), xytext=(0.62, 0.18), arrowprops=dict(arrowstyle='-|>', color=INK2, lw=0.9, ls='--', mutation_scale=8))
ax.text(0.575, 0.04, 'explanation-guided\nmitigation', ha='center', va='center', fontsize=7, color=INK2, style='italic')
save(fig, 'Fig1')

# ---------------- Fig. 2 PRISMA 2020 flow diagram ----------------
fig, ax = plt.subplots(figsize=(6.85, 8.6)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
L, wl, R_, wr = 0.235, 0.355, 0.62, 0.37
LANE = 0.15
for y0, y1, lab in [(0.865, 0.995, 'Identification'), (0.215, 0.855, 'Screening and eligibility'), (0.005, 0.205, 'Included')]:
    ax.add_patch(Rectangle((0.0, y0), 0.055, y1 - y0, fc='#cde2fb', ec='none'))
    ax.text(0.0275, (y0 + y1) / 2, lab, rotation=90, ha='center', va='center', fontsize=8.5, fontweight='bold', color=INK)


def row(y, h, ltxt, rtxt=None, rh=None, rfs=6.8, rec='#52514e'):
    box(ax, L, y, wl, h, ltxt, fs=7.2)
    if rtxt:
        rh = rh or h
        box(ax, R_, y + h / 2 - rh / 2, wr, rh, rtxt, fs=rfs, ec=rec)
        arrow(ax, L + wl, y + h / 2, R_, y + h / 2)


NL = chr(10)
row(0.885, 0.105, NL.join(['Records identified from keyword searches', '(sources, dates and counts not recorded)', 'Retained after manual pre-screening', 'and numbered (n = 265)']),
    NL.join(['Records removed before screening:', 'discarded in manual pre-screening of', 'search results before numbering', '(n not recorded)', 'duplicate records (n = 11)']), rh=0.105)
row(0.745, 0.075, NL.join(['Records screened on structured', 'extraction and metadata (n = 254)']),
    NL.join(['Records excluded (n = 23)', 'no meaningful deep-learning component: 17', 'not network intrusion detection: 2', 'survey outside the topic: 2',
             'conceptual framework, no evaluation: 1', 'dataset paper: 1', '', 'Existing reviews set aside for', 'comparison (n = 25)']), rh=0.165)
row(0.585, 0.085, NL.join(['Records assessed for eligibility on', 'two extraction formats and metadata', '(n = 206)']),
    NL.join(['Records excluded (n = 6)', 'no deep model proposed or central: 5', 'host-level (system-call) data: 1']), rh=0.07)
row(0.455, 0.07, NL.join(['Reports sought for retrieval', '(eligibility unresolved; n = 12)']), 'Reports not retrieved (n = 1)', rh=0.045)
row(0.335, 0.07, 'Reports assessed in full text (n = 11)', NL.join(['Reports excluded (n = 5)', 'no deep model proposed or central: 5']), rh=0.055)
row(0.225, 0.075, NL.join(['Eligible records audited against the', 'extraction records and bibliography', '(n = 194: 188 + 6)']),
    NL.join(['Removed in the audit (n = 2)', 'systematic review misclassified as a', 'primary study (moved to review corpus): 1', 'dataset and benchmark paper (EC3): 1']), rh=0.085, rec='#eb6834')
box(ax, L, 0.03, wl, 0.15, NL.join(['Primary studies included in the', 'synthesis (n = 192)', 'eligible on extraction-level evidence: 186', 'eligible on full-text reading: 6']), fs=7.4, fc='#f3f2ee')
box(ax, R_, 0.05, wr, 0.11, NL.join(['Existing reviews analysed separately', 'for comparison (n = 26)']), fs=7.2, fc='#f3f2ee')
cx = L + wl / 2
for y_from, y_to in [(0.885, 0.82), (0.745, 0.67), (0.335, 0.30), (0.225, 0.18)]:
    arrow(ax, cx, y_from, cx, y_to)
arrow(ax, cx, 0.585, cx, 0.525); ax.text(cx + 0.008, 0.555, 'unresolved (n = 12)', fontsize=6.6, color=INK2, va='center')
arrow(ax, cx, 0.455, cx, 0.405); ax.text(cx + 0.008, 0.43, 'retrieved (n = 11)', fontsize=6.6, color=INK2, va='center')
ax.text(cx + 0.008, 0.318, 'eligible (n = 6)', fontsize=6.6, color=INK2, va='center')
ax.plot([L, LANE, LANE], [0.60, 0.60, 0.2625], color=INK2, lw=0.8)
arrow(ax, LANE, 0.2625, L, 0.2625)
ax.text(LANE - 0.008, 0.43, 'eligible on extraction-level evidence (n = 188)', rotation=90, fontsize=6.6, color=INK2, ha='right', va='center')
save(fig, 'Fig2')

# ---------------- Fig. 3 evidence status per RQ ----------------
n = st['n']
mt, et = st['mit_tiers'], st['exp_tiers']
rq = [
    ('RQ1 datasets', [(len(st['dsok']), 'Named or described'), (len(st['dsConflict']), 'Formats conflict')]),
    ('RQ2 mitigation', [(mt['M'], 'Explicit (M)'), (mt['U'], 'Formats conflict'), (mt['N'], 'None (N)'), (mt['W'], 'Indirect (W)')]),
    ('RQ3 explanation', [(et['A1'] + et['A2'] + et['B'], 'A1, A2 or B'), (et['U'], 'Formats conflict'), (et['none'], 'None')]),
    ('RQ4 joint', [(len(st['both']), 'Both explicit'), (len(st['cand_one']) + len(st['cand_both']), 'Candidate (conflict)'), (len(st['M_FIonly']) + len(st['M_noexp']), 'Mitigation only'),
                   (len(st['exp_noM']) + len(st['neither']), 'Other')]),
    ('RQ5 results', [(n - len(st['noNumeric']), 'Numeric result'), (len(st['noNumeric']), 'No numeric result')]),
]
fig, ax = plt.subplots(figsize=(6.85, 2.9))
for i, (lab, segs) in enumerate(rq[::-1]):
    left = 0
    for j, (v, name) in enumerate(segs):
        ax.barh(i, v, left=left, color=CAT[j], hatch=HATCH[j], edgecolor='white', linewidth=1.2, height=0.6)
        if v >= 9: ax.text(left + v / 2, i, str(v), ha='center', va='center', fontsize=7.5, color='white' if j in (0, 5) else INK)
        left += v
    ax.text(n + 2, i, '; '.join(f'{name} {v}' for v, name in segs), va='center', fontsize=6.6, color=INK2)
ax.set_yticks(range(len(rq))); ax.set_yticklabels([r[0] for r in rq[::-1]])
ax.set_xlim(0, n); ax.set_xlabel(f'Eligible primary studies (n = {n} per bar)')
for s in ('top', 'right'): ax.spines[s].set_visible(False)
ax.tick_params(length=0)
save(fig, 'Fig3')

# ---------------- Fig. 4 architecture and dataset families ----------------
arch_order = sorted(st['arch'].items(), key=lambda x: -len(x[1]))
ds_show = {k: len(v) for k, v in st['ds'].items() if k not in ('Unnamed',)}
ds_order = sorted(ds_show.items(), key=lambda x: -x[1])
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 3.6), gridspec_kw={'wspace': 0.75})
hbar(a1, [k for k, _ in arch_order], [len(v) for _, v in arch_order], f'Studies (n = {n}; multi-label)', '(a) Architecture families')
hbar(a2, [k for k, _ in ds_order], [v for _, v in ds_order], f'Studies (n = {len(st["dsok"])}; multi-label)', '(b) Dataset families')
save(fig, 'Fig4')

# ---------------- Fig. 5 mitigation ----------------
mit_order = sorted(st['mit'].items(), key=lambda x: -len(x[1]))
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={'width_ratios': [1.6, 1], 'wspace': 0.75})
hbar(a1, [k for k, _ in mit_order], [len(v) for _, v in mit_order], f'Studies (n = {mt["M"]}; multi-label)', '(a) Mitigation families (tier M)')
tiers = [('Explicit (M)', mt['M']), ('Conflict (U)', mt['U']), ('None (N)', mt['N']), ('Indirect (W)', mt['W'])]
hbar(a2, [t for t, _ in tiers], [v for _, v in tiers], f'Studies (n = {n})', '(b) Evidence tier')
save(fig, 'Fig5')

# ---------------- Fig. 6 explanation ----------------
exp_order = sorted(st['exp'].items(), key=lambda x: -len(x[1]))
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={'width_ratios': [1.6, 1], 'wspace': 0.75})
hbar(a1, [k for k, _ in exp_order], [len(v) for _, v in exp_order], f'Studies (n = {len(st["EV"])}; multi-label)', '(a) Explanation families')
tiers = [('A1 established', et['A1']), ('A2 attention', et['A2']), ('B importance only', et['B']), ('Conflict (U)', et['U']), ('None', et['none'])]
hbar(a2, [t for t, _ in tiers], [v for _, v in tiers], f'Studies (n = {n})', '(b) Evidence tier')
save(fig, 'Fig6')

# ---------------- Fig. 7 pairing heatmap ----------------
MIT = ['Loss/cost-sensitive', 'Random/other resampling', 'SMOTE family', 'Generative synthesis', 'Ensemble/boosting', 'Few-shot/contrastive', 'Federated-specific', 'Threshold/calibration']
EXP = ['SHAP', 'LIME', 'Attention', 'Model-derived FI', 'Rules/surrogate/intrinsic', 'Gradient-based', 'Counterfactual/anchors']
EXPL = ['SHAP', 'LIME', 'Attn', 'FI', 'Rule', 'Grad', 'CF']
import numpy as np
M_ = np.array([[len(st['pairs'].get(f'{a}|{b}', [])) for b in EXP] for a in MIT])
fig, ax = plt.subplots(figsize=(5.2, 3.4))
from matplotlib.colors import LinearSegmentedColormap
cmap = LinearSegmentedColormap.from_list('blue', ['#ffffff', '#cde2fb', '#86b6ef', '#3987e5', '#1c5cab', '#0d366b'])
im = ax.imshow(M_, cmap=cmap, vmin=0, vmax=M_.max(), aspect='auto')
for i in range(M_.shape[0]):
    for j in range(M_.shape[1]):
        ax.text(j, i, str(M_[i, j]), ha='center', va='center', fontsize=7.5, color='white' if M_[i, j] > M_.max() * 0.55 else INK)
ax.set_xticks(range(len(EXP))); ax.set_xticklabels(EXPL)
ax.set_yticks(range(len(MIT))); ax.set_yticklabels(MIT)
ax.set_xticks(np.arange(-.5, len(EXP), 1), minor=True); ax.set_yticks(np.arange(-.5, len(MIT), 1), minor=True)
ax.grid(which='minor', color='white', linewidth=1.5); ax.tick_params(which='both', length=0)
for s in ax.spines.values(): s.set_visible(False)
save(fig, 'Fig7')

# ---------------- Fig. 8 indicators ----------------
nM, nb, nA = mt['M'], len(st['both']), len(st['A12'])
items = [
    ('Class-sensitive metric listed (tier M)', len(st['cs_M']), nM),
    ('Class-sensitive metric listed (explicit-both)', len(st['cs_both']), nb),
    ('Explanation-quality evidence (A1 or A2)', len(st['quality_A12']), nA),
    ('Explanation-quality evidence (explicit-both)', len(st['quality_both']), nb),
    ('Minority-class explanation, explicit or indirect (explicit-both)', len(st['minority_explicit']) + len(st['minority_indirect']), nb),
    ('Two or more named dataset families', len(st['multi_named']), len(st['dsok'])),
    ('Train-on-one, test-on-another dataset', len(st['h_transfer_eval']), n),
    ('Held-out unseen-attack evaluation', len(st['h_unseen_attack_eval']), n),
    ('Evaluation leakage discussed', len(st['h_eval_leakage']), n),
    ('Leakage-safe or training-only resampling stated', len(st['h_leak_safe_resampling']), n),
    ('Repeated evaluation or statistical testing', len(st['ind_stat_rigor']), n),
    ('Computational cost measured', len(st['ind_cost_measured']), n),
    ('Hardware or testbed evaluation', len(st['h_hardware_eval']), n),
    ('Adversarial-robustness evaluation', len(st['h_adversarial_eval']), n),
    ('Code released', len(st['h_code_release']), n),
]
fig, ax = plt.subplots(figsize=(6.85, 4.2))
y = list(range(len(items)))[::-1]
vals = [100 * a / b for _, a, b in items]
ax.barh(y, vals, color=BLUE, height=0.6, edgecolor='white')
for yi, (lab, a, b), v in zip(y, items, vals):
    ax.text(v + 1, yi, f'{a}/{b} ({v:.0f}%)', va='center', fontsize=7.5, color=INK)
ax.set_yticks(y); ax.set_yticklabels([i[0] for i in items])
ax.set_xlim(0, 100); ax.set_xlabel('Share of studies in the stated denominator (%)')
ax.grid(axis='x', color='#e6e5e0', linewidth=0.5); ax.set_axisbelow(True)
for s in ('top', 'right'): ax.spines[s].set_visible(False)
ax.tick_params(length=0)
save(fig, 'Fig8')

# ---------------- Fig. 9 proposed framework ----------------
fig, ax = plt.subplots(figsize=(6.85, 3.6)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
box(ax, 0.02, 0.62, 0.30, 0.30, 'Imbalance robustness\nper-class recall, macro-F1,\nMCC, G-mean, PR-AUC;\nsplit before resampling', fc='#f3f2ee')
box(ax, 0.68, 0.62, 0.30, 0.30, 'Explanation quality\nfidelity (deletion/insertion),\nstability, agreement,\nper-class coverage, analyst use', fc='#f3f2ee')
box(ax, 0.02, 0.06, 0.30, 0.30, 'Detection performance\nbinary and multiclass;\ncross-dataset, temporal\nand unseen-attack splits', fc='#f3f2ee')
box(ax, 0.68, 0.06, 0.30, 0.30, 'Deployment requirements\nlatency, memory, explanation\ncost, drift, reproducibility\n(code, seeds, configurations)', fc='#f3f2ee')
box(ax, 0.36, 0.36, 0.28, 0.28, 'Mitigation-explanation\ninteraction\nexplanations before and\nafter mitigation; background\nand reference distributions', fc='#cde2fb', lw=1.6, bold=True)
for (x1, y1, x2, y2) in [(0.32, 0.77, 0.40, 0.64), (0.68, 0.77, 0.60, 0.64), (0.32, 0.21, 0.40, 0.36), (0.68, 0.21, 0.60, 0.36)]:
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='<|-|>', color=INK2, lw=0.8, mutation_scale=8))
ax.annotate('', xy=(0.68, 0.84), xytext=(0.32, 0.84), arrowprops=dict(arrowstyle='<|-|>', color=MUTED, lw=0.7, ls='--', mutation_scale=7))
ax.annotate('', xy=(0.17, 0.62), xytext=(0.17, 0.36), arrowprops=dict(arrowstyle='<|-|>', color=MUTED, lw=0.7, ls='--', mutation_scale=7))
ax.annotate('', xy=(0.83, 0.62), xytext=(0.83, 0.36), arrowprops=dict(arrowstyle='<|-|>', color=MUTED, lw=0.7, ls='--', mutation_scale=7))
save(fig, 'Fig9')

# ---------------- Fig. 10 roadmap ----------------
fig, ax = plt.subplots(figsize=(6.85, 3.9)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
cols = [('Evidence gaps (Section 7)', ['Class-sensitive metrics\nlisted for a minority', 'Explanation quality\nrarely evidenced', 'No study joins quality\nassessment and class-\nsensitive metrics', 'Resampling order and\nleakage rarely stated', 'Legacy benchmarks;\nfew transfer tests']),
        ('Needed practices', ['Report per-class recall,\nmacro-F1, MCC, PR-AUC', 'Test fidelity and\nstability per class', 'Explain before and\nafter mitigation', 'Split, then resample;\nstate it; release code', 'Cross-dataset, temporal\nand unseen-attack splits']),
        ('Research directions (Section 8)', ['Joint benchmarks for\nmitigation and explanation', 'Explanation-guided\nmitigation', 'Class-conditional\nexplanation baselines', 'Lightweight explanation\nwithin latency budgets', 'Validation with\nsecurity analysts'])]
for ci, (head, rows) in enumerate(cols):
    x = 0.02 + ci * 0.34
    ax.text(x + 0.14, 0.96, head, ha='center', va='center', fontsize=8.5, fontweight='bold', color=INK)
    for ri, t in enumerate(rows):
        yb = 0.78 - ri * 0.18
        box(ax, x, yb, 0.28, 0.14, t, fc='#f3f2ee' if ci != 1 else '#cde2fb', fs=7)
        if ci < 2: arrow(ax, x + 0.28, yb + 0.07, x + 0.34, yb + 0.07)
save(fig, 'Fig10')
print('figures written to', OUT)
