# Online Resource 8: completed PRISMA 2020 checklist (item wording paraphrased; Page et al. 2021, CC BY 4.0)
import sys
sys.path.insert(0, r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\scripts')
import render
from ms_common import n

ITEMS = [
    ('Title', '1', 'Identify the report as a systematic review', 'Title', 'Not applicable: reported as a structured review because identification is not reproducible; PRISMA 2020 used as reporting format (Section 2.1)'),
    ('Abstract', '2', 'Structured summary (PRISMA 2020 for Abstracts)', 'Abstract', 'Partly reported: registration and funding are not stated in the abstract (no registration exists; funding is an author action)'),
    ('Introduction', '3', 'Rationale in the context of existing knowledge', 'Sections 1.1, 1.2, 5', 'Reported'),
    ('Introduction', '4', 'Objectives or questions', 'Section 1.3, Table 1', 'Reported'),
    ('Methods', '5', 'Eligibility criteria and grouping for synthesis', 'Section 2.4, Table 3; Sections 2.8\u20132.10', 'Reported'),
    ('Methods', '6', 'Information sources and date last searched', 'Section 2.2; Fig. 2', 'Not reported for identification: sources and dates were not recorded (Section 9.1). A dated post-hoc OpenAlex coverage query (3 November 2026) is reported in Section 2.2 but was not used to identify studies'),
    ('Methods', '7', 'Full search strategies', 'Section 2.2, Table 2', 'Partly reported: keyword families only (Table 2); exact strings were not recorded. The full Boolean string of the post-hoc coverage query is given in Section 2.2'),
    ('Methods', '8', 'Selection process (reviewers, independence, automation tools)', 'Sections 2.5, 2.6, 2.7; final declaration (tools)', 'Reported (single pass by one reviewer, tools declared; no second reviewer)'),
    ('Methods', '9', 'Data collection process', 'Section 2.8; final declaration (tools)', 'Partly reported: provenance of the structured extractions is not recorded'),
    ('Methods', '10a', 'Outcomes for which data were sought', 'Sections 2.8, 2.9', 'Reported (practice-level data items; no effect outcomes)'),
    ('Methods', '10b', 'Other variables for which data were sought', 'Section 2.8; Online Resource 1', 'Reported'),
    ('Methods', '11', 'Risk-of-bias assessment methods', 'Section 2.12', 'Not performed; reason stated'),
    ('Methods', '12', 'Effect measures', 'Section 2.11', 'Not applicable: no effect measures synthesised; counts and proportions reported'),
    ('Methods', '13a', 'Deciding which studies were eligible for each synthesis', 'Sections 2.8, 2.10; denominators in Section 4', 'Reported'),
    ('Methods', '13b', 'Data preparation for synthesis (missing data, conversions)', 'Section 2.10', 'Reported (conflict rules; missing values not imputed)'),
    ('Methods', '13c', 'Tabulation and visual display methods', 'Section 4 (Tables 6\u201318, Figs. 3\u20138)', 'Reported'),
    ('Methods', '13d', 'Synthesis methods and rationale', 'Section 2.11', 'Reported (structured narrative synthesis; SWiM)'),
    ('Methods', '13e', 'Methods to explore heterogeneity', 'Section 2.11', 'Not applicable (no meta-analysis)'),
    ('Methods', '13f', 'Sensitivity analyses', 'Sections 4.3, 4.5', 'Partly reported: bounds under resolution of extraction conflicts'),
    ('Methods', '14', 'Reporting-bias assessment methods', 'Section 9.1', 'Not performed; selection bias of the candidate pool discussed'),
    ('Methods', '15', 'Certainty assessment methods', 'Section 2.12', 'Not performed; reason stated'),
    ('Results', '16a', 'Results of the search and selection, with flow diagram', 'Section 4.1, Fig. 2', 'Reported (identification-stage counts not recorded)'),
    ('Results', '16b', 'Studies that appeared to meet criteria but were excluded, with reasons', 'Sections 2.6, 2.7; Table 4', 'Reported'),
    ('Results', '17', 'Characteristics of included studies', 'Tables 6\u20138; Online Resource 1', 'Reported'),
    ('Results', '18', 'Risk of bias in studies', '\u2013', 'Not performed'),
    ('Results', '19', 'Results of individual studies', 'Online Resource 1; Tables 7\u201315', 'Reported as classifications; effect estimates not tabulated because protocols are not comparable (Section 6.3)'),
    ('Results', '20a', 'Characteristics and risk of bias of studies contributing to each synthesis', 'Scope and denominator blocks of Sections 4.2\u20134.6', 'Partly reported (no risk of bias)'),
    ('Results', '20b', 'Results of all syntheses', 'Sections 4.2\u20134.7', 'Reported'),
    ('Results', '20c', 'Investigations of heterogeneity', '\u2013', 'Not applicable'),
    ('Results', '20d', 'Sensitivity analyses', 'Sections 4.3, 4.5', 'Partly reported (conflict bounds)'),
    ('Results', '21', 'Risk of bias due to missing results', '\u2013', 'Not assessed'),
    ('Results', '22', 'Certainty of evidence', '\u2013', 'Not assessed'),
    ('Discussion', '23a', 'Interpretation in the context of other evidence', 'Sections 5, 6', 'Reported'),
    ('Discussion', '23b', 'Limitations of the evidence', 'Section 9.2', 'Reported'),
    ('Discussion', '23c', 'Limitations of the review processes', 'Section 9.1', 'Reported'),
    ('Discussion', '23d', 'Implications for practice, policy and research', 'Sections 6.4, 7, 8', 'Reported'),
    ('Other information', '24a', 'Registration', 'Section 2.1', 'Not registered (stated)'),
    ('Other information', '24b', 'Protocol access', 'Section 2.1', 'No protocol (stated)'),
    ('Other information', '24c', 'Amendments to registration or protocol', 'Sections 2.6, 2.7, 2.9', 'Changes made during revision are described'),
    ('Other information', '25', 'Support (funding)', 'Statements and Declarations', 'Author action required'),
    ('Other information', '26', 'Competing interests', 'Statements and Declarations', 'Author action required'),
    ('Other information', '27', 'Availability of data, code and other materials', 'Data availability; Online Resources 1\u20137', 'Reported'),
]


def build(path):
    B = render.Builder()
    B.title('Online Resource 8: PRISMA 2020 checklist')
    B.p('**Article:** Explainable Deep Learning and Class-Imbalance Mitigation in Network Intrusion Detection: A Structured Review of Methods, Evaluation Practice and Reporting Gaps. **Journal:** '
        'Archives of Computational Methods in Engineering. **Authors:** Tarun Jangwal, Purva Pathania (Lovely Professional University, '
        'Phagwara, Punjab, India). **Corresponding author:** Tarun Jangwal, tarun.24044@lpu.co.in.', align='left', size=10)
    B.p('Item wording is abbreviated from the PRISMA 2020 checklist (Page MJ, McKenzie JE, Bossuyt PM, et al. The PRISMA 2020 statement. BMJ '
        '2021;372:n71; CC BY 4.0). \u201cLocation\u201d refers to the revised manuscript. Items marked as not reported or not performed are '
        'declared in the manuscript and are not reconstructed.', size=10)
    B.table('PRISMA 2020 checklist for the review', ['Section', 'Item', 'Checklist item (abbreviated)', 'Location in manuscript', 'Status'],
            [list(r[:1]) + [r[1], r[2], r[3], r[4]] for r in ITEMS], widths=[2.4, 1.0, 5.0, 3.6, 4.0], size=8)
    B.save(path)


if __name__ == '__main__':
    build(sys.argv[1])
    print('ok')
