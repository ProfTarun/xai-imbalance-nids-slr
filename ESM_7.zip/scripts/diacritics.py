# Repair spacing-diacritic artefacts produced by PDF text extraction (e.g. "\u00a8O" -> "\u00d6", "C\u00b8" -> "\u00c7")
import re, unicodedata

PREFIX = {'\u00a8': '\u0308', '\u00b4': '\u0301', '\u0060': '\u0300', '\u02c6': '\u0302', '\u02dc': '\u0303', '\u02c7': '\u030c',
          '\u02d8': '\u0306', '\u02d9': '\u0307', '\u02dd': '\u030b', '\u02da': '\u030a'}
SUFFIX = {'\u00b8': '\u0327', '\u02db': '\u0328'}


def fix_diacritics(s):
    s = re.sub('¸([cs])', lambda m: unicodedata.normalize('NFC', m.group(1) + '̧'), s)
    s = re.sub('([' + ''.join(PREFIX) + '])\\s?([A-Za-z\u0131])', lambda m: unicodedata.normalize('NFC', m.group(2).replace('\u0131', 'i') + PREFIX[m.group(1)]), s)
    s = re.sub('([A-Za-z])([' + ''.join(SUFFIX) + '])', lambda m: unicodedata.normalize('NFC', m.group(1) + SUFFIX[m.group(2)]), s)
    return s


if __name__ == '__main__':
    import json, sys
    sys.stdout.reconfigure(encoding='utf-8')
    W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
    E = json.load(open(W + r'\refs_final.json', encoding='utf-8'))
    pat = re.compile('.{0,14}[' + ''.join(PREFIX) + ''.join(SUFFIX) + '].{0,8}')
    for e in E:
        for m in pat.finditer(e['text']):
            print(e['new'], repr(m.group(0)), '->', fix_diacritics(m.group(0)))
