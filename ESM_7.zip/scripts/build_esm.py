# Build Online Resources 1-7 (xlsx/zip) and the record-level audit workbook
import json, re, sys, os, zipfile, shutil
sys.path.insert(0, r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\scripts')
sys.stdout.reconfigure(encoding='utf-8')
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
from ms_common import N, S, n
import c4_back
from fields import split_record

SC = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad'
W = SC + r'\work'
OUT = sys.argv[1]
ESM = os.path.join(OUT, 'Online_Resources'); os.makedirs(ESM, exist_ok=True)
AUD = os.path.join(OUT, 'Audit_Reports'); os.makedirs(AUD, exist_ok=True)
REFS = json.load(open(W + r'\refs_final.json', encoding='utf-8'))
OLD2NEW = {e['old']: e['new'] for e in REFS if e['old']}
bib = json.load(open(W + r'\bib.json', encoding='utf-8'))
r2b = {int(k): v for k, v in json.load(open(W + r'\ref2bib.json')).items()}
key2ref = {v['bibkey']: k for k, v in r2b.items()}
RS = json.load(open(W + r'\revised_studies.json', encoding='utf-8'))
recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
TITLE = 'Explainable Deep Learning and Class-Imbalance Mitigation in Network Intrusion Detection: A Structured Review of Methods, Evaluation Practice and Reporting Gaps'
HEAD = [('Article', TITLE), ('Journal', 'Archives of Computational Methods in Engineering'),
        ('Authors', 'Tarun Jangwal (School of Computing and Artificial Intelligence) and Purva Pathania (School of Computer Science and Engineering), Lovely Professional University, Phagwara, Punjab, India'), ('Corresponding author', 'Tarun Jangwal, School of Computing and Artificial Intelligence, Lovely Professional University, Phagwara, Punjab, India; tarun.24044@lpu.co.in')]


def wb_with(title, caption, header, rows, notes=None):
    wb = Workbook(); ws = wb.active; ws.title = 'About'
    for i, (k, v) in enumerate(HEAD + [('File', title), ('Content', caption)] + ([('Notes', notes)] if notes else []), 1):
        ws.cell(i, 1, k).font = Font(bold=True); ws.cell(i, 2, v).alignment = Alignment(wrap_text=True)
    ws.column_dimensions['A'].width = 22; ws.column_dimensions['B'].width = 120
    d = wb.create_sheet('Data')
    for j, h in enumerate(header, 1):
        c = d.cell(1, j, h); c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='2A78D6'); c.alignment = Alignment(wrap_text=True, vertical='top')
    rid = header.index('Record ID') if 'Record ID' in header else None
    for i, r in enumerate(rows, 2):
        for j, v in enumerate(r, 1):
            d.cell(i, j, f'R{v}' if rid is not None and j - 1 == rid and isinstance(v, int) else v)
    for j, h in enumerate(header, 1):
        d.column_dimensions[get_column_letter(j)].width = min(60, max(10, len(str(h)) + 2))
    d.freeze_panes = 'A2'
    return wb


def first_author(b):
    a = (b.get('author') or '').split(' and ')[0]
    return a.split(',')[0].strip() + ' (' + str(b.get('year', ''))[:4] + ')'


bk = {b['key']: b for b in bib}
# ---- Table 12 group per study
grp = {}
for name, key in [('Explicit-both', 'both'), ('Candidate (one-dimension conflict)', 'cand_one'), ('Candidate (two-dimension conflict)', 'cand_both'),
                  ('Mitigation; feature importance only', 'M_FIonly'), ('Mitigation; no explanation', 'M_noexp'), ('Explanation; no confirmed mitigation', 'exp_noM'), ('Neither', 'neither')]:
    for r in N[key]:
        grp[r] = name
# ---- ESM 1
H1 = ['Reference number', 'Original manuscript reference', 'Record ID', 'BibTeX key', 'First author (year)', 'Title', 'Full-text verified', 'Architecture families',
      'Dataset families', 'Dataset-identity conflict', 'Mitigation tier', 'Mitigation families', 'Explanation tier', 'Explanation families', 'Table 12 group',
      'Explanation-quality evidence', 'Minority-class explanation', 'Class-sensitive metrics listed', 'Transfer between datasets', 'Held-out unseen attacks',
      'Evaluation leakage discussed', 'Leakage-safe resampling stated', 'Repeated evaluation or statistical testing', 'Computational cost measured',
      'Hardware or testbed evaluation', 'Adversarial-robustness evaluation', 'Code released', 'Limitation categories (keyword)', 'No numeric result',
      'Generative or encoding component only', 'Corrections in revision', 'Full-text note']
rows1 = []
yn = lambda b: 'yes' if b else 'no'
for r in sorted(S, key=lambda x: OLD2NEW[x]):
    s = S[r]; b = bk[s['bibkey']]; i = s['ind']
    rows1.append([OLD2NEW[r], r, s['pid'], s['bibkey'], first_author(b), b.get('title', ''), yn(s['fulltext']), '; '.join(s['arch']), '; '.join(s['ds']),
                  yn(s['dsConflict']), s['mit_tier'], '; '.join(s['mit']), s['exp_tier'], '; '.join(s['exp']), grp[r], yn(s['quality']), s['minority'],
                  '; '.join(i['class_sensitive']), yn(i['transfer_eval']), yn(i['unseen_attack_eval']), yn(i['eval_leakage']), yn(i['leak_safe_resampling']),
                  yn(i['stat_rigor']), yn(i['cost_measured']), yn(i['hardware_eval']), yn(i['adversarial_eval']), yn(i['code_release']),
                  '; '.join(i['limitations']), yn(s['noNumeric']), yn(s['genOnly']), ' | '.join(s['corrections']), s.get('ft_note', '')])
wb_with('ESM_1.xlsx', f'Online Resource 1. Evidence dataset of the {n} included primary studies, one row per study.', H1, rows1,
        'Tiers and indicators are defined in Sections 2.8-2.10 of the article. Extraction-level evidence unless full-text verified = yes.').save(os.path.join(ESM, 'ESM_1.xlsx'))
# ---- ESM 2 (254 records)
reviews = [r[0] for r in c4_back.REVIEWS if r[1] is not None]
SURE = {263: 'Survey outside the topic', 264: 'Survey outside the topic', 164: 'Conceptual framework without empirical evaluation', 206: 'Dataset paper',
        259: 'Host-level (system-call) data'}
H2 = ['Record ID', 'BibTeX key', 'First author (year)', 'Title', 'DOI', 'Reference number (if cited)', 'Final status', 'Stage of decision', 'Reason']
rows2 = []
for b in sorted(bib, key=lambda x: x['pid']):
    ref = key2ref.get(b['key']); pid = b['pid']
    if ref in S:
        st, stage, why = 'Included primary study', 'Stage 2' if not S[ref]['fulltext'] else 'Full text', 'Eligible' + (' on full-text reading' if S[ref]['fulltext'] else ' on extraction-level evidence')
    elif ref == 77:
        st, stage, why = 'Existing review (comparison corpus)', 'Revision audit', 'Systematic review misclassified as a primary study; reclassified'
    elif ref in reviews:
        st, stage, why = 'Existing review (comparison corpus)', 'Stage 1', 'Existing review or survey set aside for comparison'
    elif ref == 51:
        st, stage, why = 'Excluded', 'Revision audit', 'EC3: dataset and benchmark paper; short-form extraction misattributed'
    elif str(ref) in RS['fulltext_excluded']:
        st, stage, why = 'Excluded', 'Full text', RS['fulltext_excluded'][str(ref)]
    elif ref == 1:
        st, stage, why = 'Not assessed', 'Full text', 'Full text not obtained; no extraction exists; not cited'
    else:
        st, stage = 'Excluded', 'Stage 1 or Stage 2'
        why = SURE.get(pid, 'No meaningful or central deep model, or not network intrusion detection (original per-record reason not in the supplied files)')
        if pid in (263, 264, 164, 206): stage = 'Stage 1'
        if pid == 259: stage = 'Stage 2'
    rows2.append([pid, b['key'], first_author(b), b.get('title', ''), (b.get('doi') or '').replace('https://doi.org/', ''), OLD2NEW.get(ref, '') if ref and ref != 1 else '', st, stage, why])
from collections import Counter
cnt2 = Counter(r[6] for r in rows2)
wb_with('ESM_2.xlsx', 'Online Resource 2. Screening status of the 254 unique records (11 identifiers unused after duplicate removal: 56, 57, 85, 98, 101, 103, 144, 229, 230, 249, 265).',
        H2, rows2, 'For 24 excluded records the original per-record exclusion reason and stage were not in the files supplied for revision; the totals by reason are '
                   'reported in Section 2.5 of the article. Status counts: ' + '; '.join(f'{k}: {v}' for k, v in cnt2.items())).save(os.path.join(ESM, 'ESM_2.xlsx'))
# ---- ESM 3 (206)
rows3 = [r for r in rows2 if r[6] == 'Included primary study' or r[7] in ('Full text', 'Revision audit') and r[6] != 'Existing review (comparison corpus)' or (r[2] and r[0] in ())]
rows3 = [r for r in rows2 if (r[6] == 'Included primary study') or (r[0] in [S_['pid'] for S_ in []])]
elig_ids = set()
rows3 = []
for r in rows2:
    pid, st, stage = r[0], r[6], r[7]
    if st == 'Included primary study' and stage == 'Stage 2':
        rows3.append(r[:6] + ['Eligible on the available evidence (second step)', 'Included'])
    elif stage == 'Full text' or (st == 'Excluded' and stage == 'Revision audit') or (st == 'Existing review (comparison corpus)' and stage == 'Revision audit') or (st == 'Included primary study' and stage == 'Full text'):
        first = 'Unresolved (second step)' if stage == 'Full text' else 'Eligible on the available evidence (second step)'
        rows3.append(r[:6] + [first, r[6] + ' (' + r[8] + ')'])
    elif pid == 259:
        rows3.append(r[:6] + ['Excluded (second step): host-level data', 'Excluded'])
wb_with('ESM_3.xlsx', 'Online Resource 3. Eligibility-stage status of the records that entered eligibility assessment (206 in total).',
        H2[:6] + ['Second-step outcome', 'Final status'], rows3,
        f'{len(rows3)} of the 206 records are listed. Five further records excluded at the second step because no deep model is proposed or central are among the '
        '24 excluded records in Online Resource 2 whose original stage could not be recovered from the supplied files.').save(os.path.join(ESM, 'ESM_3.xlsx'))
# ---- ESM 4 conflict register
rows4 = []
for flag, lst, meaning in [('Imbalance mitigation: formats conflict', N['mit_tier_lists']['U'], 'Formats disagree on whether a mitigation method exists'),
                           ('Explanation: formats conflict', N['exp_tier_lists']['U'], 'Formats disagree on whether an explanation technique is used'),
                           ('Dataset identity: formats conflict', N['dsConflict'], 'Formats name different dataset families'),
                           ('No numeric performance value', N['noNumeric'], 'No numeric performance value recorded'),
                           ('Generative or encoding component only', N['genOnly'], 'Deep component generates samples or encodes features; classical final classifier')]:
    for r in lst:
        rows4.append([flag, OLD2NEW[r], S[r]['pid'], S[r]['title'], meaning])
wb_with('ESM_4.xlsx', 'Online Resource 4. Register of extraction conflicts and flags.', ['Flag', 'Reference number', 'Record ID', 'Title', 'Meaning'], rows4).save(os.path.join(ESM, 'ESM_4.xlsx'))
# ---- ESM 5 reviews
rows5 = []
cat = ''
for r in c4_back.REVIEWS:
    if r[1] is None:
        cat = r[0]; continue
    rows5.append([OLD2NEW[r[0]], r2b[r[0]]['pid'], first_author(bk[r2b[r[0]]['bibkey']]), bk[r2b[r[0]]['bibkey']].get('title', ''), cat, r[2], r[3], r[4]])
wb_with('ESM_5.xlsx', 'Online Resource 5. The 26 existing reviews and surveys (comparison corpus).',
        ['Reference number', 'Record ID', 'First author (year)', 'Title', 'Group', 'Scope (extraction)', 'Coverage', 'Joint examination'], rows5).save(os.path.join(ESM, 'ESM_5.xlsx'))
# ---- ESM 6 unresolved
FT = {31: 'Excluded (EC2)', 32: 'Excluded (EC2)', 33: 'Excluded (EC2)', 56: 'Excluded (EC2)', 105: 'Excluded (EC2)', 60: 'Included', 82: 'Included', 117: 'Included',
      120: 'Included', 177: 'Included, flagged (deep part encodes features)', 205: 'Included', 1: 'Not assessed: full text not obtained'}
Q = {33: 'Deep models are 2 of 7 evaluated models; a deep-learning explanation toolbox is mentioned', 177: 'Network scope not established (smart-grid dataset)',
     56: 'Formats conflict on whether a deep model is involved', 105: 'Formats conflict on whether a deep model is involved', 82: 'Formats conflict on whether a deep model (TabNet) is involved',
     32: 'Deep models are 2 of 7 evaluated models; role not established', 31: 'Deep models are 2 of 7 evaluated models; role not established', 1: 'No extraction exists',
     60: 'Network scope not established (sensor testbeds versus SCADA)', 117: 'Model class not stated in either format', 205: 'Model class not stated in either format',
     120: 'Formats conflict on whether a deep classifier is involved'}
rows6 = []
for r in [31, 32, 33, 56, 105, 60, 82, 117, 120, 177, 205, 1]:
    note = S[r]['ft_note'] if r in S else RS['fulltext_excluded'].get(str(r), RS['fulltext_excluded'].get(r, 'Full text not obtained'))
    rows6.append([OLD2NEW.get(r, '(not cited)') if r != 1 else '(not cited)', r2b[r]['pid'], bk[r2b[r]['bibkey']].get('title', ''), Q[r], note, FT[r]])
wb_with('ESM_6.xlsx', 'Online Resource 6. The 12 records unresolved at the eligibility step, with the question the extractions could not answer, the full-text finding and the decision.',
        ['Reference number', 'Record ID', 'Title', 'Question the extractions could not answer', 'Full-text finding', 'Decision'], rows6).save(os.path.join(ESM, 'ESM_6.xlsx'))
# ---- indicator comparison (original manuscript vs re-implemented rule on original 188 vs revised 192)
D = json.load(open(W + r'\ms_data.json'))
orig = sorted(set().union(*D['arch'].values()))
import build_revised as BR
def kw_count(pop, key):
    c = 0
    for r in pop:
        body = recs[r2b[r]['md']]['body']
        ev, f = BR.evidence_text(body, 'both')
        if key == 'cost':
            t = ' '.join(v for k, v in f.items() if k.endswith('metrics') or k.endswith('findings'))
            c += bool(re.search(BR.I.COST_MEASURED, t, re.I))
        else:
            c += bool(re.search(BR.EVAL[key], ev, re.I))
    return c
H = BR.HAND
comp = [
    ['Cross-dataset or cross-domain wording (original) / trained on one dataset, tested on another (revised, checked record by record)', '30 of 188', f"{len(set(H['transfer_eval']) & set(orig))} of 188", f"{len(N['h_transfer_eval'])} of {n}"],
    ['Zero-day or unseen-attack wording (original) / held-out unseen attacks evaluated (revised, checked record by record)', '50 of 188', f"{len(set(H['unseen_attack_eval']) & set(orig))} of 188", f"{len(N['h_unseen_attack_eval'])} of {n}"],
    ['Leakage mentioned (original) / evaluation leakage discussed (revised, checked record by record)', '12 of 188', f"{len(set(H['eval_leakage']) & set(orig))} of 188", f"{len(N['h_eval_leakage'])} of {n}"],
    ['Training-only resampling stated (original) / leakage-safe or training-only resampling (revised, checked record by record)', '1 of 188', f"{len(set(H['leak_safe_resampling']) & set(orig))} of 188", f"{len(N['h_leak_safe_resampling'])} of {n}"],
    ['Statistical-rigor wording (keyword; k-fold cross-validation included)', '33 of 188', f"{kw_count(orig, 'stat_rigor')} of 188", f"{len(N['ind_stat_rigor'])} of {n}"],
    ['Computational cost measured (keyword; metrics and findings fields)', '27 of 188', f"{kw_count(orig, 'cost')} of 188", f"{len(N['ind_cost_measured'])} of {n}"],
    ['Edge, testbed or hardware evaluation indicated (original) / hardware or testbed evaluation (revised, checked record by record)', '38 of 188', f"{len(set(H['hardware_eval']) & set(orig))} of 188", f"{len(N['h_hardware_eval'])} of {n}"],
    ['Adversarial-robustness wording (original) / adversarial-robustness evaluation (revised, checked record by record)', '26 of 188', f"{len(set(H['adversarial_eval']) & set(orig))} of 188", f"{len(N['h_adversarial_eval'])} of {n}"],
    ['Code availability indicated (original) / code released (revised, checked record by record)', '5 of 188', f"{len(set(H['code_release']) & set(orig))} of 188", f"{len(N['h_code_release'])} of {n}"],
    ['Class-sensitive metric listed among tier-M studies', '39 of 151', '48 of 151 (both extraction formats scanned)', f"{len(N['cs_M'])} of {N['mit_tiers']['M']}"],
    ['Explanation-quality evidence among A1/A2 studies (curated record by record)', '12 of 77', '18 of 77 (six missed items added)', f"{len(N['quality_A12'])} of {len(N['A12'])}"],
]
os.makedirs(SC + r'\esm7', exist_ok=True)
import csv
with open(SC + r'\esm7\indicator_comparison.csv', 'w', newline='', encoding='utf-8') as fh:
    w_ = csv.writer(fh); w_.writerow(['Indicator', 'Original manuscript value', 'Revised rule applied to original 188 studies', 'Revised value']); w_.writerows(comp)
json.dump(comp, open(W + r'\indicator_comparison.json', 'w'), indent=0)
# ---- ESM 7 zip: scripts + derived inputs
z = zipfile.ZipFile(os.path.join(ESM, 'ESM_7.zip'), 'w', zipfile.ZIP_DEFLATED)
for fn in sorted(os.listdir(SC + r'\scripts')):
    if fn.endswith('.py') and fn not in ('build_reports.py', 'build_author_packs.py'):  # private author documents are not Online Resources
        z.write(os.path.join(SC, 'scripts', fn), 'scripts/' + fn)
for fn in ['bib.json', 'ref2bib.json', 'ms_data.json', 'ms_tiers.json', 'revised_studies.json', 'stats_revised.json', 'refs_final.json', 'ref_audit.json']:
    z.write(os.path.join(W, fn), 'data/' + fn)
z.write(SC + r'\esm7\indicator_comparison.csv', 'indicator_comparison.csv')
z.writestr('README.txt', 'Online Resource 7 for: ' + TITLE + '\nJournal: Archives of Computational Methods in Engineering\nAuthors: Tarun Jangwal (corresponding), Purva Pathania (Lovely Professional University, Phagwara, Punjab, India)\n\n'
           'scripts/ reproduce the classification, statistics, figures and manuscript tables. Run order: parse_bib.py, crossmap.py, ref2bib.py, rebuild_ms_data.py, '
           'build_revised.py, stats.py, figures.py, build_refs.py, build_manuscript.py. The extraction file (Combined_Literature_Analysis.md) is the input of '
           'crossmap.py and is not redistributed here; data/ holds the derived tables.\n'
           'ms_data.json: classification reconstructed from the reference lists printed in the pre-revision manuscript tables.\n'
           'revised_studies.json: the revised study-level dataset (Online Resource 1 in JSON form), including all corrections.\n'
           'indicator_comparison.csv: original indicator values, the revised rules applied to the original 188 studies, and revised values.\n')
z.close()
print('ESM written:', sorted(os.listdir(ESM)))
print('ESM2 status counts', cnt2, 'ESM3 rows', len(rows3))
for c in comp: print(c)
