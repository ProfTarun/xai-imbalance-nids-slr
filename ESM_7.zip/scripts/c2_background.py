# Manuscript part 2: computational background
from ms_common import *


def build(B):
    B.h(1, '3 Computational background')
    B.p("This section fixes the vocabulary and the formal objects used later. The definitions are standard and are attributed to their "
        "original sources; corpus studies are cited only to show where each idea is applied. Section 3.5 adds an analytical argument, derived "
        "for this review, for why mitigation and explanation cannot be evaluated independently.")
    B.h(2, '3.1 Problem formulation and class-sensitive evaluation')
    B.p("Let a detector $f$ map a flow with feature vector $\\mathbf{x}\\in\\mathbb{R}^d$ to one of $K$ classes, and let $n_k$ be the number "
        "of training flows of class $k$ and $\\pi_k=n_k/N$ its prior. The imbalance ratio $\\rho=\\max_k n_k/\\min_k n_k$ is often large in "
        "intrusion data, and it is the multiclass setting, where rare attack types coexist with abundant ones, that makes accuracy misleading. "
        "With per-class recall $R_k$ and precision $P_k$, accuracy is a prior-weighted average of recalls,")
    e1 = B.eq(r'\mathrm{Acc}=\sum_{k=1}^{K}\pi_k R_k ,')
    B.p(f"so a classifier that never predicts a class with $\\pi_k\\approx 0$ loses almost nothing in accuracy. Class-sensitive metrics weight "
        f"classes equally or condition on the positive class [[bg:he2009,bg:saito2015]]. The macro-averaged F1 score and the geometric mean of "
        f"recalls are")
    B.eq(r'F_1^{\mathrm{macro}}=\frac{1}{K}\sum_{k=1}^{K}\frac{2P_kR_k}{P_k+R_k},\qquad \mathrm{G\text{-}mean}=\left(\prod_{k=1}^{K}R_k\right)^{1/K}.')
    B.p("The Matthews correlation coefficient (MCC) uses all four cells of the confusion matrix and remains informative under imbalance "
        "[[bg:chicco2020]]; for the binary case,")
    B.eq(r'\mathrm{MCC}=\frac{TP\cdot TN-FP\cdot FN}{\sqrt{(TP+FP)(TP+FN)(TN+FP)(TN+FN)}}.')
    B.p("The area under the precision–recall curve has a baseline equal to the positive-class prevalence, whereas the area under the "
        "receiver operating characteristic curve (ROC-AUC) does not, which is why the former reacts more strongly to minority-class errors "
        "[[bg:saito2015]]. Which of these a study reports is itself an evidence item in Section 4.3.")
    B.h(2, '3.2 Imbalance mitigation as an intervention on the learning problem')
    B.p("A deep detector is trained by minimising an empirical risk. Writing the risk as a sum over classes shows why imbalance matters:")
    B.eq(r'\hat{\mathcal{R}}(f)=\frac{1}{N}\sum_{i=1}^{N}\ell\big(f(\mathbf{x}_i),y_i\big)=\sum_{k=1}^{K}\pi_k\,\hat{\mathcal{R}}_k(f),')
    B.p("where $\\hat{\\mathcal{R}}_k$ is the mean loss on class $k$. The gradient is dominated by the majority classes, and minority classes "
        "contribute in proportion to $\\pi_k$ [[bg:buda2018,bg:johnson2019]]. Mitigation methods change one of the three objects in this "
        "expression: the empirical distribution, the loss, or the rule that turns scores into labels.")
    B.p("**Data level.** Resampling and synthesis change the empirical distribution. SMOTE creates a synthetic minority sample by interpolation "
        "between a minority sample $\\mathbf{x}_i$ and one of its $k$ nearest minority neighbours $\\mathbf{x}_{nn}$ [[bg:chawla2002]],")
    B.eq(r'\mathbf{x}_{\mathrm{new}}=\mathbf{x}_i+\lambda\,(\mathbf{x}_{nn}-\mathbf{x}_i),\qquad \lambda\sim U(0,1),')
    B.p(f"as applied for example in {ex(N['mit']['SMOTE family'])}; ADASYN weights the number of synthetic samples by local difficulty "
        f"[[bg:he2008]]; random or informed resampling {ex(N['mit']['Random/other resampling'])} and generative synthesis with GAN, VAE or "
        f"diffusion models {ex(N['mit']['Generative synthesis'])} change the class proportions in other ways. The neighbour search makes "
        "SMOTE-type methods cost $O(n_{\\min}^2 d)$ in a naive implementation, and generative synthesis adds the training of a second deep "
        "model. Two assumptions follow. Interpolation assumes that the segment between two minority flows contains valid minority flows, which "
        "need not hold for discrete or protocol-constrained features; and any data-level step that sees test-set neighbours before the "
        "train–test split leaks information into training and inflates minority-class results [[bg:kapoor2023,bg:arp2022]].")
    B.p("**Loss level.** Class-weighted cross-entropy and the focal loss [[bg:lin2017]], with predicted probability $p_t$ of the true class, "
        "class weight $w_t$ and focusing parameter $\\gamma\\ge 0$, are")
    B.eq(r'\mathcal{L}_{\mathrm{CW}}=-w_t\log p_t,\qquad \mathcal{L}_{\mathrm{focal}}=-w_t(1-p_t)^{\gamma}\log p_t ,')
    B.p(f"both used widely in the corpus {ex(N['mit']['Loss/cost-sensitive'])}. With $w_t\\propto 1/\\pi_t$ the weighted risk equals the "
        "risk under a balanced class distribution, so class weighting and balanced resampling target the same population risk; they differ in "
        "variance (weighting scales gradients, resampling repeats or synthesises samples) and in cost (weighting adds no samples). The focal "
        "term down-weights well-classified examples irrespective of class and adds negligible computation.")
    B.p(f"**Decision level and other formulations.** Threshold or calibration methods {ex(N['mit']['Threshold/calibration'])} change how "
        "scores become labels. Under a change of class priors from $\\pi_k$ (training) to $\\pi'_k$ (deployment), Bayes' rule gives the "
        "corrected posterior")
    B.eq(r"p'(k\mid\mathbf{x})=\frac{(\pi'_k/\pi_k)\,p(k\mid\mathbf{x})}{\sum_{j=1}^{K}(\pi'_j/\pi_j)\,p(j\mid\mathbf{x})},")
    B.p(f"which shows that a detector trained on rebalanced data is calibrated to the rebalanced priors and not to operational traffic unless "
        f"the scores are corrected. Ensembles {ex(N['mit']['Ensemble/boosting'])}, few-shot or contrastive formulations "
        f"{ex(N['mit']['Few-shot/contrastive'])} and federated rebalancing {ex(N['mit']['Federated-specific'])} complete the families.")
    B.h(2, '3.3 Explanation techniques')
    B.p("An explanation technique is post hoc when it is applied to a trained model and intrinsic when the model is interpretable by design "
        "[[bg:rudin2019]]. It is local when it explains one prediction and global when it summarises the model. SHAP assigns to each feature "
        "$j$ a Shapley value $\\phi_j$ so that a prediction decomposes additively around a base value $\\phi_0$ [[bg:lundberg2017]]:")
    B.eq(r'f(\mathbf{x})=\phi_0+\sum_{j=1}^{d}\phi_j(\mathbf{x}),\qquad \phi_j=\sum_{S\subseteq F\setminus\{j\}}\frac{|S|!\,(d-|S|-1)!}{d!}\big[v(S\cup\{j\})-v(S)\big].')
    B.p("The value function $v(S)$ is the expected model output when only the features in $S$ are known. Model-agnostic estimators approximate "
        "it with a background set $\\mathcal{D}_b$,")
    B.eq(r'v(S)\approx\frac{1}{|\mathcal{D}_b|}\sum_{\mathbf{z}\in\mathcal{D}_b} f(\mathbf{x}_S,\mathbf{z}_{\bar{S}}),\qquad \phi_0=\frac{1}{|\mathcal{D}_b|}\sum_{\mathbf{z}\in\mathcal{D}_b}f(\mathbf{z}),')
    B.p(f"so the attributions depend on the choice of $\\mathcal{{D}}_b$, and Kernel SHAP needs a number of model evaluations proportional to "
        f"the number of coalition samples times $|\\mathcal{{D}}_b|$; tree-specific and deep-network variants trade generality for speed. SHAP "
        f"is used in {ex(N['exp']['SHAP'])}. LIME fits an interpretable surrogate $g$ around one instance by minimising "
        f"$\\mathcal{{L}}(f,g,\\pi_{{\\mathbf{{x}}}})+\\Omega(g)$, with $\\pi_{{\\mathbf{{x}}}}$ a proximity kernel and $\\Omega$ a complexity "
        f"penalty [[bg:ribeiro2016]]; its explanations depend on the sampling of perturbations and can vary between runs. It is used in "
        f"{ex(N['exp']['LIME'])}. Gradient-based methods compute attributions from derivatives of the output; integrated gradients integrate "
        f"them along a path from a baseline $\\mathbf{{x}}'$ [[bg:sundararajan2017]],")
    B.eq(r"\mathrm{IG}_j(\mathbf{x})=(x_j-x'_j)\int_{0}^{1}\frac{\partial f\big(\mathbf{x}'+\alpha(\mathbf{x}-\mathbf{x}')\big)}{\partial x_j}\,d\alpha ,")
    B.p(f"and Grad-CAM [[bg:selvaraju2017]] and layer-wise relevance propagation [[bg:bach2015]] are related techniques; they appear in "
        f"{ex(N['exp']['Gradient-based'])}. Counterfactual or anchor explanations {C(N['exp']['Counterfactual/anchors'])}, rules or surrogate "
        f"trees {ex(N['exp']['Rules/surrogate/intrinsic'])} and model-derived importance scores {ex(N['exp']['Model-derived FI'])} complete the "
        f"families.")
    B.p(f"Attention weights {ex(N['exp']['Attention'])} need separate treatment. They are produced by the model as part of its computation, "
        "which makes them cheap, but a high weight does not by itself show that the attended input drives the output; whether attention can "
        "serve as explanation depends on the model and on how the claim is tested [[bg:jain2019,bg:wiegreffe2019]]. This review therefore "
        "keeps attention-based explanation in its own tier (A2) and does not treat the presence of an attention layer as evidence of "
        "explainability.")
    B.h(2, '3.4 Evaluating explanations')
    B.p("Explanation techniques can be unstable under small input changes, can disagree with each other and are costly for some model classes "
        "[[bg:warnecke2020]]. Three families of tests recur. Fidelity asks whether the explanation reflects the model's behaviour; a deletion "
        "test removes or masks the top-$m$ features $T_m(\\mathbf{x})$ ranked by the explanation and measures the drop in the score of the "
        "predicted class $y$,")
    B.eq(r'\Delta_m(\mathbf{x})=f_y(\mathbf{x})-f_y\big(\mathbf{x}_{\setminus T_m(\mathbf{x})}\big),')
    B.p("with a larger drop indicating a more faithful ranking. Stability asks whether explanations of similar inputs, or of the same input "
        "under different random seeds or background sets, agree; a common measure is the Jaccard overlap of top-$m$ sets,")
    B.eq(r"J_m(\mathbf{x},\mathbf{x}')=\frac{|T_m(\mathbf{x})\cap T_m(\mathbf{x}')|}{|T_m(\mathbf{x})\cup T_m(\mathbf{x}')|}.")
    B.p("Agreement asks whether different techniques rank features similarly, and usefulness asks whether explanations help an analyst; the "
        "last requires a human study. None of these tests is implied by the predictive accuracy of the explained model.")
    B.h(2, '3.5 Why mitigation and explanation interact')
    B.p("The following argument is analytical; it follows from the definitions above and is not a finding of the corpus. It motivates the "
        "evidence items examined in Section 4.5.")
    B.p("**(a) The explained function changes.** Mitigation changes the minimiser of the training risk, so attributions computed after "
        "mitigation describe a different function from the one that would be trained on raw traffic. A comparison of explanations before and "
        "after mitigation is the only way to tell whether a mitigation step changed which features a model relies on.")
    B.p("**(b) The reference distribution changes.** For SHAP-type explainers, $\\phi_0$ and every $\\phi_j$ depend on the background set. If "
        "$\\mathcal{D}_b$ is drawn from resampled or synthetic training data, explanations are computed relative to a population that does not "
        "occur in operation; if it is drawn from raw traffic, it is dominated by benign flows and minority-class behaviour is rarely the "
        "reference.")
    B.p("**(c) Global summaries are prevalence-weighted.** A global importance computed over a sample with class proportions $\\pi_c$ "
        "decomposes as")
    B.eq(r'\bar{\Phi}_j=\sum_{c=1}^{K}\pi_c\,\bar{\Phi}_{j,c},\qquad \bar{\Phi}_{j,c}=\frac{1}{|\mathcal{D}_c|}\sum_{\mathbf{x}\in\mathcal{D}_c}\big|\phi_j(\mathbf{x})\big|,')
    B.p("so a pooled summary plot ranks the features that explain the majority classes, and the features behind a rare attack can be invisible "
        "unless explanations are reported per class.")
    B.p("**(d) Synthetic regions are explained too.** Explanations computed on synthetic minority samples describe the model in regions "
        "populated by the generator, which may lie off the data manifold of real attacks; explanation quality on synthetic and on real minority "
        "samples need not coincide.")
    B.p("Three corpus studies report observations consistent with (b) and (c): imbalanced background sets in Kernel SHAP skew Shapley values "
        "towards majority-class features [[182]], equalised class distributions stabilise SHAP estimates [[201]], and explanations for highly "
        "imbalanced classes are less stable under adversarial perturbation [[142]]. These are reports of individual studies under their own "
        "protocols, not tested regularities.")
    B.h(2, '3.6 Benchmark datasets')
    B.p("Studies draw on public benchmark families, on newer IoT and industrial sets, and on custom or simulated traffic. The benchmark families "
        "differ in age, attack taxonomy, feature construction and class distribution, so a result on one family does not transfer automatically "
        "to another. KDD Cup 99 and its derivative NSL-KDD descend from traffic generated in the late 1990s, and their limitations, including "
        "redundant records and an unrealistic traffic mix, are documented [[bg:mchugh2000,bg:tavallaee2009]]. UNSW-NB15 [[bg:moustafa2015]] and "
        "CIC-IDS2017 [[bg:sharafaldin2018]] are newer, but labelling and feature-extraction problems have been reported for the latter "
        "[[bg:engelen2021,103]]. More generally, intrusion detection differs from closed-world classification because the classes met in "
        "operation are not fixed in advance [[bg:sommer2010]]. Section 4.2 lists the families named in the corpus and Section 4.6 reports how "
        "often transfer between datasets is evaluated.")
