# Manuscript part 4: comparison with reviews, discussion, gaps, directions, limitations, conclusions, declarations
from ms_common import *

REVIEWS = [
    ('Broad NIDS and DL reviews (16)', None, None, None),
    (64, 2020, 'SLR of intrusion-detection research trends and datasets (62 studies, 2016–2020)', 'DL: ML-focused; imbalance: brief (prevalence in datasets); XAI: none', 'No'),
    (11, 2021, 'Systematic study of ML and DL NIDS across environments', 'DL: yes (ML and DL); imbalance: brief (resampling, cost-sensitive listed); XAI: brief (early post-hoc)', 'Not evidenced'),
    (36, 2021, 'Systematic review of NIDS across cloud, IoT and edge (ML, DL, swarm)', 'DL: yes; imbalance: brief; XAI: none', 'No'),
    (49, 2021, 'Survey of data-driven NIDS', 'DL: yes (ML and DL); imbalance: brief; XAI: brief (early SHAP, LIME, rules)', 'No'),
    (150, 2021, 'SLR and taxonomy of DL-based NIDS', 'DL: yes; imbalance: brief; XAI: brief (named as a challenge)', 'No'),
    (3, 2022, 'Survey of data-driven learning for NIDS, including generative augmentation', 'DL: yes; imbalance: moderate (GAN, SMOTE and ADASYN with random forest compared); XAI: brief', 'No'),
    (211, 2022, 'PRISMA SLR of anomaly-based NIDS methods and datasets (119 papers, 52 datasets)', 'DL: partial; imbalance: brief; XAI: brief (emergent XAI)', 'No'),
    (4, 2023, 'PRISMA SLR of NIDS, 2014–2022 (71 primary studies)', 'DL: yes; imbalance: brief; XAI: brief (interpretability gaps)', 'No'),
    (129, 2024, 'Meta-analysis and systematic review of anomaly NIDS (quantitative)', 'DL: partial; imbalance: moderate (resampling and cost-sensitive compared through confusion matrices); XAI: brief', 'No'),
    (162, 2024, 'SLR of swarm-intelligence-based intrusion detection (this journal)', 'DL: no (metaheuristics); imbalance: not extracted; XAI: none', 'No'),
    (29, 2025, 'Survey of DL in NIDS, 2020–2025 (31 studies, four-category taxonomy)', 'DL: yes; imbalance: brief (GAN, focal loss); XAI: brief (attention visualisation, post-hoc)', 'Not evidenced'),
    (157, 2025, 'Review of IoT intrusion detection with ML and DL', 'DL: yes (ML and DL); imbalance: not extracted (class-imbalance bias noted among limitations); XAI: brief to moderate (LIME, counterfactual, SHAP)', 'No'),
    (197, 2025, 'Review of adversarial challenges in AI-based cloud intrusion detection', 'DL: yes; imbalance: brief; XAI: brief', 'No'),
    (77, 2025, 'Systematic review of 200 papers (2023–2024) on AI-powered zero-day mitigation in IIoT (reclassified during revision)', 'DL: yes (DL and deep reinforcement learning); imbalance: brief (SMOTE, GAN oversampling, cost-sensitive learning and focal loss surveyed); XAI: brief (SHAP, LIME, rule extraction surveyed)', 'Not evidenced'),
    (12, 2026, 'PRISMA SLR of 125 papers, 2022–2025 (five-theme taxonomy)', 'DL: yes; imbalance: moderate (SMOTE, ADASYN, DSSTE, class-weighted loss); XAI: quantified scarcity (about 2% of studies)', 'Not evidenced; reports XAI scarcity'),
    (106, 2026, 'Literature review of DL intrusion detection (CNN, LSTM, autoencoder, transformer); Zenodo deposit', 'DL: yes; imbalance: brief; XAI: brief', 'No'),
    ('Imbalance-centred reviews (3)', None, None, None),
    (188, 2023, 'Review of neural networks for rare-intrusion detection in wireless networks', 'DL: yes (CNN, autoencoder, GAN); imbalance: dedicated; XAI: brief (comparative summary)', 'Not evidenced'),
    (18, 2024, 'Review of imbalance handling in NIDS (data-level, algorithm-level and hybrid taxonomy)', 'DL: partial (focal loss, GAN); imbalance: dedicated; XAI: brief (interpretability requirements)', 'Not evidenced'),
    (207, 2026, 'Survey of deep-reinforcement-learning NIDS (imbalanced data in scope)', 'DL: yes (deep reinforcement learning); imbalance: dedicated (reward shaping, SMOTE with RL); XAI: minimal (policy reward trace)', 'No'),
    ('Explanation-centred reviews (4)', None, None, None),
    (9, 2025, 'Survey of language models, GNNs and XAI for next-generation NIDS', 'DL: yes (transformers, GNN); imbalance: brief (focal loss, augmentation, contrastive); XAI: moderate to dedicated (SHAP, LIME, knowledge graphs, attention)', 'Not evidenced'),
    (26, 2025, 'Review of lightweight XAI for cybersecurity; XAI as an attack surface', 'DL: partial (autoencoder, LSTM); imbalance: minimal (cost-sensitive reconstruction weighting); XAI: dedicated', 'No'),
    (164, 2025, 'Survey and framework analysis of DL and XAI in network security', 'DL: yes; imbalance: brief; XAI: moderate (SHAP, LIME, Grad-CAM, attention)', 'Not evidenced'),
    (89, 2026, 'Systematic review of XAI in IoT and wireless-sensor-network security (this journal; six research questions)', 'DL: yes, with ML; imbalance: not extracted; XAI: dedicated', 'Not evidenced; closest review in this journal'),
    ('Reviews covering both topics inside a wider frame (2)', None, None, None),
    (128, 2025, 'Review of XAI-enabled NIDS across general, IoT, medical, industrial-control and automotive settings', 'DL: partial (CNN, LSTM, transformer; gradient boosting); imbalance: moderate (cost-sensitive, SMOTE, generative oversampling within XAI NIDS); XAI: dedicated (SHAP, LIME, RuleFit, counterfactuals, shapelets)', 'Partial: both reviewed together; depth of joint analysis unverified'),
    (69, 2026, 'Structured evidence synthesis of trustworthy DL for cybersecurity (five-axis framework; 115 cited studies)', 'DL: yes; imbalance: moderate (imbalance metrics, generative augmentation, focal loss); XAI: dedicated (fidelity, stability, human validation)', 'Partial: both appear within the framework; joint synthesis unverified'),
    ('Dataset-focused review (1)', None, None, None),
    (103, 2024, 'Survey and comparative analysis of the CIC-IDS2017 benchmark (data quality, class imbalance, duplicate flows, zero-day limitations)', 'DL: partial (CNN and RNN among reviewed methods); imbalance: moderate (dataset-level analysis; GAN and SMOTE augmentation); XAI: none', 'No'),
]


def build(B):
    # ------------------------------------------------------------------ 5
    B.h(1, '5 Comparison with existing reviews')
    B.p("The 26 existing reviews and surveys (Table 19; Online Resource 5) form a separate comparison corpus and are not counted among the "
        f"{n} primary studies. Their scope and coverage come from their structured extractions and have not been checked against the review "
        "texts, so statements about depth are indicative. Five patterns emerge.")
    B.p("**Broad NIDS and DL reviews** [[3,4,11,12,29,36,49,64,77,106,129,150,157,162,197,211]] organise the field by model family, dataset or "
        "deployment setting. According to their extractions they mention imbalance handling and explanation at survey level and describe no "
        "joint treatment. Other reviews published in this journal take a similar breadth-first view of machine-learning-based intrusion "
        "detection, of machine learning and deep learning for cyber security, and of data-driven detection in industrial control networks "
        "[[bg:thakkar2023,bg:geetha2021,bg:tama2022]]; these three were not in the candidate pool and were not analysed.")
    B.p("**Imbalance-centred reviews** [[18,188,207]] give mitigation a dedicated treatment, through a taxonomy of data-level, algorithm-level "
        "and hybrid methods or a focus on rare intrusions. Their extractions record brief treatment of explanation.")
    B.p("**Explanation-centred reviews** [[9,26,89,164]] cover explanation techniques, knowledge graphs, language models, or explanation for IoT "
        "and wireless-sensor-network security. Imbalance appears briefly in their extractions or, for one of them, was not recorded. One [[89]] "
        "was published in this journal.")
    B.p("**Reviews covering both topics inside a wider frame.** Two reviews come closest. One reviews explanation-enabled NIDS across general, "
        "IoT, medical, industrial-control and automotive settings and, according to its extraction, also discusses cost-sensitive learning, SMOTE "
        "and generative oversampling [[128]]. The other builds a five-axis framework for trustworthy DL in cybersecurity that includes "
        "imbalance-aware metrics, generative augmentation, focal loss and explanation fidelity and stability [[69]]. Whether either analyses "
        "the interaction between mitigation and explanation, or evaluates it, cannot be established from the extractions, and their full texts "
        "have not been examined.")
    B.p("**A dataset-focused review** analyses the CIC-IDS2017 benchmark, including its class imbalance, duplicate flows and limitations "
        "[[103]]; its extraction records no use of explanation.")
    rows = []
    for r in REVIEWS:
        if r[1] is None:
            rows.append([f'**{r[0]}**', '', '', ''])
        else:
            rows.append([f'{C([r[0]])} ({r[1]})', r[2], r[3], r[4]])
    B.table('The 26 existing reviews and surveys, kept separate from the primary-study synthesis. Scope and coverage come from their structured '
            'extractions and have not been verified against the review texts, so depth is indicative', ['Review', 'Scope (extraction)',
            'Coverage (deep learning; imbalance; explanation)', 'Joint examination'], rows, widths=[2.0, 4.6, 6.4, 3.0], size=8)
    B.p("**Conditional novelty statement.** On the evidence of the extractions, none of the 26 existing reviews is described as an evidence map "
        "of how primary studies combine mitigation with explanation techniques and how they evaluate the combination, and none is described as "
        "analysing the computational dependence of explanations on mitigation (Section 3.5). The distinction claimed for this review is "
        "therefore one of integration and evaluation focus: it organises primary-study evidence on the combination, states why the two "
        "components interact, and reports what the evidence does and does not show. The claim is conditional. It must be re-examined once the "
        "full texts of the two closest reviews [[69,128]] and of the review in this journal [[89]] have been checked, and it is not a claim that "
        "this is the first review to treat the two topics together. A limited web search also surfaced further reviews of explanation in "
        "intrusion detection that are not in the comparison corpus; they were not analysed, and failing to find an identical title in a search "
        "is not evidence of novelty.")

    # ------------------------------------------------------------------ 6
    B.h(1, '6 Discussion')
    B.h(2, '6.1 What the corpus shows')
    B.p(f"Within the reviewed corpus, imbalance mitigation is common ({MT['M']} of {n} studies name an explicit method) and explanation is less "
        f"common ({ln('EV')} studies carry explanation evidence), and the two are reported together in {ln('both')} studies. The corpus offers "
        "breadth across architectures, datasets and techniques. It was assembled with imbalance and explanation in mind, so these shares "
        "describe the corpus and not the NIDS field, and the evidence supports statements about what studies report and not about which "
        f"techniques work best. The central finding concerns evaluation: of the {ln('both')} studies that combine the two, {ln('quality_both')} "
        f"evidence a test of the explanation, {ln('cs_both')} a class-sensitive detection metric, and {ln('quality_cs_both')} both.")
    B.h(2, '6.2 Methodological assumptions and trade-offs')
    B.p("**Data-level versus loss-level mitigation.** Class weighting and balanced resampling target the same balanced risk (Section 3.2), so "
        "they should be compared on variance, cost and failure modes rather than on the objective. Data-level methods add computation that "
        "grows with the minority set and, for generative synthesis, the training of a second deep model; they also create the leakage risk "
        "that the corpus rarely documents, and their synthetic samples can be of poor quality: one study records training instability and a "
        "risk of mode collapse on multiclass minority distributions [[83]]. Loss-level methods add almost no computation and cannot leak, but "
        "they depend on weights or a focusing parameter that are usually tuned on the same benchmark, and extreme weights inflate gradient "
        "variance for classes with a handful of samples. The corpus contains many single-study comparisons and no multi-study protocol that "
        "would settle the choice.")
    B.p("**Few-shot, federated and decision-level formulations.** Meta-learning and few-shot formulations [[6,93,205]] address the extreme "
        "case in which a class has tens of samples, but they are evaluated on episodic splits whose relation to operational class frequencies "
        "is rarely stated. Federated rebalancing faces imbalance across clients as well as within them; one study records zero recall on "
        "classes absent from every client split [[117]], which no reweighting can repair. Decision-threshold adjustment is the cheapest "
        "intervention and the only one that can be changed after deployment, yet it is evidenced in four studies and the prior-correction "
        "identity of Section 3.2 is not discussed in the extractions.")
    B.p("**Explanation techniques.** The explanation families differ in cost, determinism and dependence on a reference distribution. "
        "Tree-specific Shapley values are exact and fast; Kernel SHAP and LIME are model-agnostic but stochastic and expensive, with one study "
        "recording Kernel SHAP latencies above 15 s per sample and rank variation across seeds [[182]]; gradient methods are cheap for "
        "differentiable models and one comparison found a gradient-based method the most faithful on a recurrent detector [[96]]; and attention "
        "weights are free but contested as explanations [[bg:jain2019,bg:wiegreffe2019]]. Several studies note that inherently interpretable "
        "or tree-based models can provide fast, faithful explanations with competitive detection [[88,191]], echoing the argument that "
        "high-stakes settings should prefer interpretable models where they suffice [[bg:rudin2019]]. Whether that holds for rare attack classes "
        "in particular is not evidenced.")
    B.p("**Tensions recorded in the extractions.** An explanation can help reduce input size, as when a SHAP ranking prunes features for "
        "resource-constrained hardware, but the same extraction records a slight loss of recall on rare attack categories [[58]]. Post-hoc "
        "explanation is attractive for reviewing alerts, but its computational cost is recorded as a limitation [[87,147]], and generating "
        "textual explanations adds latency in one study [[88]]. Explanation techniques can also disagree or become unstable, as the findings in "
        "Section 4.4 show [[182,192,142]].")
    B.h(2, '6.3 Why reported results cannot be compared or pooled')
    B.p(f"Reported accuracies cluster near the ceiling, but the protocols behind them differ in dataset family and version, binary or "
        "multiclass formulation, label granularity, deduplication, the order of splitting and resampling, and the metric set. A single study "
        "can report 98.98% accuracy with 84.78% macro-F1 [[63]]. Because accuracy is a prior-weighted average of recalls (Section 3.1), two "
        "studies with identical accuracy can differ arbitrarily on the rarest class. The extractions record point estimates without variances, "
        "and only a minority of studies report repeated evaluation. For these reasons no pooled estimate was computed, and any ranking of "
        "methods from the published numbers would mostly reflect protocol differences. Benchmarks with known artefacts "
        "[[bg:tavallaee2009,bg:engelen2021,103]] and the closed-world assumption of most evaluations [[bg:sommer2010]] add to the gap between "
        "reported and operational performance.")
    B.h(2, '6.4 Implications')
    B.p("For researchers the main implication concerns reporting and protocol: studies that pair mitigation with an explanation technique "
        "would be interpretable if they reported per-class and class-sensitive metrics, stated the split-then-resample order, reported the "
        "class composition of the explanation background set, showed explanations per class, tested explanation fidelity and stability, "
        "compared explanations before and after mitigation, and released code (Section 8). For practitioners the evidence supports caution: "
        "in the extractions, imbalance handling is usually evidenced through aggregate metrics and explainability through illustrative plots, "
        "and almost no study evaluates on hardware or transfers a model to another dataset. Neither implication rests on a comparison of "
        "techniques; both follow from what the extractions do and do not evidence.")

    # ------------------------------------------------------------------ 7
    B.h(1, '7 Research gaps')
    B.p(f"Table 20 lists the gaps that the evidence supports, each tied to the count and denominator from Section 4. Every entry is an "
        "extraction-based indicator and not a verified finding, and none concerns the field beyond the reviewed corpus.")
    B.table(f'Research gaps and the evidence behind each. All counts are extraction-based and computed from the {n} included studies unless '
            'another denominator is stated', ['Gap', 'Evidence in the reviewed corpus', 'Section'], [
        ['Limited joint treatment', f"{ln('both')} studies report an explicit method and an explicit technique; {ln('M_noexp')} report an explicit method with no explanation evidence; {ln('exp_noM')} report explanation evidence with no confirmed method; {ln('cand_one') + ln('cand_both')} are unresolved", '4.5'],
        ['Explanation quality rarely assessed', f"Assessment evidenced for {ln('quality_A12')} of {ln('A12')} A1 or A2 studies and for {ln('quality_both')} of the {ln('both')}", '4.4, 4.5'],
        ['Explanation quality and minority-class detection not evaluated together', f"Both a quality assessment and a class-sensitive metric are evidenced for {ln('quality_cs_both')} of the {ln('both')}", '4.5'],
        ['Little analysis of explanations for minority classes', f"An explanation tied to minority classes is evidenced for {ln('minority_explicit') + ln('minority_indirect')} of the {ln('both')} (explicit for {ln('minority_explicit')})", '4.5'],
        ['Mitigation–explanation interaction untested', 'No study compares explanations before and after mitigation or reports the class composition of the explanation background', '3.5, 4.5'],
        ['Inconsistent imbalance-aware metrics', f"A class-sensitive metric is listed for {ln('cs_M')} of the {MT['M']} tier-M studies", '4.3'],
        ['Explanation-guided mitigation barely explored', 'One study uses explanation to steer mitigation', '4.5'],
        ['Benchmarks and generalisation', f"Legacy benchmarks in {ln('kdd_any')} of {ln('dsok')}; a single dataset family in {ln('single_named')}; transfer between datasets in {ln('h_transfer_eval')} of {n}", '4.6'],
        ['Evaluation leakage not documented', f"Evaluation leakage discussed in {ln('h_eval_leakage')}; leakage-safe or training-only resampling stated in {ln('h_leak_safe_resampling')} of {n}", '4.6'],
        ['Deployment evidence absent', f"Hardware or testbed evaluation in {ln('h_hardware_eval')} of {n}; computational cost measured in {ln('ind_cost_measured')}, recorded as a limitation in {N['limitations']['cost/latency']}", '4.6, 4.7'],
        ['Reproducibility', f"Repeated evaluation or statistical testing in {ln('ind_stat_rigor')}; code released in {ln('h_code_release')} of {n}", '4.6'],
    ], widths=[4.2, 10.4, 1.4])

    # ------------------------------------------------------------------ 8
    B.h(1, '8 Future research directions and a proposed evaluation framework')
    B.p("Table 21 maps each gap to directions that follow from the evidence. The directions are proposals; none has been tested here.")
    B.table('Proposed research directions mapped to the gaps. Source: synthesis by the reviewers; the entries are proposals, not demonstrated results',
            ['Gap', 'Direction', 'Evidence that motivates it'], [
        ['Explanation quality and minority classes', 'Report fidelity and stability of explanations per class, including rare classes, with repeated runs and intervals', 'Quality and minority-class evidence are sparse and rarely co-occur (Section 4.5)'],
        ['Interaction of mitigation and explanation', 'Compare explanations before and after mitigation, and across mitigation families, on the same model and data; report and vary the background distribution', 'No such comparison is described; analytical reasons in Section 3.5'],
        ['Explanation-guided mitigation', 'Use per-class explanations to detect spurious features or weak classes and to steer retraining', 'One study uses this idea [[63]]'],
        ['Metrics and protocol', 'Adopt the minimum reporting set of Table 22; split before resampling and state it', 'Class-sensitive metrics and split order are sparsely evidenced (Section 4.6)'],
        ['Benchmarks and generalisation', 'Cross-dataset, temporal and unseen-attack evaluation with newer data and realistic class ratios; prior correction at deployment', 'Legacy datasets are common; transfer is rarely tested'],
        ['Cost and deployment', 'Lightweight explanation and mitigation within latency and memory budgets; measure explanation cost on target hardware', 'Cost is the most frequent recorded limitation; hardware evaluation is almost absent'],
        ['Evidence base', 'Audit the full texts behind the extractions; resolve conflicts; repeat with a fully documented, dated search', 'Counts rest on extractions and conflicts remain'],
    ], widths=[3.6, 7.0, 5.4])
    B.p("**A proposed evaluation framework.** Fig. 9 relates four properties that the review argues should be evaluated jointly: imbalance "
        "robustness, detection performance, explanation quality and deployment requirements, with the mitigation–explanation interaction "
        "as the link least examined in the corpus. The framework is derived from the synthesis of the five research questions and from the "
        "analysis of Section 3.5. It is a proposal, has not been tested experimentally and is not taken from any single study. Table 22 turns "
        "it into a minimum reporting checklist, and Fig. 10 summarises the path from gaps to practices and directions.")
    B.figure(FIG + r'\Fig9.png', 'Proposed evaluation framework: dependencies among imbalance robustness, detection performance, explanation '
             'quality and deployment requirements, with the mitigation–explanation interaction (centre) as the least-examined link. Derived '
             'from the synthesis of RQ1–RQ5; not experimentally validated. Conceptual figure, not derived from the evidence data', 15.5)
    B.table('Proposed minimum reporting checklist for studies that combine imbalance mitigation with explanation. Derived from the gaps in Table '
            '20; not validated', ['Element', 'What to report', 'Corpus evidence (extraction level)'], [
        ['Data', 'Dataset name and version; class counts in every split; deduplication; feature set', f"Dataset unnamed in {ln('unnamed')} of {ln('dsok')}; dataset-identity conflicts in {ln('dsConflict')}"],
        ['Protocol', 'Split before any resampling or synthesis, and say so; resampling parameters; random seeds; repeated runs with intervals', f"Leakage-safe resampling stated in {ln('h_leak_safe_resampling')} of {n}; repeated evaluation in {ln('ind_stat_rigor')}"],
        ['Detection metrics', 'Per-class recall and F1, macro-F1, MCC and a precision–recall summary, with the confusion matrix', f"Class-sensitive metric in {ln('cs_M')} of {MT['M']} tier-M studies"],
        ['Calibration', 'Training and deployment priors; any threshold or prior correction', 'Not evidenced'],
        ['Explanation set-up', 'Technique and implementation; background or reference set and its class composition; samples explained', 'Background composition not evidenced'],
        ['Explanation quality', 'Fidelity (for example deletion tests) and stability (for example top-m Jaccard overlap), per class', f"Evidenced for {ln('quality_A12')} of {ln('A12')} A1 or A2 studies"],
        ['Minority classes', 'Explanations reported separately for each rare class', f"Evidenced for {ln('minority_explicit') + ln('minority_indirect')} of {ln('both')} explicit-both studies"],
        ['Interaction', 'Explanations before and after mitigation on the same model family and data', 'Not evidenced'],
        ['Generalisation', 'Cross-dataset, temporal or unseen-attack evaluation', f"Transfer in {ln('h_transfer_eval')}; unseen attacks in {ln('h_unseen_attack_eval')} of {n}"],
        ['Cost and deployment', 'Training time, inference and explanation latency, memory, and hardware', f"Cost measured in {ln('ind_cost_measured')}; hardware evaluation in {ln('h_hardware_eval')} of {n}"],
        ['Reproducibility', 'Code, configurations and trained models', f"Code released in {ln('h_code_release')} of {n}"],
    ], widths=[2.8, 7.6, 5.6])
    B.figure(FIG + r'\Fig10.png', 'Roadmap from evidence gaps seen in the extractions (left), through needed reporting practices (centre), to '
             'research directions (right). Qualitative synthesis by the reviewers; no value in the figure is quantitative. Conceptual figure, '
             'not derived from the evidence data', 15.5)

    # ------------------------------------------------------------------ 9
    B.h(1, '9 Limitations')
    B.h(2, '9.1 Limitations of this review')
    B.p("**Search and candidate corpus.** The candidate corpus was assembled with keyword families developed for this review, but the original "
        "search log was not retained. The sources searched, search dates, Boolean strings, the number of results and the number discarded during "
        "manual pre-screening cannot be reconstructed; the 265 numbered records are the size of a pre-screened candidate pool and not a "
        "database total; and the identities of the 11 removed duplicates were not recorded. The pool was assembled with explanation and "
        "imbalance in mind, so it is enriched for these topics and is not representative of the NIDS literature. The review does not claim "
        "exhaustiveness, and selection bias in the candidate pool cannot be quantified.")
    B.p(f"**Screening and verification.** Screening and eligibility assessment were a single pass assisted by a large language model, with no "
        f"independent second reviewer, no agreement statistics and no validation sample. Full texts were read only for the 11 records whose "
        f"eligibility was unresolved; the other {n - ln('fulltext')} included studies were assessed on structured extractions and bibliographic "
        "metadata and are not full-text verified. The eligibility criteria were fixed before the screening decisions but were not registered "
        "and were written after the pool existed. No protocol was registered, and no risk-of-bias or certainty assessment was performed.")
    B.p(f"**Extraction conflicts, provenance and flags.** The two extraction formats conflict for {MT['U'] + ET['U'] - ln('cand_both')} included "
        f"studies on mitigation ({MT['U']}) or explanation ({ET['U']}); the formats name different dataset families for {ln('dsConflict')}; "
        f"{ln('noNumeric')} record no numeric performance value; and {ln('genOnly')} have a deep component that only generates samples or "
        "encodes features. These were retained, flagged and kept out of the affected counts, so the central counts could change if the "
        "conflicts were settled against the papers. The provenance of the extractions is not recorded. The revision audit showed that a "
        "short-form summary can describe a study cited by the paper rather than the paper itself, and found two such cases that changed "
        "eligibility; misattributions in which both formats are wrong in the same way cannot be detected without full texts.")
    B.p("**Classification and indicators.** Family labels were assigned by keyword rules and hand checks, and a study can carry several labels. "
        "The explanation tiers depend on judgements about what counts as explanation. The explanation-quality and minority-class items were "
        "curated by hand, and the revision scan found six missed quality items, which shows that hand curation can under-count. Keyword "
        "indicators have unmeasured precision and recall; hand-checked indicators were read once by one assessor. The original indicator "
        "scripts were unavailable, so several indicators were redefined during revision (Online Resource 7).")
    B.p("**Bibliographic status and novelty.** Five cited works without a DOI could not be verified against an external index, and some cited "
        "works are preprints or repository deposits without peer review. The comparison with existing reviews rests on their extractions, not "
        "their texts, and the novelty claim is conditional on checks of three reviews.")
    B.h(2, '9.2 Limitations of the included studies')
    B.p("As recorded in the extractions, the included studies mostly evaluate offline on public benchmarks with known artefacts, report "
        "aggregate metrics, rarely state the order of splitting and resampling, rarely test explanations, rarely evaluate transfer or hardware "
        "deployment and rarely release code. These are properties of the evidence base, not of this review, and they limit what any synthesis "
        "of the corpus can conclude about effectiveness.")
    B.h(2, '9.3 Evidence still needed')
    B.p(f"Four kinds of evidence would strengthen the review: a dated, documented re-run of the search in named databases; the full texts of "
        f"the {n - ln('fulltext')} included studies that were not read in full, beginning with those with extraction conflicts, to confirm the "
        "mitigation and explanation classifications and to extract training cost, inference latency and explanation latency under a common "
        "protocol; an independent second assessment of a random sample of screening decisions with agreement statistics; and the full texts of "
        "the three closest existing reviews.")

    # ------------------------------------------------------------------ 10
    B.h(1, '10 Conclusions')
    B.p(f"This systematic literature review screened 254 unique candidate records and included {n} primary studies, {ln('fulltext')} of them "
        f"verified on full text and {n - ln('fulltext')} on extraction-level evidence. Its conclusions are bounded by that evidence. Within the "
        "reviewed corpus, the five questions can be answered as follows.")
    B.bullets([
        "**RQ1.** The studies cover a wide range of DL and hybrid architectures, dominated by feed-forward, convolutional, recurrent and "
        "attention-based designs, usually combined. Three benchmark families (UNSW-NB15, NSL-KDD and CIC-IDS2017) dominate dataset use. "
        "Differences in splits, formulations and metrics prevent any ranking of architectures.",
        f"**RQ2.** Loss-level methods, resampling and generative synthesis account for most explicit mitigation ({MT['M']} studies). A "
        f"class-sensitive metric is listed for {ln('cs_M')} of them. Class weighting and balanced resampling target the same balanced risk, and "
        "the evidence shows what is used, not what works best.",
        f"**RQ3.** Post-hoc explanation, mainly SHAP and LIME, dominates ({ln('EV')} studies with explanation evidence); attention-based "
        f"explanation is treated as weaker evidence. An assessment of explanation quality is evidenced for {ln('quality_A12')} of {ln('A12')} A1 or "
        "A2 studies, and the studies that test explanations report instability and disagreement.",
        f"**RQ4.** {ln('both')} studies report both an explicit imbalance-handling method and an explicit explanation technique, and "
        f"{ln('cand_one') + ln('cand_both')} further studies are unresolved. Most join the two as separate modules. The extractions evidence an "
        f"assessment of explanation quality for {ln('quality_both')} of the {ln('both')}, an explanation tied to minority classes for "
        f"{ln('minority_explicit') + ln('minority_indirect')}, and both a quality assessment and a class-sensitive metric for "
        f"{ln('quality_cs_both')}. No study compares explanations before and after mitigation, although the explained function, the explanation "
        "reference distribution and prevalence-weighted summaries all depend on the mitigation.",
        f"**RQ5.** The extractions evidence legacy benchmarks, single-dataset evaluation, scarce documentation of the split-then-resample order "
        f"({ln('h_leak_safe_resampling')} of {n}), almost no transfer ({ln('h_transfer_eval')}) or hardware evaluation ({ln('h_hardware_eval')}), and "
        f"rare code release ({ln('h_code_release')}), as indicators and not as verified findings. Source papers most often record computational "
        "cost as a limitation.",
    ])
    B.p("The review contributes a computational account of mitigation and explanation, an evidence map and a reporting-gap analysis built on an "
        "explicit classification, together with a proposed framework and reporting checklist for evaluating imbalance robustness and "
        "explanation quality jointly. Its novelty relative to the closest existing reviews remains conditional on full-text checks. The most "
        "useful next steps are a documented re-run of the search, a check of the full texts behind the extractions and of a sample of the "
        "screening decisions by a second assessor, resolution of the conflicting records, and empirical testing of the proposed checklist.")

    # ------------------------------------------------------------------ supplementary, references, declarations
    B.h(1, 'Supplementary information')
    B.p("The following Online Resources accompany the article; each is cited in the text.")
    B.bullets([
        f"Online Resource 1 (ESM_1.xlsx): evidence dataset of the {n} included primary studies, one row per study, with record identifier, reference "
        "number, evidence tiers, family labels, conflict flags, indicators, full-text status and the corrections made during revision.",
        "Online Resource 2 (ESM_2.xlsx): screening status of the 254 unique records (decision and stage).",
        "Online Resource 3 (ESM_3.xlsx): eligibility-stage status of the 206 records that entered eligibility assessment.",
        "Online Resource 4 (ESM_4.xlsx): register of extraction conflicts and flags (mitigation, explanation, dataset identity, missing numeric "
        "results, generative-only components).",
        "Online Resource 5 (ESM_5.xlsx): the 26 existing reviews and surveys with their scope and coverage as recorded in the extractions.",
        "Online Resource 6 (ESM_6.xlsx): the 12 records unresolved at the eligibility step, with the full-text finding and decision for each.",
        "Online Resource 7 (ESM_7.zip): scripts and input tables that reproduce every count, table and figure, and a comparison of original and "
        "recomputed indicator values.",
        "Online Resource 8 (ESM_8.pdf): completed PRISMA 2020 checklist.",
    ])
    B.h(1, 'References')
    B.references()
    B.h(1, 'Statements and Declarations')
    B.p("**Funding.** The authors declare that no funds, grants or other support were received during the preparation of this manuscript.")
    B.p("**Competing interests.** The authors have no relevant financial or non-financial interests to disclose.")
    B.p("**Author contributions.** Tarun Jangwal conceived the review and designed its methodology. Purva Pathania performed the literature "
        "search and assembled the candidate records. Tarun Jangwal carried out the screening, data extraction and analysis, with the "
        "assistance of a large language model as described in Section 2.14, and drafted the manuscript. Both authors critically revised the "
        "manuscript, and read and approved the final version.")
    B.p("**Data availability.** The data that support the findings of this review (the evidence dataset, the screening and eligibility tables, "
        "the conflict register, the reviews table, the full-text resolution table, the scripts and the PRISMA 2020 checklist) are provided with "
        "the article as Online Resources 1–8 and are openly available in a GitHub repository at "
        "https://github.com/ProfTarun/xai-imbalance-nids-slr. The primary studies are cited in the reference list.")
    B.p("**Ethics approval and consent.** Not applicable. This review analyses published literature and involved no human participants, "
        "personal data or animals.")
