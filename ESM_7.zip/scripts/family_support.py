# Verify that each mitigation/explanation family label is supported by some wording in the study's record (excluding the title)
import json, re
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
rows = {r['ref']: r for r in json.load(open(W + r'\audit_rows.json', encoding='utf-8'))}
D = json.load(open(W + r'\ms_data.json'))
KW = {
    ('mit', 'Loss/cost-sensitive'): r'focal|weight|cost[- ]sensitive|loss',
    ('mit', 'Random/other resampling'): r'sampl|tomek|ENN|ROS|RUS|duplicat|DSSTE|balanc',
    ('mit', 'Generative synthesis'): r'\bGANs?\b|generative|VAE|diffusion|synthetic|LLM|augment|WGAN|CTGAN',
    ('mit', 'SMOTE family'): r'SMOTE|ADASYN',
    ('mit', 'Ensemble/boosting'): r'ensemble|boost|bagg|stack|voting',
    ('mit', 'Few-shot/contrastive'): r'few-shot|contrastive|meta|prototyp|one-class|siamese',
    ('mit', 'Federated-specific'): r'federat|non-IID',
    ('mit', 'Threshold/calibration'): r'threshold|calibrat',
    ('exp', 'SHAP'): r'SHAP|Shapley',
    ('exp', 'LIME'): r'\bLIME\b',
    ('exp', 'Model-derived FI'): r'importance|permutation|attribution|Gini|MDI',
    ('exp', 'Attention'): r'attention',
    ('exp', 'Rules/surrogate/intrinsic'): r'rule|surrogate|decision tree|fuzzy|prototype|partial dependence|PDP|intrinsic|interpretable',
    ('exp', 'Gradient-based'): r'Grad-?CAM|saliency|integrated gradient|LRP|relevance propagation|gradient',
    ('exp', 'Counterfactual/anchors'): r'counterfactual|anchor',
}
for (sec, fam), pat in KW.items():
    for ref in D[sec][fam]:
        md = rows[ref]['md']
        body = recs[md]['body']
        body = body.split('\n', 1)[1] if '\n' in body else body
        title = rows[ref]['title']
        body_wo_title = body.replace(title, '')
        hits = [m.group(0) for m in re.finditer(pat, body_wo_title, re.I)]
        if not hits:
            print(f'UNSUPPORTED {sec}:{fam} [{ref}] P{md} | {title[:70]}')
        elif fam == 'Generative synthesis' and all(h.lower().startswith('gan') and False for h in hits):
            pass
# specific: GAN substring false positives
for ref in set(D['arch']['GAN-based']) | set(D['mit']['Generative synthesis']):
    body = recs[rows[ref]['md']]['body']
    real = re.findall(r'\bGANs?\b|generative adversarial|WGAN|CTGAN|BiGAN|ACGAN|CGAN|VAE|diffusion|LLM|synthetic', body, re.I)
    if not real:
        print('NO GENERATIVE TERM', ref, rows[ref]['title'][:70])
