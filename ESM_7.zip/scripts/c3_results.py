# Manuscript part 3: results and evidence synthesis
from ms_common import *

ARCH_SCOPE = {
    'MLP/DNN/ANN': 'Feed-forward or generic deep networks (broad label; also matches studies that name only “deep learning”)',
    'CNN': 'Convolutional models on flow features, byte or image-like encodings',
    'RNN/LSTM/GRU': 'Recurrent models for sequences of flows or packets',
    'Transformer/attention': 'Self-attention encoders, attentive tabular models and attention layers inside hybrids',
    'GAN-based': 'Generative adversarial components (augmentation or detection)',
    'Autoencoder/VAE': 'Reconstruction, latent-space and variational models',
    'Federated': 'Federated or distributed training of deep detectors',
    'Meta/few-shot/contrastive': 'Meta-learning, few-shot, contrastive and self-supervised designs',
    'GNN': 'Graph neural networks',
    'Reinforcement learning': 'Deep reinforcement-learning agents',
    'Other deep': 'Diffusion, capsule, spiking, Kolmogorov–Arnold, extreme-learning-machine, quantum-inspired, mixture-of-experts and transfer designs',
}
DS_LABEL = {'Other IoT/IIoT': 'X-IIoTID, WUSTL, IoT-23 and other IoT or industrial IoT (IIoT) sets', 'In-vehicle': 'In-vehicle (controller area network) and vehicular',
            'ICS/SCADA/power': 'Industrial control, supervisory control and data acquisition (SCADA) and power systems', 'Other named': 'Other named (5G, SDN, smart grid, healthcare, other)',
            'Other/custom/synthetic': 'Other, custom or synthetic', 'Unnamed benchmark': 'Unnamed “benchmark” mentioned in the extraction', 'Unnamed': 'No dataset named in the extraction'}
MIT_SCOPE = {
    'Loss/cost-sensitive': 'Focal loss, class weights, cost matrices, weighted losses',
    'Random/other resampling': 'Random or informed over- and under-sampling, Tomek links, DSSTE, weighted samplers',
    'Generative synthesis': 'Synthetic minority samples from GAN, VAE, diffusion or language models; augmentation',
    'SMOTE family': 'SMOTE, ADASYN, Borderline-SMOTE and hybrids',
    'Ensemble/boosting': 'Boosting, bagging, stacking or voting used for imbalance',
    'Few-shot/contrastive': 'Few-shot, meta-learning, contrastive, prototype or one-class formulations',
    'Federated-specific': 'Client-side or aggregation-level handling under non-IID skew',
    'Threshold/calibration': 'Decision-threshold or calibration adjustment',
    'Explanation-guided': 'Retraining guided by explanation output',
}
EXP_SCOPE = {
    'SHAP': 'Shapley-value attributions (global summaries and local plots)',
    'LIME': 'Local surrogate explanations of single predictions',
    'Model-derived FI': 'Importance scores from tree models, permutation or attribution outputs',
    'Attention': 'Attention scores or maps presented as explanation',
    'Rules/surrogate/intrinsic': 'Rules, decision trees, fuzzy rules, prototypes, partial dependence or intrinsic designs',
    'Gradient-based': 'Gradient or relevance-propagation methods (Grad-CAM, saliency, integrated gradients, LRP)',
    'Counterfactual/anchors': 'Counterfactual or anchor explanations',
}
QM = {  # extraction-based descriptions for Table 15 (explanation quality, minority-class explanation)
    6: ('–', 'Indirect: SHAP used to check where attention focuses; minority-class (man-in-the-middle) recall reported separately'),
    14: ('Agreement between SHAP and LIME quantified (72% for benign, 65% for DDoS traffic)', '–'),
    52: ('Feature-removal fidelity (0.91) and stability (0.89) of SHAP explanations', '–'),
    58: ('–', 'Indirect: SHAP-based feature selection reported to retain minority-attack features; a slight recall loss on rare categories is recorded'),
    63: ('–', 'Explicit: per-class SHAP analysis identifies weak minority classes and drives retraining'),
    83: ('–', 'Indirect: LIME used to check feature contributions; minority detection reported separately'),
    87: ('Fidelity, stability and consistency listed as metrics; trade-off figure', '–'),
    88: ('Fidelity score and explanation latency for four explainable architectures', '–'),
    93: ('–', 'Explicit: attention scores computed and compared for rare and majority classes'),
    95: ('Faithfulness, sensitivity and complexity of LIME and SHAP compared', '–'),
    122: ('Cross-layer consistency of Grad-CAM explanations (inconsistency index, spatial-consistency kappa)', '–'),
    147: ('SHAP attribution consistency listed as a metric', 'Explicit: SHAP summaries computed for minority attack classes'),
    168: ('Feature-ranking consistency checked across SHAP, LIME, Morris and permutation importance', '–'),
    191: ('Explanation-fidelity score and explanation generation time measured', 'Indirect: post-hoc model reported to retain minority recall; explanations not shown per class'),
    192: ('Consistency of attributions across MLP, LSTM and CNN; LIME-based selection unstable across seeds', 'Indirect: explanation-based feature selection retains minority indicators'),
    193: ('Fidelity (change in F1 after masking top-k features) and stability (bootstrap Jaccard overlap)', '–'),
    196: ('Consistency of SHAP rankings between tree and deep models', 'Explicit: attributions shown per attack class, including R2L and U2R'),
    201: ('Explanation stability listed as a metric', '–'),
}
SHORT = {'Model-derived FI': 'FI', 'Rules/surrogate/intrinsic': 'rules', 'Gradient-based': 'gradient', 'Counterfactual/anchors': 'counterfactual', 'Attention': 'attention'}


def build(B):
    B.h(1, '4 Results and evidence synthesis')
    B.p(f"Every count in this section is computed from the {n} included primary studies. The 26 existing reviews, the excluded records and the "
        "record that could not be obtained are not included in any denominator. Each research question is answered in the same way: its scope "
        "and denominator, the taxonomy derived from the evidence, a comparison table, an Observations block (counts and source-reported facts), "
        "a Discussion and Comments block (interpretation by the reviewers) and the limitations that apply. Tables list every study in the "
        "relevant family, so each claim can be traced to the records behind it; study-level data are given in Online Resource 1.")
    # ---------------- 4.1
    B.h(2, '4.1 Study selection and characteristics of the included studies')
    B.p(f"Figure 2 shows the selection flow in the PRISMA 2020 format. From 265 numbered candidate records, 11 duplicates were removed and 254 "
        f"records were screened; 23 were excluded and 25 existing reviews were set aside; 206 were assessed for eligibility on the two "
        f"extraction formats, of which 6 were excluded, 188 were eligible and 12 were unresolved; 11 of the 12 were assessed in full text "
        f"(5 excluded, 6 eligible) and 1 could not be obtained; and the record-level audit moved one record to the review corpus and excluded "
        f"one dataset paper. {n} primary studies are included. Table 6 summarises the corpus and the main findings, each with its evidence class and a confidence level, and Fig. 3 shows, for each research question, how "
        f"the {n} studies divide into those that carry usable evidence, those whose extraction formats conflict and those that carry none.")
    B.figure(FIG + r'\Fig2.png', 'Study selection flow (PRISMA 2020 format, used as a reporting format only). Search results were pre-screened manually before '
             'records were numbered; the sources, dates and counts of that stage were not recorded and are shown as not recorded rather than '
             'estimated. Stage-1 screening and the eligibility step used structured extractions and bibliographic metadata; full texts were '
             'read for the 12 unresolved records. The record-level audit (Section 2.7) moved one systematic review to the comparison corpus and '
             'excluded one dataset paper. Counts are computed from the screening tables (Online Resources 2, 3 and 6)', 15.5)
    core = [r for r in S if not (S[r]['mit_tier'] == 'N' and S[r]['exp_tier'] == 'none')]
    confl = sorted(set(N['mit_tier_lists']['U']) | set(N['exp_tier_lists']['U']))
    DSN = {k: len(v) for k, v in N['ds'].items()}
    B.table(f'Characteristics and main findings of the {n} included primary studies, with the evidence class of each count and a confidence '
            'level. Confidence: high = full-text verified or a name stated in the extraction; moderate = assigned from the extractions or an '
            'indicator checked record by record; low = keyword-only indicator or an absence claim sensitive to unresolved conflicts. '
            '“Not evidenced” means not evidenced in the extractions',
            ['Item', 'n', 'Evidence class', 'Confidence', 'Section'], [
        ['Included primary studies (curated, non-exhaustive corpus)', n, 'Assigned (single-reviewer selection)', 'Moderate', '2.3–2.7'],
        ['Full-text verified studies', f"{ln('fulltext')} of {n}", 'Full text', 'High', '2.6'],
        ['Inclusion tier: core / supporting', f'{len(core)} / {n - len(core)}', 'Assigned', 'Moderate', '2.8'],
        ['Two or more architecture-family labels', ln('multiarch'), 'Assigned (keyword families)', 'Moderate', '4.2'],
        ['Most named datasets: UNSW-NB15 / NSL-KDD / CIC-IDS2017', f"{DSN['UNSW-NB15']} / {DSN['NSL-KDD']} / {DSN['CIC-IDS2017']} of {ln('dsok')}", 'Extracted', 'High', '4.2'],
        ['IoT, industrial or vehicular data', f"{ln('cps_any')} of {ln('dsok')}", 'Extracted', 'High', '4.2'],
        ['Explicit imbalance-mitigation method (tier M)', f"{MT['M']} of {n}", 'Assigned', 'Moderate', '4.3'],
        ['Loss-level reweighting among tier M', f"{ln('mit', 'Loss/cost-sensitive')} of {MT['M']}", 'Assigned', 'Moderate', '4.3'],
        ['Class-sensitive metric listed among tier M', f"{ln('cs_M')} of {MT['M']}", 'Keyword indicator', 'Low', '4.3'],
        ['Explanation evidence (tier A1 / A2 / B)', f"{ln('EV')} ({ET['A1']} / {ET['A2']} / {ET['B']})", 'Assigned', 'Moderate', '4.4'],
        ['Explanation-quality evidence among tiers A1 and A2', f"{ln('quality_A12')} of {ln('A12')}", 'Curated record by record', 'Moderate (may under-count)', '4.4'],
        ['Explicit mitigation and explicit explanation: confirmed / unresolved', f"{ln('both')} / {ln('cand_one') + ln('cand_both')}", 'Assigned', 'Moderate; conflict-sensitive', '4.5'],
        ['Among confirmed: quality / minority-class (explicit + indirect) / quality and class-sensitive metric', f"{ln('quality_both')} / {ln('minority_explicit')} + {ln('minority_indirect')} / {ln('quality_cs_both')}", 'Curated; keyword indicator', 'Low to moderate (absence claims)', '4.5'],
        ['Hardware evaluation / leakage-safe resampling / code release / cross-dataset testing', f"{ln('h_hardware_eval')} / {ln('h_leak_safe_resampling')} / {ln('h_code_release')} / {ln('h_transfer_eval')} of {n}", 'Indicator checked record by record', 'Moderate', '4.6'],
        ['Measured computational cost; repeated evaluation or statistical testing', f"{ln('ind_cost_measured')} / {ln('ind_stat_rigor')} of {n}", 'Keyword indicator', 'Low', '4.6'],
        ['Conflict between extraction formats on mitigation or explanation', len(confl), 'Flag', 'Counted neither way', '2.10'],
        ['No numeric performance value recorded', ln('noNumeric'), 'Flag', 'Excluded from performance statements', '2.10'],
        ['Deep component generates samples or encodes features; classical final classifier', ln('genOnly'), 'Flag', 'Reported separately', '2.10'],
    ], widths=[6.4, 2.6, 3.0, 2.6, 1.4], size=8)
    B.figure(FIG + r'\Fig3.png', f'Evidence status of the {n} included studies for each research question; every bar sums to {n}. RQ4 groups the '
             'partition reported in Section 4.5 into four segments (“mitigation only” includes studies whose only explanation evidence is '
             'model-derived importance; “other” includes explanation-only and neither). Evidence-derived figure computed from Online Resource 1', 16)

    # ---------------- 4.2 RQ1
    B.h(2, '4.2 RQ1: architectures and datasets')
    B.p(f"**Scope and denominator.** RQ1 asks what DL architectures and datasets the included studies use. Architecture counts use all {n} "
        f"studies. Dataset counts use the {ln('dsok')} studies whose two extraction formats do not conflict on dataset identity; the "
        f"{ln('dsConflict')} studies in conflict are listed separately and are not counted in any dataset family.")
    A = N['arch']
    B.p(f"**Architectures.** Table 7 lists every included study under the family labels assigned to it (Fig. 4a). Generic feed-forward or deep "
        f"networks (multilayer perceptrons, MLP; deep and artificial neural networks, DNN and ANN) form the broadest label, because it also "
        f"matches studies that name only “deep learning”. Convolutional ({ex(A['CNN'])}), recurrent (recurrent neural networks, RNN; "
        f"LSTM; gated recurrent units, GRU; {ex(A['RNN/LSTM/GRU'])}) and attention-based designs ({ex(A['Transformer/attention'])}) follow. GAN "
        f"components appear in {ex(A['GAN-based'])} and autoencoders or VAEs in {ex(A['Autoencoder/VAE'])}. Federated designs "
        f"({ex(A['Federated'])}), meta-learning, few-shot and contrastive designs ({ex(A['Meta/few-shot/contrastive'])}), graph neural networks "
        f"(GNN; {C(A['GNN'])}) and reinforcement learning ({C(A['Reinforcement learning'])}) are small groups. Most studies combine families, for "
        f"instance a convolutional encoder followed by a recurrent layer and an attention block. In {ln('genOnly')} studies the deep component "
        f"only generates samples or encodes features while a classical model makes the final decision; they are counted in their families and "
        f"flagged in Table 7.")
    rows = [[k, ARCH_SCOPE[k], len(v), C(v)] for k, v in sorted(A.items(), key=lambda x: -len(x[1]))]
    rows.append(['Flag: generative or encoding only', 'Deep component generates samples or encodes features; the final classifier is classical (also counted above)', ln('genOnly'), C(N['genOnly'])])
    B.table(f'Architecture families among the {n} included studies. A study can carry several labels, so rows overlap; every included study '
            'appears in at least one row', ['Familyᵃ', 'Scope of the label', 'n', 'Studies'], rows, widths=[2.6, 4.2, 0.8, 8.4],
            footnote='ᵃ Labels were assigned from the architecture fields of the structured extraction; they are descriptive tags, not a validated taxonomy')
    D_ = N['ds']
    B.p(f"**Datasets.** Table 8 and Fig. 4b show the dataset families. Three benchmark families dominate: UNSW-NB15 ({ex(D_['UNSW-NB15'])}), "
        f"NSL-KDD ({ex(D_['NSL-KDD'])}) and CIC-IDS2017 ({ex(D_['CIC-IDS2017'])}). Newer IoT and industrial sets follow, including ToN-IoT "
        f"({ex(D_['ToN-IoT'])}), Bot-IoT ({ex(D_['Bot-IoT'])}) and Edge-IIoTset ({ex(D_['Edge-IIoTset'])}). {len(D_['Unnamed benchmark']) + len(D_['Unnamed'])} "
        f"extractions mention an unnamed “benchmark” or no dataset, and {ln('unnamed')} studies name no specific dataset at all "
        f"({ln('unnamed') - len(D_['Unnamed'])} whose only dataset label is an unnamed benchmark and {len(D_['Unnamed'])} with no dataset), which "
        f"limits traceability. Engineering settings are well represented: {ln('cps_any')} of the {ln('dsok')} studies use IoT, industrial or "
        f"vehicular data, {ln('cps_ind')} of them industrial-control, power-system, industrial-IoT (Edge-IIoTset) or in-vehicle data, and "
        f"{ln('both_cps')} of the {ln('both')} explicit-both studies belong to this group. Missing a minority attack in these settings can reach "
        f"a physical process; the extractions, however, rarely report deployment on such systems (Section 4.6).")
    order = ['UNSW-NB15', 'NSL-KDD', 'CIC-IDS2017', 'CSE-CIC-IDS2018', 'KDD Cup 99', 'ToN-IoT', 'Bot-IoT', 'Edge-IIoTset', 'CIC-IoT2023', 'CIC-DDoS2019',
             'Other IoT/IIoT', 'In-vehicle', 'ICS/SCADA/power', 'Other named', 'Other/custom/synthetic', 'Unnamed benchmark', 'Unnamed']
    rows = [[DS_LABEL.get(k, k), len(D_[k]), C(D_[k])] for k in order if D_[k]]
    onlyU = sorted(set(N['unnamed']) - set(D_['Unnamed']))
    rows.append(['Unnamed benchmark only, no named dataset (subset of the unnamed-benchmark row)', len(onlyU), C(onlyU)])
    rows.append(['Dataset-identity conflicts between the two extraction formats (not counted above)', ln('dsConflict'), C(N['dsConflict'])])
    B.table(f"Dataset families named in the extractions of the {ln('dsok')} included studies without a dataset-identity conflict (multi-label; "
            f"extracted; the {ln('dsConflict')} conflicting studies are excluded)",
            ['Dataset family', 'n', 'Studies'], rows, widths=[4.6, 0.8, 10.6])
    B.figure(FIG + r'\Fig4.png', f"Architecture families (a) among the {n} included studies and dataset families (b) among the {ln('dsok')} studies "
             'without a dataset-identity conflict. Bars show the number of studies; a study can carry several labels. IIoT: industrial Internet of '
             'Things. Family labels were assigned by keyword rules checked record by record (assigned, extraction level). Evidence-derived figure computed from Online Resource 1', 16.5)
    B.p("**Evaluation settings.** The extractions record accuracy, precision, recall, F1, false-alarm rates, ROC-AUC and, less often, "
        "class-sensitive metrics (Section 4.3). Reported accuracies are frequently very high, but each is obtained under the study's own split, "
        "binary or multiclass formulation and preprocessing. Two extractions illustrate why such numbers do not compare across studies: one "
        "reports an accuracy of 98.98% alongside a macro-F1 of 84.78% [[63]], and another reports 99.85% in a binary and 97.43% in a multiclass "
        f"formulation [[95]]. These values are as recorded in the extractions and have not been reproduced. {ln('noNumeric')} studies record no "
        "numeric performance value and are excluded from any statement about reported performance.")
    B.p(f"**Observations** (denominator {n} unless stated).")
    B.bullets([
        f"{ln('multiarch')} studies carry more than one architecture label.",
        f"UNSW-NB15 ({len(D_['UNSW-NB15'])} of {ln('dsok')}), NSL-KDD ({len(D_['NSL-KDD'])}) and CIC-IDS2017 ({len(D_['CIC-IDS2017'])}) account for most "
        f"dataset use. KDD Cup 99 or NSL-KDD appear in {ln('kdd_any')} of {ln('dsok')} and are the only named families in {ln('kdd_only')}.",
        f"{ln('single_named')} of {ln('dsok')} studies name a single dataset family and {ln('multi_named')} name two or more.",
        f"Federated ({len(A['Federated'])}), graph ({len(A['GNN'])}) and reinforcement-learning ({len(A['Reinforcement learning'])}) designs are small groups.",
    ])
    B.p("**Discussion and Comments.** *Interpretation.* Within the reviewed corpus there is a wide choice of architectures but no basis for "
        "ranking them. Differences in dataset, split, label granularity and metrics are larger than any difference the extractions would need to "
        "report for a ranking, and the extractions describe no study that compares many architectures under one protocol with class-sensitive "
        "metrics. Dataset concentration matters for a second reason: the dominant families were built under particular collection settings, "
        "their known artefacts [[bg:tavallaee2009,bg:engelen2021]] interact with resampling (duplicated or mislabelled minority records are "
        "duplicated again by oversampling), and results on them may not describe current traffic. Naming two or more dataset families is not the "
        "same as testing transfer between them; Section 4.6 shows that the latter is rare.")
    B.p(f"**Limitations.** Architecture labels are keyword-assigned tags, and the generic label is broad. {ln('dsConflict')} studies are outside "
        "the dataset counts because their two formats name different datasets, so the counts could change if those conflicts were resolved.")

    # ---------------- 4.3 RQ2
    B.h(2, '4.3 RQ2: imbalance handling and minority-class detection')
    M_ = N['mit']
    B.p(f"**Scope and denominator.** RQ2 asks how the included studies address imbalance and minority-class detection. Denominator: {n}. "
        f"{MT['M']} studies name an explicit method (tier M); {MT['W']} show an indirect link; {MT['N']} show none or evaluation-only handling; and "
        f"{MT['U']} are in conflict between extraction formats and are counted neither way (Fig. 5b; Tables 9 and 5). Family counts below use "
        f"the {MT['M']} tier-M studies.")
    B.table(f"Included studies without an explicit, confirmed imbalance-mitigation method (tiers W, N and U; {MT['W'] + MT['N'] + MT['U']} of {n})",
            ['Tier', 'n', 'Studies'], [
        ['Indirect (W)', MT['W'], C(N['mit_tier_lists']['W'])],
        ['None or evaluation-only (N)', MT['N'], C(N['mit_tier_lists']['N'])],
        ['Conflicting extraction formats (U)', MT['U'], C(N['mit_tier_lists']['U'])],
    ], widths=[4.0, 0.8, 11.2])
    B.p(f"**Taxonomy.** Table 10 and Fig. 5a give the families. Loss-level methods are the most common, mainly focal loss, class weights and "
        f"weighted cross-entropy ({ex(M_['Loss/cost-sensitive'])}). Resampling by random or informed over- and under-sampling "
        f"({ex(M_['Random/other resampling'])}) and generative synthesis with GAN, VAE, diffusion or language models ({ex(M_['Generative synthesis'])}) "
        f"are the next groups, and the SMOTE family ({ex(M_['SMOTE family'])}) is listed separately because of its prominence. Smaller groups use "
        f"ensembles ({ex(M_['Ensemble/boosting'])}), few-shot, meta-learning or contrastive formulations ({ex(M_['Few-shot/contrastive'])}), "
        f"federated rebalancing ({ex(M_['Federated-specific'])}) and decision-threshold adjustment ({ex(M_['Threshold/calibration'])}). One "
        f"study uses explanation output to select the classes to retrain [[63]]. {ln('multimit')} of the tier-M studies combine two or more "
        f"families, typically a data-level step with a loss-level step.")
    rows = [[k, MIT_SCOPE[k], len(v), C(v)] for k, v in sorted(M_.items(), key=lambda x: -len(x[1]))]
    B.table(f"Imbalance-mitigation families among the {MT['M']} included studies with an explicit method (tier M; multi-label). Every tier-M "
            "study appears in at least one row", ['Familyᵃ', 'Scope', 'n', 'Studies'], rows, widths=[2.8, 4.2, 0.8, 8.2],
            footnote='ᵃ Stratified splitting, stratified cross-validation, balanced test sets and macro-F1-only reporting were not counted as mitigation')
    B.figure(FIG + r'\Fig5.png', f"Imbalance-mitigation families among the {MT['M']} included studies with an explicit method (a) and evidence "
             f"tier of all {n} included studies (b). A study can carry several family labels. Explicit: tier M; Conflict: the two extraction formats "
             "disagree; None: no method or evaluation-only handling; Indirect: an effect on imbalance that is not a mitigation method. "
             "Evidence-derived figure computed from Online Resource 1", 16.5)
    cb = N['cs_M_by']
    B.p(f"**Evaluation of minority-class detection.** Among the tier-M studies, the extraction lists at least one class-sensitive metric for "
        f"{ln('cs_M')} of {MT['M']}: macro-F1 for {cb['macro-F1']}, G-mean for {cb['G-mean']}, MCC for {cb['MCC']}, a precision–recall "
        f"summary for {cb['PR summary']}, Cohen's kappa for {cb['kappa']} and per-class or minority-class recall for {cb['per-class recall']} "
        "(a study can list several). The others list accuracy, precision, recall, F1, ROC-AUC or false-alarm rates. Where class-sensitive "
        "metrics are listed, a reader can see whether mitigation helped minority classes; where only aggregate metrics are listed, that cannot "
        "be judged from the extraction.")
    B.p(f"**Observations** (denominator {n} unless stated).")
    B.bullets([
        f"Loss-level methods ({len(M_['Loss/cost-sensitive'])} of {MT['M']}), resampling ({len(M_['Random/other resampling'])}), generative synthesis "
        f"({len(M_['Generative synthesis'])}) and the SMOTE family ({len(M_['SMOTE family'])}) account for most explicit mitigation.",
        f"A class-sensitive metric is listed for {ln('cs_M')} of the {MT['M']} tier-M studies; macro-F1 is the most frequent.",
        f"{MT['U']} studies conflict on whether imbalance is handled; ensembles, few-shot or contrastive formulations, federated rebalancing and "
        "thresholding are each evidenced for fewer than ten studies.",
    ])
    B.p("**Discussion and Comments.** *Interpretation.* Counting families says what is used, not what works. Each study pairs a mitigation "
        "method with its own architecture, dataset and metric set, so the corpus cannot show that one family is better. Three cautions follow "
        "from Section 3.2. First, a method that changes the training distribution must be applied after the train–test split to avoid "
        "leakage, and whether this was done is rarely visible in the extractions (Section 4.6). Second, class weighting and balanced "
        "resampling target the same balanced risk, so differences between them reported within a study say more about variance, synthetic-sample "
        "quality and tuning than about the objective; few studies compare them under one protocol. Third, a detector trained on rebalanced data "
        "is calibrated to the rebalanced priors, and no extraction describes a correction of scores to operational priors. Studies that list "
        "only accuracy-type metrics for a problem defined by imbalance cannot show, from the extraction, that minority-class detection "
        f"improved. If the {MT['U']} conflicts were settled in favour of mitigation, the explicit count would rise to at most {MT['M'] + MT['U']}.")
    B.p("**Limitations.** Family labels rest on keyword rules and record-by-record checks. Metric lists come from the extractions and may omit metrics that "
        "the papers report. Mitigation in tier-W and tier-U studies is not established.")

    # ---------------- 4.4 RQ3
    B.h(2, '4.4 RQ3: explainability techniques')
    X = N['exp']
    B.p(f"**Scope and denominator.** RQ3 asks which explanation techniques are used to interpret DL-based NIDS models. Denominator: {n}. "
        f"{ln('EV')} studies carry explanation evidence of tier A1, A2 or B ({ET['A1']} A1, {ET['A2']} A2, {ET['B']} B); {ET['U']} conflict "
        f"between extraction formats and are counted neither way; {ET['none']} carry no qualifying item. Items often described as explanation "
        "but not counted are listed in Section 2.8.")
    B.p(f"**Taxonomy.** Fig. 6 and Table 11 give the families; a study can use several. Post-hoc explanation by feature attribution is the "
        f"commonest approach: SHAP ({ex(X['SHAP'])}) and LIME ({ex(X['LIME'])}) often appear together. Model-derived feature importance (tier B "
        f"when it is the only evidence) is next ({ex(X['Model-derived FI'])}). Attention-based explanation ({ex(X['Attention'])}) forms its own "
        f"tier, A2, when it is the only explanation. Smaller groups use rules, surrogate trees or intrinsic designs ({ex(X['Rules/surrogate/intrinsic'])}), "
        f"gradient-based methods ({ex(X['Gradient-based'])}) and counterfactual or anchor explanations ({C(X['Counterfactual/anchors'])}).")
    rows = [[k, EXP_SCOPE[k], len(v), C(v)] for k, v in sorted(X.items(), key=lambda x: -len(x[1]))]
    B.table(f"Explanation families among the {ln('EV')} included studies with explanation evidence of tier A1, A2 or B (multi-label)",
            ['Familyᵃ', 'Scope', 'n', 'Studies'], rows, widths=[2.8, 4.2, 0.8, 8.2],
            footnote='ᵃ Feature selection, principal-component variance, learning curves, t-SNE and latent-space plots, chi-square or mutual-information '
                     'ranking and similar items were not counted as explanation. Studies whose extraction formats conflict on explanation are not counted')
    B.figure(FIG + r'\Fig6.png', f"Explanation families among the {ln('EV')} included studies with explanation evidence (a) and evidence tier of "
             f"all {n} included studies (b). A1: established technique; A2: attention-based explanation; B: model-derived feature importance only; "
             "Conflict: the two extraction formats disagree; None: no qualifying item. A study can carry several family labels. Evidence-derived "
             "figure computed from Online Resource 1", 16.5)
    B.p(f"**Assessment of explanation quality.** Few studies are recorded as testing the explanation itself. Among the {ln('A12')} studies of "
        f"tier A1 or A2, the extraction records an assessment of explanation quality for {ln('quality_A12')} {C(N['quality_A12'])}. The records "
        "describe the stronger cases as follows. Faithfulness, sensitivity and complexity metrics are used to compare LIME and SHAP [[95]]; "
        "feature-removal fidelity and stability scores are reported for SHAP [[52]]; fidelity is measured by masking the top-ranked features and "
        "stability by bootstrap Jaccard overlap [[193]]; four techniques are compared on a recurrent detector, with gradient-based methods "
        "faster than sampling-based ones and one of them more faithful [[96]]; and SHAP and LIME are audited for completeness and robustness "
        "under adversarial perturbation [[142]]. Several of these tests return cautionary findings: LIME-based feature selection is unstable "
        "across random seeds and at small feature counts [[192]]; features ranked highly by SHAP or LIME on one model often fail to carry over "
        "to another classifier, post-hoc techniques can mislead when features are correlated, and Kernel SHAP rankings vary across seeds "
        "[[182]]; and LIME can assign high importance to synthetic dummy features [[142]]. For several of the other studies, the extraction "
        "only lists a quality-related metric or states the aim, and the strength of the assessment cannot be judged. The extractions also record "
        "the cost of explanation: the combined computation of SHAP and LIME during real-time inference [[87]], the computational intensity of "
        "Deep SHAP for convolutional models [[147]], and Kernel SHAP latencies above 15 s per sample against below 0.01 s for TreeSHAP [[182]].")
    B.p(f"**Observations** (denominator {n} unless stated).")
    B.bullets([
        f"SHAP ({len(X['SHAP'])} of {ln('EV')}) and LIME ({len(X['LIME'])}) dominate; gradient-based ({len(X['Gradient-based'])}) and counterfactual "
        f"({len(X['Counterfactual/anchors'])}) techniques are each evidenced for few studies.",
        f"Tiers: {ET['A1']} A1, {ET['A2']} A2 (attention-based) and {ET['B']} B.",
        f"An assessment of explanation quality is evidenced in the extraction for {ln('quality_A12')} of {ln('A12')} A1 or A2 studies.",
        f"Attention-based explanation is the only explanation in {ET['A2']} studies, and the extractions rarely describe a validation of attention "
        "weights as explanations.",
    ])
    B.p("**Discussion and Comments.** *Interpretation.* Most studies apply an explanation technique and display its output. The studies that "
        "do test explanations report instability, disagreement between techniques and sensitivity to the background distribution, which "
        "agrees with evaluations of explanation methods in security outside this corpus [[bg:warnecke2020]]. This suggests that explanation "
        "output alone is weak evidence of explainability. The choice of technique also carries a computational trade-off that the corpus "
        "rarely makes explicit: exact tree-specific Shapley values and gradient methods are cheap, model-agnostic Kernel SHAP and LIME are "
        "expensive and stochastic, and attention weights are free but contested as explanations.")
    B.p(f"**Limitations.** Families were assigned by keyword rules and, for some extraction items, by hand. That a quality assessment is not "
        f"evidenced in an extraction does not show that the paper omits it; the revision audit found six such misses in the original "
        f"curation, so further misses are possible. {ET['U']} studies conflict between formats and are not counted.")

    # ---------------- 4.5 RQ4
    B.h(2, '4.5 RQ4: imbalance handling and explainability together')
    B.p(f"**Scope and denominator.** RQ4 is the central question: to what extent the two are addressed together and how explanations are "
        f"evaluated. Denominator: {n}, partitioned in Table 12. {ln('both')} studies are confirmed to report both an explicit imbalance-handling method (tier M) "
        f"and an explicit explanation technique (tier A1 or A2; {len(N['bothA1'])} A1, {len(N['bothA2'])} A2). {ln('cand_one') + ln('cand_both')} "
        f"further studies are candidates: {ln('cand_one')} conflict on one dimension while the other is positive, and {ln('cand_both')} conflict on "
        f"both. The central result is therefore {ln('both')} confirmed and {ln('cand_one') + ln('cand_both')} unresolved. The count is provisional: if every candidate conflict were resolved in favour of "
        f"inclusion it could rise to at most {ln('both') + ln('cand_one') + ln('cand_both')}, and it could also fall if tier assignments change.")
    B.table(f'Status of the {n} included studies with respect to imbalance mitigation and explanation (tiers are defined in Section 2.8). '
            'Assigned from the extractions; candidate rows are conflict-sensitive and are counted neither for nor against',
            ['Group', 'n', 'Studies'], [
        ['Explicit imbalance method and explicit explanation technique', ln('both'), 'Table 14'],
        ['Candidate: extraction conflict on one dimension, the other positive', ln('cand_one'), C(N['cand_one'])],
        ['Candidate: extraction conflict on both dimensions', ln('cand_both'), C(N['cand_both'])],
        ['Explicit imbalance method; model-derived feature importance only', ln('M_FIonly'), C(N['M_FIonly'])],
        ['Explicit imbalance method; no explanation evidence', ln('M_noexp'), 'Online Resource 1'],
        ['Explanation evidence; no confirmed imbalance method', ln('exp_noM'), C(N['exp_noM'])],
        ['Neither dimension evidenced', ln('neither'), C(N['neither'])],
        ['Total included studies', N['table12_sum'], ''],
    ], widths=[7.0, 0.8, 8.2])
    P = N['pairs']
    pl = lambda a, b: len(P.get(f'{a}|{b}', []))
    BA = N['both_arch']; BD = N['both_ds']
    B.p(f"**Which techniques are combined.** Fig. 7 and Table 13 show the pairings. Loss-level mitigation with SHAP is the commonest pair "
        f"({pl('Loss/cost-sensitive', 'SHAP')} studies), followed by loss-level mitigation with LIME ({pl('Loss/cost-sensitive', 'LIME')}) and with "
        f"attention-based explanation ({pl('Loss/cost-sensitive', 'Attention')}), resampling with SHAP ({pl('Random/other resampling', 'SHAP')}), "
        f"loss-level mitigation with model-derived importance ({pl('Loss/cost-sensitive', 'Model-derived FI')}) and SMOTE-family oversampling with "
        f"SHAP ({pl('SMOTE family', 'SHAP')}). Generative synthesis is paired with SHAP in {pl('Generative synthesis', 'SHAP')} studies and with "
        f"attention-based explanation in {pl('Generative synthesis', 'Attention')}. By architecture the {ln('both')} studies include attention-based "
        f"designs ({BA['Transformer/attention']}), generic deep networks ({BA['MLP/DNN/ANN']}), convolutional ({BA['CNN']}) and recurrent models "
        f"({BA['RNN/LSTM/GRU']}), with smaller numbers of generative ({BA['GAN-based']}) and federated designs ({BA['Federated']}). Among those "
        f"without a dataset-identity conflict ({N['both_dsok']}), CIC-IDS2017 ({BD['CIC-IDS2017']}), UNSW-NB15 ({BD['UNSW-NB15']}) and NSL-KDD "
        f"({BD['NSL-KDD']}) are named most often, and {N['both_unnamed']} name no specific dataset. Table 14 lists every one of the {ln('both')} studies.")
    B.figure(FIG + r'\Fig7.png', f"Pairings of mitigation family (rows) and explanation family (columns) among the {ln('both')} studies reporting "
             "both an explicit imbalance method and an explicit explanation technique. Cell values count studies; a study can contribute to several "
             "cells. Attn: attention-based explanation; FI: model-derived feature importance; Rule: rules, surrogates or intrinsic designs; Grad: "
             "gradient-based; CF: counterfactual or anchors. Evidence-derived figure computed from Online Resource 1", 12.5)
    rows = [[a, b, len(v), C(v)] for k, v in sorted(P.items(), key=lambda x: (-len(x[1]), x[0])) if len(v) >= 4 for a, b in [k.split('|')]]
    B.table(f"Most frequent pairings of mitigation family and explanation family among the {ln('both')} explicit-both studies (pairs with four or "
            "more studies; multi-label)", ['Mitigation family', 'Explanation family', 'n', 'Studies'], rows, widths=[3.6, 3.2, 0.8, 8.4])
    B.table(f"The {ln('both')} confirmed studies reporting both an explicit imbalance method and an explicit explanation technique, by explanation "
            f"tier (assigned from the extractions; the {ln('cand_one') + ln('cand_both')} unresolved candidates are listed in Table 12)",
            ['Tier', 'n', 'Studies'], [['A1 (established technique)', len(N['bothA1']), C(N['bothA1'])],
                                        ['A2 (attention-based explanation)', len(N['bothA2']), C(N['bothA2'])]], widths=[4.0, 0.8, 11.2])
    qb, mi, mx, csb = set(N['quality_both']), set(N['minority_indirect']), set(N['minority_explicit']), set(N['cs_both'])
    B.p(f"**How are explanations evaluated?** Among the {ln('both')} studies, the extractions evidence an assessment of explanation quality for "
        f"{len(qb)} and list a class-sensitive detection metric for {len(csb)}. Only {w(len(qb & csb))} {C(sorted(qb & csb))} evidence both, "
        "so in most of the group either the detector's minority-class behaviour or the explanation's quality cannot be judged from the "
        "extraction. Detection is evaluated with each study's own metric set, and explanation is mostly shown through plots. This describes what "
        "the extractions record and not necessarily what the papers contain.")
    B.p(f"**Are minority-class predictions explained?** The extractions tie an explanation to rare or minority classes explicitly for "
        f"{len(mx)} of the {ln('both')} studies {C(sorted(mx))} and indirectly for {len(mi)} {C(sorted(mi))}, for example when SHAP-guided feature "
        f"selection is reported to preserve minority-class performance. For the other {ln('both') - len(mx) - len(mi)} studies the extractions "
        f"evidence no such link. {w(len((mx | mi) & qb)).capitalize()} studies {C(sorted((mx | mi) & qb))} evidence both a minority-class "
        f"explanation and an explanation-quality assessment, and one [[191]] also lists a class-sensitive metric, though its minority link is "
        "indirect. Table 15 lists every study in the group with any such evidence. Examples show the range. One study applies SMOTE and explains "
        "its models with SHAP, LIME and random-forest importance, and records that LIME-based selection became unstable [[192]]. One combines "
        "GAN-generated minority samples with LIME and records training instability and a risk of mode collapse among its limitations [[83]]. "
        "One combines cost-sensitive re-weighting with Deep SHAP and TreeSHAP and records minority-class-specific SHAP summary plots [[147]]. "
        "One combines meta-learning sample scoring, which expands only difficult minority samples, with attention-based relevance scoring "
        "computed separately for rare and majority classes [[93]].")
    rows = []
    for r in sorted(qb | mx | mi):
        fams = '; '.join(SHORT.get(f, f) for f in S[r]['exp'])
        q, m = QM[r]
        rows.append([C([r]), fams, q, m, 'yes' if S[r]['ind']['class_sensitive'] else '–'])
    B.table(f"Explicit-both studies for which the extraction records an assessment of explanation quality or an explanation tied to minority "
            "classes. Entries describe what the extraction states (curated record by record) and are not verified against the papers; the counts are "
            "absence-sensitive and have low to moderate confidence (Table 6)",
            ['Studyᵃ', 'Explanation family', 'Explanation-quality evidence', 'Minority-class explanation', 'Class-sensitive metric'], rows,
            widths=[1.3, 2.6, 5.0, 5.4, 1.7],
            footnote='ᵃ For the other studies in this group the extraction evidences neither item; absence in the extraction is not evidence of absence in the paper')
    B.p("**Explanation under imbalance without a mitigation method.** Studies outside the group bear directly on RQ4. One records that "
        "imbalanced background sets in Kernel SHAP skew Shapley values towards majority-class features [[182]], and one that explanations for "
        "highly imbalanced classes are less stable under adversarial perturbation [[142]]. Both sit outside the explicit-both group as defined, "
        "and both match the analytical points (b) and (c) of Section 3.5.")
    B.p("**Does explanation feed back into mitigation?** One study uses explanation to decide where mitigation is needed: a SHAP-guided loop "
        "identifies weak minority classes and drives retraining, and its limitations record added training time before deployment [[63]]. The "
        "extractions describe no other study in which explanation output changes the mitigation, and none that compares explanations before "
        "and after mitigation.")
    B.p(f"**Observations** (denominator {n} unless stated).")
    B.bullets([
        f"{ln('both')} studies are confirmed to report both an explicit imbalance-handling method and an explicit explanation technique; "
        f"{ln('cand_one') + ln('cand_both')} more are unresolved because their extraction formats conflict.",
        f"Loss-level mitigation with SHAP is the commonest pairing ({pl('Loss/cost-sensitive', 'SHAP')} of {ln('both')}).",
        f"Among the {ln('both')}: explanation-quality assessment is evidenced for {len(qb)}; a class-sensitive metric for {len(csb)}; both for "
        f"{len(qb & csb)}; an explanation tied to minority classes explicitly for {len(mx)} and indirectly for {len(mi)}.",
        "The extractions describe one study that uses explanation to guide mitigation and none that compares explanations before and after mitigation.",
    ])
    B.p(f"**Discussion and Comments.** *Interpretation.* Most of the {ln('both')} studies join a mitigation step and an explanation technique as "
        "separate modules, and the extractions give little sign that the two are examined together. Section 3.5 gives four reasons why they "
        "should be: mitigation changes the explained function, post-hoc explainers depend on a background distribution that mitigation can "
        "change, pooled global summaries are weighted by class prevalence, and explanations computed on synthetic samples describe synthetic "
        "regions. The corpus contains isolated observations consistent with two of these [[182,201,142]] and no study that tests any of them "
        "systematically. The presence of a mitigation method and of an explanation technique does not by itself establish robustness or "
        f"explanation quality, so none of the {ln('both')} studies is described here as imbalance-robust or as explainable in a validated sense.")
    B.p(f"**Limitations.** The count of {ln('both')} depends on tier assignment and on the agreement rule. The minority-class and "
        "explanation-quality entries come from record-by-record curation of the extractions, extended by a systematic scan during revision. Whether "
        "explanations were computed on resampled or raw data cannot be extracted for any study. The revision audit changed "
        f"{len(N['audit_removed']) + ln('audit_changed')} of {N['audit_examined']} records ({pct(len(N['audit_removed']) + ln('audit_changed'), N['audit_examined'])}; "
        "Section 2.7); an error of that order in either direction, together with the unresolved candidates, bounds how far the central counts "
        "can be trusted.")
    SE = N['sens']
    B.p(f"**Sensitivity of the central counts.** The counts were recomputed without the {len(N['preprints'])} preprints or deposits without peer "
        f"review {C(N['preprints'])} and without the {ln('genOnly')} studies whose deep component only generates samples or encodes features. "
        f"Without the preprints, {SE['no_preprints']['M']} of {SE['no_preprints']['n']} studies report an explicit mitigation method, "
        f"{SE['no_preprints']['both']} are explicit-both, {SE['no_preprints']['quality']} of these evidence explanation quality and "
        f"{SE['no_preprints']['quality_cs']} evidence both quality and a class-sensitive metric. Without the generative-or-encoding studies the "
        f"figures are {SE['no_genOnly']['M']} of {SE['no_genOnly']['n']}, {SE['no_genOnly']['both']}, {SE['no_genOnly']['quality']} and "
        f"{SE['no_genOnly']['quality_cs']}; without both groups they are {SE['neither']['M']} of {SE['neither']['n']}, {SE['neither']['both']}, "
        f"{SE['neither']['quality']} and {SE['neither']['quality_cs']}. Removing either group changes no finding: loss-level reweighting and SHAP "
        f"remain the dominant families, and joint evidence of explanation quality and minority-class behaviour remains rare.")

    # ---------------- 4.6 RQ5
    B.h(2, '4.6 RQ5: methodological and evaluation gaps')
    B.p(f"**Scope and denominators.** RQ5 asks what methodological and evaluation gaps are evidenced. All entries are indicators (Section 2.9). "
        f"Denominator {n} unless stated; dataset indicators use the {ln('dsok')} studies without a dataset-identity conflict. Table 16 and Fig. 8 "
        "summarise them. Limitations recorded in the extractions are distinguished from gaps seen by comparing studies.")
    ind = [
        ['Panel A. Dataset labels and indicators checked record by record (each keyword hit read in context)', '', '', ''],
        ['Uses KDD Cup 99 or NSL-KDD', 'dataset labels', f"{ln('kdd_any')} of {ln('dsok')}", ex(N['kdd_any'], 8)],
        ['Only KDD Cup 99 or NSL-KDD named', 'dataset labels', f"{ln('kdd_only')} of {ln('dsok')}", ex(N['kdd_only'], 8)],
        ['A single named dataset family', 'dataset labels', f"{ln('single_named')} of {ln('dsok')}", ex(N['single_named'], 8)],
        ['Two or more named dataset families', 'dataset labels', f"{ln('multi_named')} of {ln('dsok')}", ex(N['multi_named'], 8)],
        ['Trained on one dataset and tested on another', 'checked record by record', f"{ln('h_transfer_eval')} of {n}", C(N['h_transfer_eval'])],
        ['Held-out unseen attack types evaluated', 'checked record by record', f"{ln('h_unseen_attack_eval')} of {n}", C(N['h_unseen_attack_eval'])],
        ['Train–test (evaluation) leakage discussed', 'checked record by record', f"{ln('h_eval_leakage')} of {n}", C(N['h_eval_leakage'])],
        ['Leakage-safe or training-only resampling stated', 'checked record by record', f"{ln('h_leak_safe_resampling')} of {n}", C(N['h_leak_safe_resampling'])],
        ['Hardware or testbed evaluation', 'checked record by record', f"{ln('h_hardware_eval')} of {n}", C(N['h_hardware_eval'])],
        ['Adversarial-robustness evaluation', 'checked record by record', f"{ln('h_adversarial_eval')} of {n}", C(N['h_adversarial_eval'])],
        ['Code released', 'checked record by record', f"{ln('h_code_release')} of {n}", C(N['h_code_release'])],
        ['Panel B. Keyword-only indicators (unknown precision and recall; not context-verified; no conclusion rests on them alone)', '', '', ''],
        ['Repeated evaluation or statistical testing', 'keyword', f"{ln('ind_stat_rigor')} of {n}", ex(N['ind_stat_rigor'], 8)],
        ['Computational cost measured', 'keyword', f"{ln('ind_cost_measured')} of {n}", ex(N['ind_cost_measured'], 8)],
    ]
    B.table('Extraction-based indicators of evaluation and reporting practice, in two panels by evidentiary strength. A positive entry means '
            'that the practice is described in the extraction outside the future-work and limitation fields; a negative entry means only that it '
            'is not evidenced in the extraction. Dataset indicators exclude the studies with a dataset-identity conflict. Lists longer than ten '
            'show the first eight studies',
            ['Indicator', 'Method', 'n of denominator', 'Studies'], ind, widths=[5.0, 2.2, 2.4, 6.4])
    B.figure(FIG + r'\Fig8.png', 'Extraction-based indicators of evaluation and reporting practice, each as a share of the stated denominator '
             'with the count beside the bar. Indicators checked record by record were read in context; cost and statistical testing are keyword-only '
             'indicators with unknown precision and recall. None has been '
             'verified in the papers. Evidence-derived figure computed from Online Resource 1', 16)
    B.p(f"**Benchmarks and generalisation.** KDD Cup 99 or NSL-KDD are used by {ln('kdd_any')} of {ln('dsok')} studies and are the only named "
        f"families in {ln('kdd_only')}; {ln('single_named')} name a single dataset family. Although {ln('multi_named')} studies name two or more "
        f"families, a model trained on one dataset and tested on another is described in only {ln('h_transfer_eval')} "
        f"{C(N['h_transfer_eval'])}, and an evaluation on held-out unseen attack types in {ln('h_unseen_attack_eval')}. Evaluating on several "
        "datasets separately shows breadth, not transfer.")
    B.p(f"**Leakage and protocol.** Train–test leakage is discussed in {ln('h_eval_leakage')} extractions, and resampling is stated to be "
        f"restricted to the training data, or leakage-safe, in {ln('h_leak_safe_resampling')} {C(N['h_leak_safe_resampling'])}. This does not show "
        "that leakage occurred elsewhere. It shows that the order of splitting and resampling is rarely visible in the extractions, which "
        "matters because oversampling before the split inflates minority-class results [[bg:kapoor2023,bg:arp2022]]. Repeated evaluation or "
        f"statistical testing (including k-fold cross-validation) appears in {ln('ind_stat_rigor')} extractions and code release in "
        f"{ln('h_code_release')}.")
    L = N['limitations']
    B.p(f"**Cost and deployment.** Measured computational cost (training or inference time, latency, parameter count, memory or model size) "
        f"appears in the metrics or findings of {ln('ind_cost_measured')} extractions, but an evaluation on embedded hardware or a testbed is "
        f"described in only {ln('h_hardware_eval')}: an emulated software-defined-networking testbed [[37]] and embedded edge boards [[76,110]]. "
        f"The limitations recorded in the extractions point the same way: computational cost or latency for {L['cost/latency']}, rare-class "
        f"difficulty for {L['rare-class difficulty']}, hyperparameter sensitivity for {L['hyperparameter sensitivity']}, limited or "
        f"single-dataset evaluation for {L['limited/single-dataset evaluation']}, synthetic-data quality for {L['synthetic-data quality']}, an "
        f"explanation or interpretability gap for {L['explanation/interpretability gap']} and absent real-world validation for "
        f"{L['no real-world validation']} (keyword categories of the limitation fields; a study can record several). Related reviews, per "
        "their extractions, report reliance on legacy or simulated datasets and absent live validation [[4,12,29,106,162,211]], and inconsistent "
        "evaluation procedures and metric reporting [[9,11,18,64]].")
    B.p(f"**Observations** (denominator {n} unless stated).")
    B.bullets([
        f"Legacy benchmarks are evidenced for {ln('kdd_any')} of {ln('dsok')} studies and a single dataset family for {ln('single_named')}.",
        f"Transfer between datasets is described in {ln('h_transfer_eval')} and held-out unseen-attack evaluation in {ln('h_unseen_attack_eval')}.",
        f"Evaluation leakage is discussed in {ln('h_eval_leakage')}; leakage-safe or training-only resampling is stated in {ln('h_leak_safe_resampling')}.",
        f"Computational cost is measured in {ln('ind_cost_measured')}; hardware or testbed evaluation is described in {ln('h_hardware_eval')}; code "
        f"release is indicated in {ln('h_code_release')}.",
        f"Limitations recorded in the extractions are dominated by computational cost ({L['cost/latency']}).",
    ])
    B.p("**Discussion and Comments.** *Interpretation.* The limitations recorded by the studies concern cost and data; the gaps seen by "
        "comparing studies concern reporting and protocol. Five stand out: few class-sensitive metrics among the mitigation studies, little "
        "evidence of explanation-quality assessment, little documentation of the split-then-resample order, almost no transfer or hardware "
        "evaluation, and scarce code release. They matter jointly. A result on a legacy benchmark, with accuracy as the main metric, an "
        "unstated resampling order and no explanation assessment, supports little about deployment. Related reviews describe similar concerns "
        "about datasets and metrics, so these gaps are not peculiar to this corpus, but the counts here describe the corpus only and are "
        "indicators, not verified findings.")
    B.p("**Limitations.** Keyword indicators have unmeasured precision and recall; checked record by record indicators were read once by one assessor. "
        "Indicators were computed from the evidence-describing fields only, so studies that report a practice only in a field excluded from the "
        "scan are missed. Online Resource 7 compares these values with those of the original indicator scripts.")

    # ---------------- 4.7
    B.h(2, '4.7 Computational perspective on the evidence')
    st = N['stage']
    B.p("This subsection reads the same evidence through the computational pipeline. It adds no new studies and no numerical comparison of "
        "methods: the groupings are assigned from the family labels, the counts overlap, and the indicators are those of Section 4.6.")
    B.p(f"**Where mitigation acts.** The mitigation families act at different points of the training pipeline (Table 17). Data-level methods "
        f"({st['Data level']['n']} studies) change the training set before the model sees it, which is why the order of splitting and "
        f"resampling matters; the extractions state leakage-safe or training-only resampling for {st['Data level']['train_only']} of them and "
        f"discuss evaluation leakage for {st['Data level']['leakage']}. Loss-level methods ({st['Training objective']['n']}) change the training "
        f"objective and leave the data untouched. Learning formulations ({st['Learning formulation']['n']}), ensembles ({st['Ensemble']['n']}) "
        f"and decision-rule adjustments ({st['Decision rule']['n']}) act through the model structure, the combination of models and the final "
        f"threshold. Computational cost is recorded as a limitation for {st['Data level']['cost_lim']} data-level and "
        f"{st['Training objective']['cost_lim']} loss-level studies, but this is a limitation recorded by the papers and not a measured "
        "comparison.")
    EXPL = {'Data level': 'Training distribution and the explained function change; a background set drawn from resampled data, or '
                          'synthetic samples, alters the reference and can place attributions in synthetic regions (Section 3.5 a, b, d)',
            'Training objective': 'Explained function changes through the weights; data and background distribution are untouched; '
                                  'weights act in expectation only and fade once training data are separated (Section 3.2)',
            'Learning formulation': 'Representation and, for federated rebalancing, client weighting change; background sets must match '
                                    'the deployed representation',
            'Ensemble': 'Explained function is the combination; explaining one member does not explain the ensemble',
            'Decision rule': 'Scores and therefore attributions are unchanged; only the decision changes, so explanations of the score '
                             'can disagree with the final label',
            'Explanation-guided': 'Explanation output selects what is retrained, so the explained function and the explanation are coupled'}
    B.table(f"Where the {MT['M']} explicit mitigation methods act in the training pipeline, what each stage changes for a post-hoc explainer, "
            "and indicators for the studies concerned (assigned from the family labels; a study can appear in several rows; the "
            "consequence column is analytical, from Section 3, and not a corpus count)",
            ['Stage', 'Families', 'Consequence for a post-hoc explainer', 'n', 'Leakage-safe resampling stated', 'Evaluation leakage discussed',
             'Cost recorded as limitation', 'Class-sensitive metric listed'], [
        [k, fam, EXPL[k], v['n'], v['train_only'], v['leakage'], v['cost_lim'], v['cs']] for k, fam in [
            ('Data level', 'resampling, SMOTE family, generative synthesis'), ('Training objective', 'loss-level and cost-sensitive learning'),
            ('Learning formulation', 'few-shot, contrastive, one-class, federated rebalancing'), ('Ensemble', 'boosting, bagging, stacking, voting'),
            ('Decision rule', 'threshold or calibration'), ('Explanation-guided', 'retraining guided by explanation output')] for v in [st[k]]
    ], widths=[1.9, 2.6, 5.1, 0.8, 1.4, 1.4, 1.4, 1.4], size=7.5)
    ea = N['exp_app']
    B.p(f"**Where explanation acts.** Explanation techniques differ in when they are computed (Table 18). Post-hoc attribution and "
        f"counterfactual techniques ({ea['post-hoc']['n']} studies) are computed on a trained model for each prediction or for a sample of "
        f"predictions, so their cost adds to inference and analysis time; in-model or intrinsic signals (attention weights, model-derived "
        f"importance and rules; {ea['in-model']['n']} studies) come from the model itself. An assessment of explanation quality is evidenced for "
        f"{ea['post-hoc']['quality']} of the post-hoc and {ea['in-model']['quality']} of the in-model studies, and cost appears among the "
        f"recorded limitations of {ea['post-hoc']['cost_lim']} and {ea['in-model']['cost_lim']} studies respectively.")
    B.table(f"How the explanation techniques of the {ln('EV')} studies with explanation evidence are applied, with indicators for the studies "
            "concerned (assigned from the family labels; a study can appear in both rows)",
            ['Application', 'Families', 'n', 'Explanation-quality evidence', 'Cost recorded as limitation', 'Hardware or testbed evaluation'], [
        ['Post-hoc attribution or counterfactual', 'SHAP, LIME, gradient-based, counterfactual', ea['post-hoc']['n'], ea['post-hoc']['quality'], ea['post-hoc']['cost_lim'], ea['post-hoc']['edge']],
        ['In-model or intrinsic signal', 'attention weights, model-derived importance, rules', ea['in-model']['n'], ea['in-model']['quality'], ea['in-model']['cost_lim'], ea['in-model']['edge']],
    ], widths=[3.4, 4.6, 0.9, 2.4, 2.4, 2.3])
    B.p("**What the evidence does not allow.** The extractions rarely report training time, parameter counts, inference latency or explanation "
        "latency in a comparable form, so no comparison of computational cost across methods is possible and none is attempted. Closing this "
        "gap needs the full texts of the studies, from which training and inference cost, hardware and explanation latency could be extracted "
        "under a common protocol; it is listed among the evidence still needed in Section 9.")
