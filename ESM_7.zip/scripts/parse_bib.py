import re, json
src = r'C:\Users\tarun\Desktop\MtechPurva\Combined_Literature_Analysis.md'
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
t = open(src, encoding='utf-8').read()
i = t.find('# REFERENCES:')
bt = t[i:]
entries = re.split(r'\n(?=@\w+\{)', bt)[1:]
bib = []
for e in entries:
    m = re.match(r'@(\w+)\{([^,]+),', e)
    typ, key = m.group(1), m.group(2)
    f = {}
    for fm in re.finditer(r'\n\s*(\w+)\s*=\s*\{(.*?)\}\s*,?\s*(?=\n\s*\w+\s*=|\n\}|$)', e, re.S):
        f[fm.group(1).lower()] = re.sub(r'\s+', ' ', fm.group(2)).strip()
    idm = re.match(r'(\d+)([a-z]?)', key if key[0].isdigit() else '232' + key)
    bib.append(dict(key=key, type=typ, pid=int(idm.group(1)), suffix=idm.group(2), **f))
print('bib entries', len(bib))
ids = [b['pid'] for b in bib]
from collections import Counter
c = Counter(ids)
print('repeated pid', {k: v for k, v in c.items() if v > 1})
print('max', max(ids))
print('absent in 1..265:', [k for k in range(1, 266) if k not in c])
json.dump(bib, open(W + r'\bib.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
for b in bib:
    if b['pid'] in (1, 50, 56, 57, 85, 86, 98, 101, 103, 144, 165, 203, 204, 205, 229, 230, 249, 255):
        print(b['key'], '|', b.get('title','')[:80], '|', b.get('doi',''))
