import re, json, sys
src = r'C:\Users\tarun\Desktop\MtechPurva\Combined_Literature_Analysis.md'
out = sys.argv[1]
lines = open(src, encoding='utf-8').read().split('\n')
pat = [
    re.compile(r'^#{2,3}\s*Paper\s+\d+\s*:\s*Paper\s+(\d+)\b(.*)$'),          # batch6
    re.compile(r'^#{2,3}\s*Paper\s+ID\s+(\d+)\s*[—\-:–]+\s*(.*)$'),
    re.compile(r'^#{2,3}\s*Paper\s+(\d+)\s*[:—\-–]\s*(.*)$'),
]
starts = []
for i, l in enumerate(lines):
    for p in pat:
        m = p.match(l)
        if m:
            starts.append((i, int(m.group(1)), m.group(2).strip()))
            break
# any other top-level headings define boundaries too
bounds = set(s[0] for s in starts)
for i, l in enumerate(lines):
    if re.match(r'^#{1,2}\s', l) and i not in bounds:
        bounds.add(i)
bounds = sorted(bounds) + [len(lines)]
recs = {}
dups = []
for (i, pid, title) in starts:
    j = next(b for b in bounds if b > i)
    body = '\n'.join(lines[i:j])
    if pid in recs:
        dups.append((pid, i+1, recs[pid]['line']))
        recs[pid]['body'] += '\n' + body
        continue
    recs[pid] = dict(id=pid, line=i+1, title=title, body=body)
ids = sorted(recs)
print('n records parsed', len(ids), 'min', ids[0], 'max', ids[-1])
missing = [k for k in range(1, max(ids)+1) if k not in recs]
print('missing ids', missing, len(missing))
print('repeated headings', dups)
json.dump(recs, open(out, 'w', encoding='utf-8'), ensure_ascii=False)
