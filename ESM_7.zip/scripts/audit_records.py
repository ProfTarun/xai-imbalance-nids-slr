# Audit extraction records of manuscript-cited studies: paper type, review signals, short-vs-long author mismatch
import json, re
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
r2b = {int(k): v for k, v in json.load(open(W + r'\ref2bib.json')).items()}
bib = {b['key']: b for b in json.load(open(W + r'\bib.json', encoding='utf-8'))}
D = json.load(open(W + r'\ms_data.json'))
elig = set().union(*D['arch'].values())
reviews = {3, 4, 9, 11, 12, 18, 26, 29, 36, 49, 64, 69, 89, 103, 106, 128, 129, 150, 157, 162, 164, 188, 197, 207, 211}
unres = {33, 177, 56, 105, 82, 32, 31, 1, 60, 117, 205, 120}
rows = []
for n, v in sorted(r2b.items()):
    md = v['md']
    body = recs[md]['body'] if md else ''
    ptype = re.search(r'Paper type\**\s*:?\**\s*([^\n]*)', body)
    ptype = ptype.group(1).strip(' *.') if ptype else ''
    rev_words = len(re.findall(r'\b(systematic review|literature review|survey|this review|reviews? \d+ (?:papers|studies)|we review)\b', body[:6000], re.I))
    short_auth = re.search(r'Authors?(?: and| &) (?:Publication )?Year\**:?\**\s*\|?\s*([^\n|]*)', body)
    short_auth = short_auth.group(1).strip() if short_auth else ''
    bib_first = bib[v['bibkey']].get('author', '').split(' and ')[0].split(',')[0].strip().lower()
    auth_ok = (bib_first[:5] in short_auth.lower()) if short_auth and bib_first else None
    group = 'eligible' if n in elig else 'review' if n in reviews else 'unresolved' if n in unres else '??'
    rows.append(dict(ref=n, pid=v['pid'], md=md, group=group, ptype=ptype, rev_words=rev_words, short_auth=short_auth[:70], bib_first=bib_first, auth_ok=auth_ok,
                     title=bib[v['bibkey']].get('title', '')[:90]))
json.dump(rows, open(W + r'\audit_rows.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('groups', {g: sum(1 for r in rows if r['group'] == g) for g in set(r['group'] for r in rows)})
print('\n== eligible studies whose paper type or text signals a review/survey:')
for r in rows:
    if r['group'] == 'eligible' and (re.search(r'review|survey', r['ptype'], re.I) or r['rev_words'] >= 3):
        print(f"[{r['ref']}] P{r['md']} type='{r['ptype']}' revwords={r['rev_words']} | {r['title']}")
print('\n== eligible studies where short-summary author does not contain bib first author:')
for r in rows:
    if r['group'] == 'eligible' and r['auth_ok'] is False:
        print(f"[{r['ref']}] P{r['md']} bib='{r['bib_first']}' short='{r['short_auth']}' | {r['title'][:60]}")
