# Rebuild the original manuscript's study-level classification from the reference lists printed in its tables
import re, json
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
t = open(W + r'\main_fitz.txt', encoding='utf-8').read()
t = t[:t.rfind('\nReferences\n')]


def parse(s):
    nums = []
    for part in re.split(r',\s*', s.replace('\n', ' ')):
        part = part.strip()
        mm = re.match(r'(\d+)\s*[-\u2013]\s*(\d+)$', part)
        if mm:
            nums += list(range(int(mm.group(1)), int(mm.group(2)) + 1))
        elif part.isdigit():
            nums.append(int(part))
    return nums


allL = [(m.start(), parse(m.group(1))) for m in re.finditer(r'\[([\d,\s\-\u2013]+)\]', t)]
big = [L for L in allL if len(L[1]) >= 4]
B = lambda i: big[i][1]
D = {}
D['mitU'] = B(3); D['expU'] = B(4); D['dsConflict'] = B(5); D['noNumeric'] = B(6); D['genOnly'] = B(7)
arch = ['MLP/DNN/ANN', 'CNN', 'RNN/LSTM/GRU', 'Transformer/attention', 'GAN-based', 'Autoencoder/VAE', 'Federated', 'Meta/few-shot/contrastive']
D['arch'] = {a: B(8 + i) for i, a in enumerate(arch)}
D['arch']['GNN'] = [37, 43, 204]; D['arch']['Reinforcement learning'] = [20, 136, 170]; D['arch']['Other deep'] = [81, 115, 212]
ds = ['UNSW-NB15', 'NSL-KDD', 'CIC-IDS2017', 'CSE-CIC-IDS2018', 'KDD Cup 99', 'ToN-IoT', 'Bot-IoT', 'Edge-IIoTset', 'CIC-IoT2023']
D['ds'] = {a: B(17 + i) for i, a in enumerate(ds)}
D['ds']['CIC-DDoS2019'] = [14, 182, 215]; D['ds']['Other IoT/IIoT'] = B(26); D['ds']['In-vehicle'] = [125, 137, 145]
D['ds']['ICS/SCADA/power'] = [6, 47, 185]; D['ds']['Other named'] = B(27); D['ds']['Other/custom/synthetic'] = [116, 170, 199]
D['ds']['Unnamed benchmark'] = B(28); D['ds']['Unnamed'] = [171]
D['mitW'] = [158, 170, 200]; D['mitN'] = B(30)
mit = ['Loss/cost-sensitive', 'Random/other resampling', 'Generative synthesis', 'SMOTE family']
D['mit'] = {a: B(32 + i) for i, a in enumerate(mit)}
D['mit']['Ensemble/boosting'] = [24, 88, 210]; D['mit']['Few-shot/contrastive'] = B(36); D['mit']['Federated-specific'] = B(37)
D['mit']['Threshold/calibration'] = B(38); D['mit']['Explanation-guided'] = [63]
exp = ['SHAP', 'LIME', 'Model-derived FI', 'Attention', 'Rules/surrogate/intrinsic', 'Gradient-based']
D['exp'] = {a: B(39 + i) for i, a in enumerate(exp)}
D['exp']['Counterfactual/anchors'] = [110, 204]
D['expQuality'] = [52, 87, 88, 95, 96, 142, 147, 182, 192, 193, 196, 201]
D['minorityExplicit'] = [63, 93, 147, 196]; D['minorityIndirect'] = [6, 58, 83, 191, 192]
D['bothA1'] = B(61); D['bothA2'] = B(62)
pairs = [('Loss/cost-sensitive', 'SHAP'), ('Loss/cost-sensitive', 'LIME'), ('Random/other resampling', 'SHAP'), ('Loss/cost-sensitive', 'Attention'),
         ('Loss/cost-sensitive', 'Model-derived FI'), ('SMOTE family', 'SHAP'), ('Random/other resampling', 'Model-derived FI'), ('Random/other resampling', 'LIME'),
         ('SMOTE family', 'Model-derived FI'), ('Generative synthesis', 'LIME'), ('Generative synthesis', 'SHAP'), ('Generative synthesis', 'Attention'),
         ('SMOTE family', 'LIME'), ('Loss/cost-sensitive', 'Rules/surrogate/intrinsic')]
D['pairs'] = {f'{a}|{b}': B(47 + i) for i, (a, b) in enumerate(pairs)}
json.dump(D, open(W + r'\ms_data.json', 'w'), indent=0)

U = lambda d: set().union(*d.values())
elig = U(D['arch'])
print('eligible (union arch)', len(elig))
tierM = U(D['mit'])
allmit = tierM | set(D['mitN']) | set(D['mitW']) | set(D['mitU'])
print('tier M', len(tierM), 'N', len(D['mitN']), 'W', len(D['mitW']), 'U', len(D['mitU']), 'sum', len(tierM) + len(D['mitN']) + len(D['mitW']) + len(D['mitU']), 'union', len(allmit), 'subset elig', allmit <= elig)
A1fam = ['SHAP', 'LIME', 'Rules/surrogate/intrinsic', 'Gradient-based', 'Counterfactual/anchors']
A1 = set().union(*[D['exp'][f] for f in A1fam])
A2 = set(D['exp']['Attention']) - A1
Bt = set(D['exp']['Model-derived FI']) - A1 - A2
print('A1', len(A1), 'A2', len(A2), 'B', len(Bt), 'exp evidence', len(A1 | A2 | Bt), 'expU', len(D['expU']), 'none', len(elig - A1 - A2 - Bt - set(D['expU'])))
print('expU overlaps exp evidence:', sorted(set(D['expU']) & (A1 | A2 | Bt)))
both = tierM & (A1 | A2)
print('explicit-both computed', len(both), 'listed', len(D['bothA1']) + len(D['bothA2']), 'diff', sorted(both ^ (set(D['bothA1']) | set(D['bothA2']))))
print('A1-both', len(tierM & A1), 'A2-both', len(tierM & A2))
dsall = U(D['ds'])
print('ds union', len(dsall), 'conflict', len(D['dsConflict']), 'overlap', sorted(dsall & set(D['dsConflict'])), 'missing', sorted(elig - dsall - set(D['dsConflict'])))
for k, v in D['arch'].items(): print(' arch', k, len(v))
for k, v in D['mit'].items(): print(' mit', k, len(v))
for k, v in D['exp'].items(): print(' exp', k, len(v))
print('quality among A1/A2', len(set(D['expQuality']) & (A1 | A2)), 'among both', len(set(D['expQuality']) & both))
print('minority any', len(set(D['minorityExplicit'] + D['minorityIndirect'])), 'in both', len(set(D['minorityExplicit'] + D['minorityIndirect']) & both))
mitUset, expUset = set(D['mitU']), set(D['expU'])
cand, fi_only, m_noexp, e_nom, neither = set(), set(), set(), set(), set()
for s in elig:
    m = s in tierM; e = s in (A1 | A2); b = s in Bt; mu = s in mitUset; eu = s in expUset
    if m and e:
        continue
    if (mu and e) or (eu and m):
        cand.add(s)
    elif m and b:
        fi_only.add(s)
    elif m:
        m_noexp.add(s)
    elif (e or b) and not mu:
        e_nom.add(s)
    else:
        neither.add(s)
print('Table12: both', len(both), 'cand', len(cand), 'FI only', len(fi_only), 'M no exp', len(m_noexp), 'exp no M', len(e_nom), 'neither', len(neither),
      'sum', len(both) + len(cand) + len(fi_only) + len(m_noexp) + len(e_nom) + len(neither))
print('M & expU (in m_noexp?)', sorted(tierM & expUset - (A1 | A2)))
