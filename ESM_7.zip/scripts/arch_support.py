# For each eligible study and each architecture label, test whether the long-form record supports it
import json, re
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
rows = {r['ref']: r for r in json.load(open(W + r'\audit_rows.json', encoding='utf-8'))}
D = json.load(open(W + r'\ms_data.json'))
KW = {
    'GAN-based': r'\bGANs?\b|generative adversarial|WGAN|CTGAN|BiGAN|ACGAN|CGAN',
    'Autoencoder/VAE': r'auto-?encoder|\bVAE|\bCVAE|\bAE\b|\bSAE\b|reconstruction',
    'Federated': r'federat',
    'GNN': r'graph neural|\bGNN|\bGCN|\bGAT\b|graph attention',
    'Reinforcement learning': r'reinforcement|\bDRL\b|\bDQN|Q-learning|replay',
    'Transformer/attention': r'transformer|attention|\bBERT|self-attention',
    'Meta/few-shot/contrastive': r'few-shot|meta-learn|contrastive|siamese|prototyp|self-supervised',
    'CNN': r'\bCNN|convolution|ResNet|Inception|VGG|AlexNet|TCN',
    'RNN/LSTM/GRU': r'LSTM|\bGRU|\bRNN|recurrent',
}


def long_part(body):
    i = body.find('### 1. Bibliographic')
    if i < 0:
        i = body.find('Bibliographic Information')
    return body[i:] if i >= 0 else ''


def short_part(body):
    i = body.find('### 1. Bibliographic')
    return body[:i] if i > 0 else body[:2500]


flags = []
for fam, refs in D['arch'].items():
    if fam not in KW:
        continue
    for ref in refs:
        b = recs[rows[ref]['md']]['body']
        L, S = long_part(b), short_part(b)
        inL = bool(re.search(KW[fam], L, re.I)); inS = bool(re.search(KW[fam], S, re.I))
        if not inL:
            flags.append((ref, fam, inS))
flags.sort()
print('labels not supported anywhere in long form:', len(flags))
for ref, fam, inS in flags:
    print(f'  [{ref}] P{rows[ref]["md"]} {fam} (in short: {inS}) | {rows[ref]["title"][:70]}')
json.dump(flags, open(W + r'\arch_flags.json', 'w'))
