import re, json, sys, pymupdf
doc = pymupdf.open(r'C:\Users\tarun\Desktop\MtechPurva\main.pdf')
txt = '\n'.join(p.get_text() for p in doc)
i = txt.rfind('\nReferences\n')
reftxt = txt[i:]
# remove page numbers lines
reftxt = re.sub(r'\n\d{1,2}\n', '\n', reftxt)
parts = re.split(r'\n\[(\d{1,3})\]\s', reftxt)
refs = {}
for k in range(1, len(parts), 2):
    n = int(parts[k]); body = parts[k+1].replace('\n', ' ')
    body = re.sub(r'\s+', ' ', body).strip()
    body = body.replace('https: //', 'https://').replace('/ s', '/s')
    refs[n] = body
print(len(refs), min(refs), max(refs))
json.dump(refs, open(sys.argv[1], 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
open(sys.argv[2],'w',encoding='utf-8').write(txt)
