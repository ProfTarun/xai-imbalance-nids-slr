# Compare each manuscript reference with Crossref metadata; classify as verified / corrected / unverifiable
import json, re, difflib, sys, unicodedata
sys.stdout.reconfigure(encoding='utf-8')
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
M = json.load(open(W + r'\mapping.json', encoding='utf-8'))
R = {int(k): v for k, v in M['R'].items()}
CR = json.load(open(W + r'\crossref.json', encoding='utf-8'))


def dehy(s): return re.sub(r'(\w)- (\w)', r'\1\2', s)
def strip_acc(s): return ''.join(c for c in unicodedata.normalize('NFKD', s) if not unicodedata.combining(c))
def norm(s): return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', strip_acc(dehy(s)).lower())).strip()
def sim(a, b): return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()


audit = {}
for n in sorted(R):
    r = R[n]; c = CR.get('ref' + str(n), {})
    raw = dehy(r['raw'])
    a = dict(ref=n, doi=r['doi'], title=dehy(r['title']), year=r['year'], issues=[])
    cr = c.get('cr')
    if r['doi'] and not cr:
        a['status'] = 'DOI not found in Crossref'; a['issues'].append('DOI did not resolve in Crossref (%s)' % c.get('err'))
        srch = c.get('search') or []
        if srch:
            best = max(srch, key=lambda m: sim(a['title'], m['title']))
            a['search_best'] = best; a['search_sim'] = round(sim(a['title'], best['title']), 2)
    elif cr:
        ts = sim(a['title'], cr['title'])
        a['cr'] = cr; a['title_sim'] = round(ts, 2)
        if ts < 0.85: a['issues'].append(f'title differs: CR="{cr["title"][:120]}"')
        cy = cr.get('published_print') or cr.get('year') or cr.get('published_online')
        years = {y for y in (cr.get('year'), cr.get('published_print'), cr.get('published_online')) if y}
        if r['year'] and int(r['year'][:4]) not in years: a['issues'].append(f'year {r["year"]} vs CR {sorted(years)}')
        fa = (cr['authors'][0] if cr['authors'] else '')
        ra = strip_acc(dehy(r['authors'])).split(',')[0].strip().split(' ')[0].lower()
        if fa and ra and strip_acc(fa).lower().split(' ')[-1][:5] not in strip_acc(dehy(r['authors'])).lower() and ra[:5] not in strip_acc(fa).lower():
            a['issues'].append(f'first author {r["authors"][:30]} vs CR {fa}')
        cont = cr.get('container') or ''
        if cont and sim(cont, raw) < 0.2 and norm(cont)[:20] not in norm(raw):
            # container name not found in raw reference
            words = [w for w in norm(cont).split() if len(w) > 3]
            if words and sum(w in norm(raw) for w in words) / len(words) < 0.5:
                a['issues'].append(f'venue differs: CR="{cont[:80]}"')
        if cr.get('volume') and not re.search(r'\b' + re.escape(str(cr['volume'])) + r'\b', raw):
            a['issues'].append(f'volume: CR {cr["volume"]}')
        if cr.get('page') and str(cr['page']).split('-')[0] not in raw:
            a['issues'].append(f'pages/article: CR {cr["page"]}')
        a['status'] = 'verified' if not a['issues'] else 'discrepancy'
    else:
        srch = c.get('search') or []
        if srch:
            best = max(srch, key=lambda m: sim(a['title'], m['title']))
            s = sim(a['title'], best['title'])
            a['search_best'] = best; a['search_sim'] = round(s, 2)
            a['status'] = 'no DOI; Crossref match found' if s > 0.85 else 'no DOI; not found in Crossref'
        else:
            a['status'] = 'no DOI; not found in Crossref'
    audit[n] = a
json.dump(audit, open(W + r'\ref_audit.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
from collections import Counter
print(Counter(a['status'] for a in audit.values()))
for n, a in audit.items():
    if a['status'] != 'verified':
        extra = ''
        if 'search_best' in a: extra = f" | SEARCH({a['search_sim']}): {a['search_best']['doi']} {a['search_best']['title'][:70]} ({a['search_best']['year']}) {a['search_best']['container'][:40]}"
        print(f"[{n}] {a['status']}: {'; '.join(a['issues'])}{extra}\n      REF: {a['title'][:90]} ({a['year']}) doi={a['doi']}")
