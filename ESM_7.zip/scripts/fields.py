# Split each extraction record into named fields (short format and long format)
import re

SHORT_KEYS = {
    'metrics': r'Evaluation Metrics',
    'findings': r'Main Findings',
    'limitations': r'Limitations',
    'future': r'Future Work',
    'imbalance': r'Class[- ]Imbalance',
    'xai': r'(?:Explainable AI|XAI)',
    'datasets': r'Datasets?',
    'technique': r'Proposed',
    'preprocessing': r'(?:Data )?Preprocessing',
}
LONG_KEYS = {
    'metrics': r'Evaluation Metrics',
    'findings': r'Main Findings',
    'limitations': r'Limitations',
    'future': r'Future Work',
    'imbalance': r'Class Imbalance',
    'xai': r'Explainable AI',
    'datasets': r'Dataset',
    'technique': r'Proposed Method',
    'setup': r'Experimental Setup',
    'preprocessing': r'Preprocessing',
    'conclusion': r'Conclusion',
    'contribution': r'Contribution',
}


def split_record(body):
    i = body.find('### 1. Bibliographic')
    if i < 0:
        i = body.find('Bibliographic Information')
    short = body[:i] if i > 0 else body
    long = body[i:] if i > 0 else ''
    f = {}
    # short format: lines beginning with a bold key
    lines = short.split('\n')
    cur = None
    for ln in lines:
        m = re.match(r'^\s*(?:\d+\.|[-*]|\|)\s*\*\*([^*]+?)\*\*', ln)
        if m:
            key = m.group(1)
            cur = None
            for k, pat in SHORT_KEYS.items():
                if re.match(pat, key.strip(), re.I) or re.search(pat, key, re.I) and k in ('limitations', 'metrics', 'findings', 'future'):
                    cur = 's_' + k
                    break
            if cur:
                f[cur] = f.get(cur, '') + ' ' + ln
            continue
        if cur and ln.strip().startswith(('*', '-', '  ')):
            f[cur] += ' ' + ln
        elif not ln.strip():
            pass
    # long format: ### N. Section
    parts = re.split(r'\n#{2,4}\s*\d+\.\s*', '\n' + long)
    for p in parts[1:]:
        head = p.split('\n', 1)[0]
        text = p.split('\n', 1)[1] if '\n' in p else ''
        for k, pat in LONG_KEYS.items():
            if re.match(pat, head.strip(), re.I):
                f['l_' + k] = f.get('l_' + k, '') + ' ' + text
                break
    f['all'] = body
    return f
