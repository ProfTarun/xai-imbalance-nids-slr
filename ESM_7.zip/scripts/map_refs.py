import re, json, sys, difflib
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
recs = json.load(open(W+r'\recs.json', encoding='utf-8'))
refs = json.load(open(W+r'\refs.json', encoding='utf-8'))
def norm(s):
    s = s.lower()
    s = re.sub(r'[^a-z0-9 ]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()
doi_re = re.compile(r'10\.\d{4,9}/[^\s\)\]\*,;]+', re.I)
def clean_doi(d):
    return d.rstrip('.').lower()
# md record info
for k, r in recs.items():
    b = r['body']
    t = r['title']
    m = re.search(r'\*\*Title:\*\*\s*\*?([^*\n]+)', b)
    if (not t or t.lower().startswith('paper')) and m: t = m.group(1)
    if k in ('260','261','262','263','264'):
        m = re.search(r'Paper %s\s*[—–\-�]+\s*\*([^*]+)\*' % k, b)
        if m: t = m.group(1)
    r['title_clean'] = t.strip(' *')
    r['dois'] = sorted(set(clean_doi(d) for d in doi_re.findall(b)))
# ref info
R = {}
for n, s in refs.items():
    s2 = s.split(' Statements and Declarations')[0]
    m = re.match(r'(.*?)\((\d{4}[a-z]?)\)\s*(.*)', s2)
    authors, year, rest = (m.group(1), m.group(2), m.group(3)) if m else ('', '', s2)
    title = rest.split('. ')[0] if rest else ''
    d = doi_re.findall(s2.replace(' ', ''))
    R[int(n)] = dict(n=int(n), authors=authors.strip(), year=year, title=title, doi=clean_doi(d[0]) if d else '', raw=s2)
# match
mapping = {}
used = {}
for n, ref in R.items():
    best = None
    if ref['doi']:
        for k, r in recs.items():
            if ref['doi'] in r['dois']:
                best = (k, 1.0, 'doi'); break
    if not best:
        nt = norm(ref['title'])
        scores = []
        for k, r in recs.items():
            sc = difflib.SequenceMatcher(None, nt, norm(r['title_clean'])).ratio()
            scores.append((sc, k))
        scores.sort(reverse=True)
        best = (scores[0][1], scores[0][0], 'title')
        ref['second'] = scores[1]
    mapping[n] = best
json.dump(dict(R=R, mapping=mapping, rec_titles={k: r['title_clean'] for k, r in recs.items()}, rec_dois={k: r['dois'] for k,r in recs.items()}), open(W+r'\mapping.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
# report
inv = {}
for n,(k,sc,how) in mapping.items(): inv.setdefault(k, []).append(n)
low = [(n,mapping[n]) for n in mapping if mapping[n][1] < 0.8]
print('refs', len(R), 'matched by doi', sum(1 for v in mapping.values() if v[2]=='doi'))
print('low-confidence', len(low))
for n,(k,sc,how) in sorted(low, key=lambda x: x[1][1]):
    print(f'[{n}] {sc:.2f} -> P{k}: REF="{R[n]["title"][:80]}" | MD="{recs[k]["title_clean"][:80]}"')
print('records hit by >1 ref:', {k:v for k,v in inv.items() if len(v)>1})
unmapped = sorted((int(k) for k in recs if k not in inv))
print('md records not mapped to any ref:', len(unmapped), unmapped)
