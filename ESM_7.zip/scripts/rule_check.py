# Check whether the manuscript's conflict rule (tier U when the two formats disagree) was applied consistently
import json, re
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
rows = {r['ref']: r for r in json.load(open(W + r'\audit_rows.json', encoding='utf-8'))}
D = json.load(open(W + r'\ms_data.json'))
T = json.load(open(W + r'\ms_tiers.json'))
U = lambda d: set().union(*d.values())
elig = sorted(U(D['arch'])); M = U(D['mit']); mU = set(D['mitU']); eU = set(D['expU'])
A12 = set(T['A1']) | set(T['A2']); B = set(T['B'])
NEG = re.compile(r'^\W*(no|none|not (explicitly )?(reported|addressed|used|applied|mentioned|stated|specified|discussed|implemented)|n/?a)\b', re.I)


def grab(body, pats):
    for p in pats:
        m = re.search(p, body, re.I)
        if m:
            return re.sub(r'\[[\d,\s\-–]+\]', '', m.group(1)).strip(' *.:|')
    return None


out = []
for ref in elig:
    b = recs[rows[ref]['md']]['body']
    short_imb = grab(b, [r'Class[- ]Imbalance (?:Handling )?(?:Techniques?)?[^:\n]*:\**\s*\|?\s*([^\n|]+)'])
    long_imb_q = grab(b, [r'Is class imbalance addressed\?\**\s*:?\s*\**([^\n]+)'])
    long_imb_t = grab(b, [r'\n\* \**Technique used:?\**\s*:?\s*([^\n]+)'])
    short_xai = grab(b, [r'(?:Explainable AI|XAI)[^:\n]*Techniques?[^:\n]*:\**\s*\|?\s*([^\n|]+)'])
    long_xai_q = grab(b, [r'Is XAI used\?\**\s*:?\s*\**([^\n]+)'])
    long_xai_t = grab(b, [r'\n\* \**XAI method:?\**\s*:?\s*([^\n]+)'])
    neg = lambda s: (s is not None) and bool(NEG.match(s))
    s_imb = None if short_imb is None else (not neg(short_imb))
    l_imb = None if (long_imb_q is None and long_imb_t is None) else not ((long_imb_q and neg(long_imb_q)) or (long_imb_t and neg(long_imb_t)))
    s_xai = None if short_xai is None else (not neg(short_xai))
    l_xai = None if (long_xai_q is None and long_xai_t is None) else not ((long_xai_q and neg(long_xai_q)) or (long_xai_t and neg(long_xai_t)))
    ms_m = 'M' if ref in M else 'U' if ref in mU else 'N/W'
    ms_e = 'A' if ref in A12 else 'B' if ref in B else 'U' if ref in eU else 'none'
    flag = []
    if ms_m == 'M' and (s_imb is False or l_imb is False): flag.append('M-but-one-format-negative')
    if ms_m == 'N/W' and s_imb and l_imb: flag.append('N/W-but-both-positive')
    if ms_e == 'A' and (s_xai is False or l_xai is False): flag.append('A-but-one-format-negative')
    if ms_e == 'none' and s_xai and l_xai: flag.append('none-but-both-positive')
    out.append(dict(ref=ref, md=rows[ref]['md'], ms_m=ms_m, ms_e=ms_e, short_imb=short_imb, long_imb=(long_imb_q, long_imb_t), short_xai=short_xai,
                    long_xai=(long_xai_q, long_xai_t), flags=flag))
json.dump(out, open(W + r'\rule_check.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
from collections import Counter
print(Counter(f for o in out for f in o['flags']))
print('unparsed short_imb', sum(o['short_imb'] is None for o in out), 'unparsed long imb', sum(o['long_imb'] == (None, None) for o in out))
for o in out:
    if o['flags']:
        print(f"[{o['ref']}] P{o['md']} ms={o['ms_m']}/{o['ms_e']} {o['flags']}\n    S-imb: {str(o['short_imb'])[:110]}\n    L-imb: {str(o['long_imb'])[:150]}\n    S-xai: {str(o['short_xai'])[:110]}\n    L-xai: {str(o['long_xai'])[:150]}")
