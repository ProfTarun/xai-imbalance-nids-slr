import json, time, urllib.request, urllib.parse, ssl, sys
sys.stdout.reconfigure(encoding='utf-8')
DOIS = ['10.1136/bmj.n71','10.1613/jair.953','10.1109/IJCNN.2008.4633969','10.1109/ICCV.2017.324','10.1145/2939672.2939778','10.1109/ICCV.2017.74',
        '10.1371/journal.pone.0130140','10.18653/v1/N19-1357','10.18653/v1/D19-1002','10.1186/s12864-019-6413-7','10.1109/SP.2010.25',
        '10.1109/EuroSP48549.2020.00018','10.1016/j.patter.2023.100804','10.1109/SPW53761.2021.00009','10.1109/CISDA.2009.5356528','10.1145/382912.382923',
        '10.1109/TKDE.2008.239','10.1016/j.neunet.2018.07.011','10.1186/s40537-019-0192-5','10.1371/journal.pone.0118432','10.1109/MilCIS.2015.7348942',
        '10.5220/0006639801080116','10.1038/s42256-019-0048-x','10.1007/s11831-023-09943-8','10.1007/s11831-020-09478-2','10.1007/s11831-020-09481-7',
        '10.1007/s11831-022-09767-y']
out = {}
for d in DOIS:
    try:
        with urllib.request.urlopen(urllib.request.Request('https://api.crossref.org/works/' + d, headers={'User-Agent': 'SLR-reference-check/1.0'}), timeout=30) as r:
            m = json.load(r)['message']
        out[d] = dict(title=(m.get('title') or [''])[0], container=(m.get('container-title') or [''])[0], year=(m.get('issued', {}).get('date-parts') or [[None]])[0][0],
                      volume=m.get('volume'), issue=m.get('issue'), page=m.get('page') or m.get('article-number'),
                      authors=[(a.get('family', ''), a.get('given', '')) for a in m.get('author', [])], type=m.get('type'))
    except Exception as e:
        out[d] = {'error': str(e)}
    time.sleep(0.3)
json.dump(out, open('work/crossref_new.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
for d, v in out.items():
    if 'error' in v: print('ERR', d, v['error']); continue
    a = v['authors']; au = ', '.join(f"{x[0]} {''.join(p[0] for p in x[1].replace('-', ' ').split() if p)}" for x in a[:6]) + (' et al' if len(a) > 6 else '')
    print(f"{d} | {au} ({v['year']}) {v['title'][:90]} | {v['container'][:60]} {v['volume']}({v['issue']}):{v['page']}")
