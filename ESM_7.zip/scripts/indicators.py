# Keyword-scan indicators of reporting practice over the extraction records (documented rules; Online Resource 7)
import json, re, sys
sys.path.insert(0, r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\scripts')
from fields import split_record

CLASS_SENSITIVE = {
    'macro-F1': r'macro[- ]?(?:averaged? )?F1|F1[- ]?macro|macro[- ]?(?:averaged? )?F[- ]?(?:score|measure)',
    'per-class recall': r'per[- ]class (?:recall|detection rate|TPR)|class[- ]wise (?:recall|detection)|minority[- ]class (?:recall|detection rate|TPR)|(?:recall|detection rate) (?:for|on|of) (?:each|minority|rare)',
    'MCC': r'\bMCC\b|Matthews',
    'G-mean': r'G[- ]?mean|geometric mean',
    'PR summary': r'PR[- ]?AUC|AUPRC|AUC[- ]PR|precision[- ]recall (?:curve|AUC|area)|average precision',
    'kappa': r'kappa',
}
WORDING = {
    'cross_dataset': r'cross[- ]dataset|cross[- ]domain|inter[- ]dataset|across (?:multiple |different |several )?datasets|external (?:dataset|deployment)|(?:trained|pre-?trained) on .{0,40} (?:tested|evaluated) on',
    'zero_day': r'zero[- ]day|unseen[- ]attack|unseen attack|novel attack|unknown attack|open[- ]set',
    'leakage': r'leakage',
    'train_only_resampling': r'(?:only|exclusively|strictly) (?:on|to) the train|train(?:ing)? (?:set|split|data|partition) only|applied (?:only )?(?:on|to) the training (?:set|split|data)|after (?:the )?(?:train[- ]test )?split',
    'stat_rigor': r'repeated (?:runs|experiments|trials)|\b\d+ (?:independent |random )?(?:runs|seeds|trials)\b|confidence interval|standard deviation|\u00b1|t-test|Wilcoxon|statistical(?:ly)? signific|p-value|Friedman|McNemar',
    'adversarial': r'adversarial|evasion attack|poison|FGSM|\bPGD\b|DeepFool|C&W',
    'code': r'github|code (?:is )?(?:publicly )?available|open[- ]source(?:d)? (?:code|implementation)|source code (?:is )?(?:publicly )?(?:available|released)|code repository',
    'edge_testbed': r'Raspberry|Jetson|edge device|testbed|test-bed|\bhardware\b|FPGA|real[- ]time deploy|deployed on|embedded|microcontroller|on-device|prototype implementation',
}
COST_MEASURED = r'latency|inference time|training time|detection time|\bms\b|millisecond|\bseconds?\b|FLOPs|parameter count|number of parameters|\bparams\b|memory (?:usage|footprint|consumption)|throughput|runtime|execution time|energy consumption|model size|\bMB\b'
LIMITS = {
    'cost/latency': r'computational|latency|overhead|memory|expensive|training time|inference time|execution time|\bGPU\b|complexity|resource',
    'rare-class difficulty': r'\brare\b|minority|under-?represent|U2R|R2L|\bworms\b|scarce',
    'synthetic-data quality': r'synthetic|mode collapse|generat(?:ed|ion) (?:quality|samples)|GAN (?:training|instability)|oversampling noise|distributional alignment|generator',
    'hyperparameter sensitivity': r'hyper-?parameter|tuning|sensitiv',
    'explanation/interpretability gap': r'explainab|interpretab|black[- ]box|\bXAI\b|transparen',
    'limited/single-dataset evaluation': r'evaluat\w* (?:only|primarily|solely|exclusively) on|restricted to (?:the )?[\w\-]+|only (?:on )?(?:one|a single|the) [\w\- ]{0,25}dataset|single[- ](?:dataset|benchmark)|one dataset|(?:cross-dataset|generaliz\w+)[^.]{0,60}not (?:been )?(?:tested|evaluated|verified|validated)|may not (?:directly )?generaliz|static benchmark',
    'no real-world validation': r'real[- ]world|live (?:traffic|network|environment|deployment|streaming)|production (?:network|environment|deployment)|offline (?:evaluation|benchmark)|static offline|simulated (?:traffic|data|environment|logs)|(?:line-rate|real-time)[^.]{0,40}not (?:empirically )?(?:benchmarked|evaluated|tested)',
}


def scan(body):
    f = split_record(body)
    metrics = f.get('s_metrics', '') + ' ' + f.get('l_metrics', '')
    findings = f.get('s_findings', '') + ' ' + f.get('l_findings', '')
    limits = f.get('s_limitations', '') + ' ' + f.get('l_limitations', '')
    allt = f['all']
    out = {}
    out['class_sensitive'] = [k for k, p in CLASS_SENSITIVE.items() if re.search(p, metrics, re.I)]
    for k, p in WORDING.items():
        out[k] = bool(re.search(p, allt, re.I))
    out['cost_measured'] = bool(re.search(COST_MEASURED, metrics + ' ' + findings, re.I))
    out['limitations'] = [k for k, p in LIMITS.items() if re.search(p, limits, re.I)]
    return out


if __name__ == '__main__':
    W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
    sys.stdout.reconfigure(encoding='utf-8')
    recs = json.load(open(W + r'\recs2.json', encoding='utf-8'))
    rows = {r['ref']: r for r in json.load(open(W + r'\audit_rows.json', encoding='utf-8'))}
    D = json.load(open(W + r'\ms_data.json'))
    elig = sorted(set().union(*D['arch'].values()))
    M = set().union(*D['mit'].values())
    both = set(D['bothA1']) | set(D['bothA2'])
    res = {ref: scan(recs[rows[ref]['md']]['body']) for ref in elig}
    json.dump(res, open(W + r'\indicators_orig188.json', 'w'), indent=0)
    cs = [r for r in M if res[r]['class_sensitive']]
    print('class-sensitive among tier M: %d of %d (orig 39)' % (len(cs), len(M)))
    for k in CLASS_SENSITIVE:
        print('   ', k, sum(k in res[r]['class_sensitive'] for r in M))
    print('class-sensitive among both: %d of %d (orig 14)' % (sum(bool(res[r]['class_sensitive']) for r in both), len(both)))
    orig = dict(cross_dataset=30, zero_day=50, leakage=12, train_only_resampling=1, stat_rigor=33, cost_measured=27, edge_testbed=38, adversarial=26, code=5)
    examples = dict(cross_dataset=[14, 15, 16, 17, 19, 20, 27, 47, 51, 70], zero_day=[15, 17, 22, 23, 30, 37, 42, 59, 61, 63], leakage=[15, 16, 17, 62, 68, 81, 84, 135, 139, 145],
                    train_only_resampling=[71], stat_rigor=[7, 16, 20, 30, 45, 47, 52, 53, 79, 80], cost_measured=[5, 14, 16, 19, 37, 40, 50, 58, 59, 76],
                    edge_testbed=[16, 17, 20, 35, 37, 45, 46, 58, 75, 76], adversarial=[28, 35, 48, 61, 70, 75, 77, 84, 107, 116], code=[13, 20, 62, 148, 170])
    for k, o in orig.items():
        n = sum(res[r][k] for r in elig)
        ex = examples[k]
        rec = sum(res[r][k] for r in ex if r in res)
        print(f'  {k}: {n} (orig {o}); recall on printed examples {rec}/{len(ex)}')
    from collections import Counter
    c = Counter(l for r in elig for l in res[r]['limitations'])
    print('limitations', c.most_common(), '(orig cost 82, rare 25, synthetic 25, hyper 22, expl 19, single 10, realworld 9)')
