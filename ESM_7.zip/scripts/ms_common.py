# Shared data and helpers for the manuscript content modules
import json
W = r'C:\Users\tarun\Desktop\MtechPurva\Build_Pipeline\work'
FIG = W + r'\figs'
N = json.load(open(W + r'\stats_revised.json'))
RS = json.load(open(W + r'\revised_studies.json', encoding='utf-8'))
S = {int(k): v for k, v in RS['studies'].items()}
n = N['n']
MT, ET = N['mit_tiers'], N['exp_tiers']
MT.setdefault('U', 0); ET.setdefault('U', 0)   # tier U may be empty after the full-text resolution
CU = len(N['cand_one']) + len(N['cand_both'])   # unresolved RQ4 candidates
CONF = MT.get('U', 0) + ET.get('U', 0) + len(N['dsConflict'])   # remaining extraction conflicts


def C(lst):
    if not lst:
        return '–'
    return '[[' + ','.join(str(x) for x in lst) + ']]'


def ex(lst, k=3):
    return C(sorted(lst)[:k])


def ln(key, sub=None):
    v = N[key] if sub is None else N[key][sub]
    return len(v)


def pct(a, b):
    return f'{100 * a / b:.0f}%'


WORDS = {0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 11: 'eleven', 12: 'twelve'}


def w(x):
    return WORDS.get(x, str(x))
