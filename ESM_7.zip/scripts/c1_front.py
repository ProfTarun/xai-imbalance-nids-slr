# Manuscript part 1: title page, abstract, introduction, review methodology
from ms_common import *

ABSTRACT = (
    "Deep-learning network intrusion detection systems (NIDS) face two persistent obstacles: class imbalance, which can hide rare but "
    "consequential attacks, and opaque decisions, which limit analyst trust. This systematic literature review examines how imbalance "
    "mitigation and explainable artificial intelligence (XAI) are used, combined and evaluated in deep-learning NIDS research, and the "
    "computational assumptions of each method family. Of 265 numbered candidate records, 11 duplicates were removed and 254 were screened "
    "against explicit criteria on structured extractions; 11 unresolved records were read in full, and a record-level audit removed two "
    f"misclassified records, leaving {n} primary studies and 26 existing reviews. Screening was a single pass assisted by a large language "
    "model, the search log was not retained, and most studies were assessed at extraction level, so counts describe this corpus, not the "
    f"field. Loss-level reweighting ({ln('mit', 'Loss/cost-sensitive')} of {MT['M']} studies with an explicit method), resampling "
    f"and generative synthesis dominate mitigation; Shapley-value attributions ({ln('exp', 'SHAP')} of {ln('EV')} studies with explanation "
    f"evidence) and local surrogate explanations ({ln('exp', 'LIME')}) dominate explanation. {ln('both')} studies report both an explicit "
    f"mitigation method and an explicit explanation technique, but explanation quality is evidenced for {ln('quality_both')} of them, "
    f"minority-class explanation for {ln('minority_explicit') + ln('minority_indirect')}, and only {w(ln('quality_cs_both'))} evidence both an "
    f"explanation-quality assessment and a class-sensitive detection metric. Hardware evaluation ({ln('h_hardware_eval')} of {n}), leakage-safe resampling "
    f"({ln('h_leak_safe_resampling')}) and code release ({ln('h_code_release')}) are rarely evidenced. The review contributes a computational "
    "taxonomy, an evidence map, a reporting-gap analysis and a proposed, unvalidated evaluation framework."
)


def build(B):
    B.title('Explainable Deep Learning for Imbalance-Robust Network Intrusion Detection: A Systematic Literature Review')
    B.p('Tarun Jangwal¹* · Purva Pathania²', align='left', space_after=2)
    B.p('¹School of Computing and Artificial Intelligence, Lovely Professional University, Phagwara, Punjab, India', align='left', size=10, space_after=0)
    B.p('²School of Computer Science and Engineering, Lovely Professional University, Phagwara, Punjab, India', align='left', size=10, space_after=2)
    B.p('*Corresponding author: Tarun Jangwal, tarun.24044@lpu.co.in', align='left', size=10, space_after=0)
    B.p('E-mail: tarun.24044@lpu.co.in (T. Jangwal); pathaniapurva40@gmail.com (P. Pathania)', align='left', size=10)
    B.p('**Abstract** ' + ABSTRACT)
    B.p('**Keywords** Network intrusion detection · Deep learning · Class imbalance · Explainable artificial intelligence · '
        'Systematic literature review · Evaluation methodology')

    # ------------------------------------------------------------------ 1
    B.h(1, '1 Introduction')
    B.h(2, '1.1 Motivation')
    B.p("Network intrusion detection systems (NIDS) inspect network traffic or flow records and raise alerts when behaviour departs from what is "
        "expected or matches a known attack pattern. They are a basic control in enterprise, Internet-of-Things (IoT), industrial and vehicular "
        "networks, where undetected intrusions can disrupt services or damage physical processes. Over the last decade, deep learning (DL) has "
        "become a common modelling choice for this task, and the literature now spans convolutional neural networks (CNNs), recurrent networks "
        "such as long short-term memory (LSTM) models, and attention-based, generative, graph and federated designs [[29,106,150]]. Reviews have "
        "mostly organised that literature by model family, dataset or deployment setting [[4,11,49,211]], and earlier reviews in this journal have "
        "covered machine-learning-based intrusion detection, data-driven detection in industrial control networks and swarm-intelligence-based "
        "detection [[bg:thakkar2023,bg:tama2022,162]]. Two computational difficulties recur across those reviews and across the primary studies "
        "they cover.")
    B.p("The first is class imbalance (hereafter imbalance). Benign flows usually outnumber malicious ones, and within the malicious class a few "
        "attack types dominate, so a detector trained by empirical risk minimisation can reach a high overall accuracy while missing the rare "
        "attacks that matter most [[18,188,bg:he2009,bg:johnson2019]]. The second is opacity. A DL detector returns a label without a rationale, "
        "which limits the confidence analysts can place in an alert and complicates auditing and incident response [[69,128,150]]. Explainable "
        "artificial intelligence (XAI) addresses this second difficulty.")
    B.p("Each difficulty has produced its own body of methods. Imbalance is attacked at the data level, through resampling (for example the "
        "Synthetic Minority Over-sampling Technique, SMOTE [[bg:chawla2002]], and Adaptive Synthetic sampling, ADASYN [[bg:he2008]]) and "
        "synthetic generation with generative adversarial networks (GANs) or variational autoencoders (VAEs); at the loss level, through "
        "class-weighted and focal objectives [[bg:lin2017]]; and through decision thresholds, ensembles and specialised learning formulations "
        "[[3,18]]. We call these approaches imbalance mitigation, or mitigation for short. Opacity is attacked with post-hoc explanation, for "
        "example SHapley Additive exPlanations (SHAP) [[bg:lundberg2017]] and Local Interpretable Model-agnostic Explanations (LIME) "
        "[[bg:ribeiro2016]], with gradient-based attribution, attention-based explanation, rule extraction and counterfactuals [[9,26,164]]. "
        "The two lines of work interact, which is the reason for considering them together (Fig. 1). A mitigation step changes the training "
        "distribution and therefore the function that is later explained; post-hoc explainers additionally depend on a reference or background "
        "distribution and aggregate attributions over classes in proportion to their frequency (Section 3.5). Conversely, an explanation can "
        "reveal that a model separates minority classes using spurious features, which would call the mitigation into question. A detector that "
        "is both imbalance-robust and explainable therefore needs evidence on whether the two properties are examined together, and not only "
        "evidence that each is addressed.")
    B.figure(FIG + r'\Fig1.png', 'Generic deep-learning pipeline for NIDS, showing where imbalance mitigation and explanation enter. The dashed '
             'path marks explanation-guided mitigation. Conceptual schematic produced for this review; it is not derived from the evidence data', 16)
    B.h(2, '1.2 Existing reviews and the gap')
    B.p("The 26 existing reviews and surveys set aside for comparison (Section 5) cover broad NIDS taxonomies, DL-based NIDS, imbalance handling "
        "[[18,188,207]] or explainability [[9,26,89,128,164]]. According to their structured extractions, each treats the topic outside its "
        "focus at survey level. Two reviews, [[128]] and [[69]], cover both topics inside a wider frame, and whether they analyse the interaction "
        "between mitigation and explanation could not be established without their full texts. The gap pursued here therefore concerns synthesis "
        "and evaluation practice, not an unstudied topic. Many primary studies pair a mitigation method with an explanation technique. What is "
        "less clear is whether such studies assess explanation quality, whether they explain predictions for minority classes, whether the "
        "computational assumptions of the two components are compatible, and whether the reporting needed to interpret their results "
        "(class-sensitive metrics, the order of splitting and resampling, cross-dataset evidence, computational cost) is evidenced.")
    B.h(2, '1.3 Scope, research questions and contributions')
    B.p(f"This article reviews that evidence for a candidate pool assembled by the authors with these concerns in mind. It does not survey the "
        f"whole NIDS literature. Of 254 unique candidate records, {n} primary studies were included (Fig. 2), and all quantitative results below "
        f"are computed from those {n} studies. The review rests mainly on structured extractions of each paper; full texts were read only for the "
        f"records whose eligibility the extractions could not settle, and Section 2 states what this means for every number reported. Because the "
        f"pool was assembled with explanation and imbalance in mind, shares reported here describe the reviewed corpus and cannot be read as "
        f"prevalence in the field. Five research questions organise the review (Table 1).")
    B.table('Research questions and their motivation', ['ID', 'Question', 'Motivation'], [
        ['RQ1', 'What DL architectures and datasets are used for network intrusion detection?', 'Establishes the technical landscape and shows how far results can be compared'],
        ['RQ2', 'How do DL NIDS studies address class imbalance and minority-class detection?', 'Shows what is done about imbalance and whether evaluation reflects minority-class behaviour'],
        ['RQ3', 'Which explainability techniques are used to interpret DL-based NIDS models?', 'Separates established explanation techniques from visualisations and feature-selection steps that are sometimes called explanation'],
        ['RQ4', 'To what extent are imbalance handling and explainability addressed together, and how are explanations evaluated?', 'The central question: whether the two properties are examined together and whether explanation quality is assessed'],
        ['RQ5', 'What methodological and evaluation gaps remain for developing explainable and imbalance-robust DL NIDS?', 'Identifies reporting practices that limit interpretation of results and deployment readiness'],
    ], widths=[1.2, 7.3, 7.5])
    B.p("The review offers six contributions, each demonstrated in the sections cited. (i) A computational account of how mitigation and "
        "explanation methods act on the learning problem, including an analytical argument for why the two interact (Section 3). (ii) A taxonomy "
        f"of architecture, mitigation and explanation families for the {n} included studies, with explicit rules for what counts as mitigation "
        "and as explanation (Sections 4.2–4.4). (iii) An evidence map of the studies that report both an explicit mitigation method and an "
        "explicit explanation technique, recording what the evidence shows about explanation quality and minority-class explanation "
        "(Section 4.5). (iv) A reporting-gap analysis with hand-checked indicators (Sections 4.6 and 7). (v) A comparison with 26 existing "
        "reviews, with a novelty statement kept conditional on full-text checks (Section 5). (vi) A proposed evaluation framework and minimum "
        "reporting checklist relating imbalance robustness, detection performance, explanation quality and deployment requirements (Section 8); "
        "they are derived from the synthesis, have not been validated experimentally and are not taken from any single study.")
    B.p("**Organisation.** Section 2 describes the review methodology. Section 3 gives the computational background. Section 4 reports study "
        "selection and answers the five questions. Section 5 compares the review with earlier reviews, Section 6 discusses the evidence, and "
        "Sections 7 and 8 present research gaps and directions. Sections 9 and 10 state limitations and conclusions.")

    # ------------------------------------------------------------------ 2
    B.h(1, '2 Review methodology')
    B.h(2, '2.1 Review type, protocol and reporting guideline')
    B.p("The objective is to synthesise what primary studies report about imbalance mitigation and explanation in DL-based NIDS and to identify "
        "gaps in how the two are combined and evaluated, through the research questions in Table 1. The review follows the phases of systematic "
        "literature reviews in computing (identification, selection, extraction and synthesis) [[bg:kitchenham2007]] and is reported against the "
        "Preferred Reporting Items for Systematic reviews and Meta-Analyses (PRISMA) 2020 statement [[bg:page2021]]; the completed PRISMA 2020 "
        "checklist, with the location of each item or the reason it is not reported, is provided as Online Resource 8. No protocol was "
        "registered. Several PRISMA items cannot be met retrospectively because the information was not recorded when the candidate pool was "
        "assembled (Sections 2.2 and 9); these items are declared rather than reconstructed. Reporting against PRISMA describes transparency; "
        "it is not a claim about the methodological quality of the review.")
    B.h(2, '2.2 Search concepts and what was documented')
    B.p("The candidate pool was collected with keyword families developed for this project around four concepts: network intrusion detection, "
        "deep learning, class imbalance and explainability (Table 2). The authors state that different combinations of these concepts were "
        "used, that a paper was not required to mention all four, and that search results were pre-screened manually while the pool was being "
        "assembled, with clearly irrelevant items discarded before records were numbered. The original search log did not preserve the "
        "databases or platforms queried, the exact query strings and Boolean operators, the date limits and search dates, any language or "
        "document-type limits, any grey-literature or citation-chasing steps, or the number of results returned and discarded at that manual "
        "stage. These items are therefore reported as not recorded (Fig. 2) and are not reconstructed. The publication years of the candidates "
        "(2016 to 2026 by bibliographic year) describe the range of the pool and not a search window.")
    B.table('Keyword families used when the literature was collected, as stated by the authors. The exact strings, databases, dates and '
            'per-source counts were not retained', ['Concept', 'Keyword family'], [
        ['Network intrusion detection', 'network intrusion detection; intrusion detection system; NIDS; network-based intrusion detection; intrusion detection'],
        ['Deep learning', 'deep learning; deep neural network; convolutional neural network (CNN); long short-term memory (LSTM); bidirectional LSTM (BiLSTM); CNN-LSTM; hybrid deep learning; transformer'],
        ['Class imbalance', 'class imbalance; imbalanced data; minority class; oversampling; SMOTE; ADASYN; class-weighted and cost-sensitive learning; focal loss'],
        ['Explainability', 'explainable AI; explainable artificial intelligence (XAI); explainable or interpretable intrusion detection; SHAP; LIME; feature importance; explainable deep learning'],
    ], widths=[3.5, 12.5])
    B.h(2, '2.3 Candidate pool and duplicate handling')
    B.p("The records retained after manual pre-screening were numbered 1 to 265. Eleven identifiers (56, 57, 85, 98, 101, 103, 144, 229, 230, "
        "249 and 265) are unused in the retained files because those records were removed as duplicates; which retained record each of them "
        "duplicated was not recorded, so the duplicate decisions themselves cannot be re-examined. The retained bibliography holds 254 distinct "
        "entries, the highest identifier present is 264, and every one of the 254 entries was carried into screening. During the revision, the "
        "254 entries were re-checked for residual duplicates: no two share a digital object identifier (DOI), and the only pair with "
        "near-identical normalised titles and the same author team describes different methods (a machine-learning and a deep-learning model); "
        "one of the two was excluded at screening, so the pair cannot be double-counted in the synthesis.")
    B.h(2, '2.4 Eligibility criteria')
    B.p("The criteria in Table 3 were written from the research topic and fixed before any screening decision was made. They were not "
        "registered, and they were written after the candidate pool had been assembled. A paper did not need to address imbalance and "
        "explanation together. A DL NIDS study was eligible if it contributed evidence to at least one research question, including "
        "architecture and evaluation evidence only. Existing reviews and surveys of NIDS, imbalance or explanation were not excluded; they form a "
        "separate comparison corpus and are never counted as primary studies.")
    B.table('Eligibility criteria. They were written from the review topic, fixed before any screening decision and not registered',
            ['Code', 'Criterion'], [
        ['IC1', 'Intrusion or anomaly detection on network traffic or network communications, including IoT, industrial, software-defined networking (SDN) and vehicular networks'],
        ['IC2', 'A deep neural model is proposed, or deep models form a central or at-least-half share of the models evaluated'],
        ['IC3', 'Evidence relevant to at least one research question (architecture, dataset, imbalance, explanation or evaluation)'],
        ['EC1', 'Not network intrusion detection (for example host-level system-call or log data)'],
        ['EC2', 'No meaningful deep component (classical machine learning only, or a deep model that is a minor comparator)'],
        ['EC3', 'Dataset or benchmark paper; conceptual framework without empirical evaluation; survey outside the topic'],
        ['Separate', 'Existing reviews and surveys of NIDS, imbalance or explanation: related-work comparison only'],
    ], widths=[1.8, 14.2])
    B.h(2, '2.5 Selection process')
    B.p("Eligibility was assessed in two steps. In the first step, all 254 unique records were screened against the criteria using the "
        "structured extraction of each record and its bibliographic metadata. This step excluded 23 records, set aside 25 existing reviews and "
        "surveys for comparison, left 12 records uncertain and provisionally included 194. In the second step, the 206 records that were "
        "provisionally included or uncertain were re-checked against a second extraction format and the bibliographic metadata, covering "
        "network-traffic scope, the role of deep models and the availability of evidence relevant to at least one research question. This step "
        "excluded 6 records, found 188 eligible on the available evidence and left 12 unresolved because the evidence was insufficient or "
        "contradictory. Stage 1 excluded 17 records without a meaningful DL component, 2 that do not concern network intrusion detection, "
        "2 surveys outside the topic, 1 conceptual framework without empirical evaluation and 1 dataset paper; the second step excluded 5 records "
        "in which no deep model is proposed or central and 1 that analyses host-level system-call data.")
    B.p("Both steps were carried out in a single pass assisted by a large language model, working to the criteria in Table 3. No independent "
        "second reviewer assessed the decisions, so no agreement statistics exist. The decision and reason for every record are tabulated in "
        "Online Resources 2 and 3.")
    B.h(2, '2.6 Full-text assessment of the unresolved records')
    B.p("The full text of each of the 12 unresolved records was sought. Eleven were obtained and read against criteria IC1–IC3 and "
        "EC1–EC3; the twelfth could not be obtained (only the publisher's web page was available), so its eligibility was not assessed and "
        "it is not cited. Of the eleven, six were eligible and five were excluded because no deep model is proposed or central (EC2) (Table 4). "
        "The six eligible studies are classified from their full texts and marked as full-text verified in Online Resource 1. Two cautions "
        "apply. First, these are the only eligibility decisions in the review that rest on full text, and they were made on cases that were "
        "uncertain by construction, so they say little about how often the extraction-level decisions for the other studies would change. "
        "Second, the full-text reading corrected the extractions in several cases: for [[60]] the extractions left the network scope unclear, "
        "whereas the study uses network flows from a water-system industrial-control testbed, and for [[117]], [[120]] and [[205]] one of the two "
        "extraction formats named datasets or models that the full text does not contain.")
    B.table('Full-text assessment of the records whose eligibility was unresolved after the second screening step. One further record could '
            'not be obtained and is not listed', ['Record', 'Finding in the full text', 'Decision'], [
        ['[[31]]', 'Seven models (random forest, deep neural network, AdaBoost, multilayer perceptron, k-nearest neighbours, support vector machine, LightGBM); the neural models are 2 of 7; SHAP and LIME used for feature explanation; no imbalance method', 'Excluded (EC2: deep models are a minor comparator)'],
        ['[[32]]', 'The same seven models; the study evaluates black-box explanation frameworks', 'Excluded (EC2)'],
        ['[[33]]', 'The same seven models; Xplique is applied to the deep neural network only; random oversampling is used', 'Excluded (EC2)'],
        ['[[56]]', 'NGBoost (gradient boosting) against tree-ensemble baselines; no deep model central; no imbalance method', 'Excluded (EC2)'],
        ['[[105]]', 'Random forest and XGBoost only; SMOTE and SHAP on CIC-IDS2017 and CSE-CIC-IDS2018', 'Excluded (EC2: no deep model)'],
        ['[[60]]', 'Multi-head attention classifier with an autoencoder for zero-day attacks; network flows from a water-system industrial-control testbed; SHAP explanations; no imbalance method', 'Included'],
        ['[[82]]', 'XGBoost and TabNet on UNSW-NB15; SHAP and LIME, compared on ten instances with the Jaccard index; no imbalance method', 'Included (TabNet is 1 of 2 models, which meets the at-least-half rule)'],
        ['[[117]]', 'Federated deep model with F1-based cost-sensitive loss weights on CIC-IDS2017, UNSW-NB15 and Bot-IoT; the architecture is not stated in the paper', 'Included'],
        ['[[120]]', 'Difficult Set Sampling Technique (DSSTE) applied to the training split, with random forest, support vector machine, XGBoost, LSTM, AlexNet and Mini-VGGNet (3 of 6 models deep) on NSL-KDD and CSE-CIC-IDS2018', 'Included'],
        ['[[177]]', 'Attention-LSTM encoder feeding a gradient-boosting ensemble on a public smart-grid intrusion dataset (network communication features); SMOTE on the training split only and focal loss; attention-based explanation', 'Included, flagged (the deep part encodes features and a classical model makes the final decision)'],
        ['[[205]]', 'Few-shot meta-learning with negative learning and bagging; 1D-CNN, ResNet and Inception backbones; CIC-IDS2017, Edge-IIoTset and IoT-23', 'Included'],
    ], widths=[1.6, 10.2, 4.2])
    B.h(2, '2.7 Record-level audit during revision')
    B.p("Before the synthesis was finalised, every eligible record was audited against the bibliography and its two extraction formats. The "
        "audit (i) linked each reference, bibliographic entry and extraction record through the persistent record identifier, the title and "
        "the DOI; (ii) compared the paper type, authors, datasets and techniques named in the short and the long extraction format; (iii) "
        "checked that each architecture, mitigation and explanation label is supported by wording in the record; and (iv) checked the "
        "bibliographic metadata of every cited work against Crossref (Section 2.12). Two eligibility decisions and one classification changed.")
    B.bullets([
        "[[77]] is a systematic review of 200 papers according to its bibliographic entry and long-form extraction. Its short-form extraction "
        "summarises a federated deep model reported by a study that the review cites, and the earlier classification had been taken from that "
        "summary. The record was moved to the comparison corpus of existing reviews (now 26).",
        "[[51]] generates a balanced software-defined-networking IoT dataset and benchmarks four deep models on it, according to its long-form "
        "extraction; its short-form extraction describes a federated conditional VAE that the paper does not report. It meets exclusion "
        "criterion EC3 (dataset or benchmark paper) and was excluded.",
        "[[43]] describes a graph-attention network whose name contains the string “GAN”. The keyword rules had assigned it to the "
        "GAN-based architecture family and to generative synthesis; neither label is supported by its record, and both were removed. Its "
        "loss-level mitigation and attention-based explanation are unaffected.",
        "A systematic scan of the tier A1 and A2 records for fidelity, stability, consistency and agreement tests found six records "
        "[[14,81,122,168,191,200]] that meet the definition of explanation-quality evidence (Section 2.8) but had been missed by the "
        "original hand curation. They were added after each record was read; four of them belong to the explicit-both group.",
    ])
    B.p(f"After the audit, {n} primary studies are included: {n - ln('fulltext')} eligible on extraction-level evidence and "
        f"{ln('fulltext')} on full-text reading. The audit also found that in some records the short-form summary attributes the paper to the "
        "wrong authors while describing the correct study; these attribution errors do not affect classification and are corrected in the "
        "reference list. The audit cannot detect a misattributed summary when both extraction formats are wrong in the same way, which is one "
        "reason why the extraction-level evidence is treated as provisional throughout.")
    B.h(2, '2.8 Data items, evidence classes and classification rules')
    B.p("The evidence is the structured extraction of each paper, prepared in two overlapping formats: a short twelve-field summary and a "
        "longer sectioned record. Whether each extraction rests on the full text or on abstract-level information is not recorded. Every "
        "statement below therefore belongs to one of four classes, and the text says which applies wherever it matters.")
    B.bullets([
        "**Extracted**: stated in an extraction, for example a dataset name or a reported metric. Reported results are the authors' own, "
        "obtained under their own splits and metrics, and were not reproduced.",
        "**Assigned**: a classification made for this review from the extraction, for example an architecture family or an evidence tier.",
        "**Indicator**: a scan of the extraction for a reporting practice, either by keyword or by keyword followed by reading each hit in "
        "context (hand-checked). A positive entry shows that the practice is described in the extraction; a negative entry shows only that it "
        "was not evidenced there, not that the original paper omits it.",
        "**Interpretation**: a judgement by the reviewers, labelled as such in the Discussion and Comments blocks.",
    ])
    B.p("**Mitigation tiers.** Tier M (explicit) requires that the extraction names a method that acts on imbalance: resampling, synthetic "
        "generation, class-weighted, focal or cost-sensitive learning, a decision-threshold adjustment, a few-shot or contrastive formulation, "
        "a federated rebalancing step, or an ensemble used for imbalance. Stratified splitting or cross-validation, balanced test sets and "
        "macro-F1 reporting alone are not mitigation (tier N, none). Tier W (indirect) marks an effect on imbalance that is not a mitigation "
        "method, and tier U marks conflicting extraction formats (Section 2.10).")
    B.p("**Explanation tiers.** A study counts as explanation evidence only when its extraction identifies a genuine explanation technique. "
        "Tier A1 covers established post-hoc and intrinsic techniques (SHAP, LIME, gradient-based methods, counterfactuals, surrogates or rules "
        "and similar). Tier A2 covers attention-based explanation, meaning attention weights or maps presented as explanation; it is kept "
        "separate because the validity of attention weights as explanations is contested [[bg:jain2019,bg:wiegreffe2019]] and the extractions "
        "rarely describe a validation. Tier B covers feature-importance scores taken from a model without a separate explanation procedure. "
        "Feature selection, principal-component variance, learning curves, t-SNE or latent-space plots, chi-square or mutual-information "
        "ranking and replay-buffer tracking are not counted. Tier U marks conflicting formats, and “none” marks no qualifying item.")
    B.p("**Studies reporting both.** The phrase “studies reporting both an explicit imbalance-handling method and an explicit explanation "
        "technique” (explicit-both studies) means tier M together with tier A1 or A2. It describes what a study reports. It does not mean "
        "that a study is imbalance-robust or explainable, because neither the presence of a method nor the presence of an explanation technique "
        "establishes robustness or explanation quality.")
    B.p("**Families.** Architecture, dataset, mitigation and explanation families were assigned by keyword rules applied to the extraction "
        "fields and checked by hand for the categories that carry conclusions (Online Resource 7). A study can carry several family labels, so "
        "family counts overlap and do not sum to the number of studies. The two evidence items used most in Section 4.5 were curated by hand: "
        "explanation-quality evidence (a test of fidelity, stability, consistency or agreement of explanations, or a human assessment) and "
        "minority-class explanation (explanations computed for, or tied to, rare classes; explicit or indirect).")
    B.h(2, '2.9 Indicators of reporting practice')
    B.p("Indicators were re-implemented during revision because the scripts behind the original indicator counts were not available and three "
        "rules could not be reproduced (Online Resource 7 lists original and recomputed values). Two changes in definition matter. First, "
        "evaluation indicators are now computed only from text that describes what a study did; statements in the future-work, limitation and "
        "relevance fields, and descriptions of where a dataset was collected, are excluded, because many hits there describe what was not done "
        "(for example “real-time hardware deployment was not evaluated”). Second, seven indicators that carry conclusions were "
        "hand-checked: every keyword hit was read in context and kept only if it described the practice in the intended sense (for example, "
        "train–test leakage rather than privacy leakage). These are training on one dataset and testing on another, evaluation on held-out "
        "unseen attack types, discussion of evaluation leakage, leakage-safe or training-only resampling, adversarial-robustness evaluation, "
        "hardware or testbed evaluation, and code release. Class-sensitive metrics (macro-F1, per-class or minority-class recall, the Matthews "
        "correlation coefficient (MCC), the geometric mean of recalls (G-mean), a precision–recall summary and Cohen's kappa), repeated "
        "evaluation or statistical testing, and measured computational cost remain keyword indicators read from the metrics and findings fields "
        "of either format; a spot check of 12 cost hits found all 12 to describe a measurement.")
    B.h(2, '2.10 Conflict-resolution procedure')
    B.p("The two extraction formats sometimes disagree, and neither is treated as authoritative. The procedure applied to every eligible study "
        "was as follows; the flags it produces are summarised in Table 5.")
    B.bullets([
        "Compare the short and the long format on whether the practice exists (an imbalance-mitigation method, an explanation technique, a "
        "deep model, a dataset identity).",
        "If they differ only in detail or emphasis, accept the practice and record the more specific description.",
        "If one format states the practice and the other denies it or describes something that is not that practice, assign tier U for that "
        "dimension. The study is then counted neither for nor against the practice.",
        "If the formats name different dataset families, exclude the study from dataset-family counts and from the dataset indicators, and "
        "report it separately.",
        "If no numeric performance value is recorded, exclude the study from any statement about reported performance.",
        "If the deep component only generates samples or encodes features while a classical model makes the final decision, keep the study "
        "but flag it and report it separately.",
        "If a full text was read, the full text overrides both formats.",
    ], numbered=True)
    flags = [
        ['Imbalance mitigation: formats conflict', 'The formats disagree on whether a mitigation method exists, or the long-form technique is not a mitigation', MT['U'], C(N['mit_tier_lists']['U'])],
        ['Explanation: formats conflict', 'The formats disagree on whether an explanation technique is used', ET['U'], C(N['exp_tier_lists']['U'])],
        ['Dataset identity: formats conflict', 'The formats name different dataset families', ln('dsConflict'), C(N['dsConflict'])],
        ['No numeric performance value', 'No numeric performance value is recorded in the extraction', ln('noNumeric'), C(N['noNumeric'])],
        ['Generative or encoding component only', 'The deep component generates samples or encodes features; the final classifier is classical', ln('genOnly'), C(N['genOnly'])],
    ]
    B.table(f'Flags carried in the evidence table for the {n} included studies. Conflicts are retained and not resolved; the studies concerned '
            'are not counted in the affected category', ['Flag', 'Meaning', 'n', 'Studies'], flags, widths=[3.4, 5.0, 0.8, 6.8])
    B.p("Where the available evidence does not allow resolution, the uncertainty is retained and no stronger claim is made. Online Resource 4 "
        "lists the studies in each category, and Section 4.5 states the effect on the central counts.")
    B.h(2, '2.11 Synthesis methods')
    B.p("The included studies use different datasets, splits, label granularities, preprocessing pipelines and metric sets, and the extractions "
        "record point estimates without variances. Effect sizes are therefore not comparable across studies and no meta-analysis or pooled "
        "performance estimate was attempted. The synthesis is a structured narrative synthesis organised by the research questions, reported in "
        "line with the Synthesis Without Meta-analysis (SWiM) guideline [[bg:campbell2020]]: studies are grouped by method family and evidence "
        "tier, the grouping rules are stated in Sections 2.8–2.10, counts are reported with their numerators and denominators, and "
        "statements about what works are limited to what individual studies report. Counting how often a method is used describes practice; "
        "it is not evidence of effectiveness, and vote counting of reported improvements was not used.")
    B.h(2, '2.12 Risk of bias and certainty of evidence')
    B.p("No study-level risk-of-bias or quality appraisal was performed, and no certainty-of-evidence grading was applied. Established tools for "
        "these purposes target clinical and intervention studies and have no agreed counterpart for machine-learning intrusion-detection "
        "experiments, and the extraction-level evidence would not support such an appraisal. The reporting indicators of Section 4.6 describe "
        "how completely studies report practices that affect the interpretation of results (for example the order of splitting and resampling); "
        "they are not a risk-of-bias assessment. Readers should treat every reported performance value as the authors' own claim under their "
        "own protocol.")
    B.h(2, '2.13 Bibliographic reconciliation')
    B.p("Citation keys were normalised, conference papers typed as journal articles were retyped, and the metadata of every cited work were "
        "checked against Crossref during revision. Of the 224 corpus references cited, 194 matched Crossref on title, year, first author, "
        "volume and pages. Ten were corrected: a truncated title, a first author, a publication year, four missing volume and article numbers, "
        "a DOI registered with a double slash, a preprint replaced by its published version, and a DOI that resolves nowhere, which was removed. "
        "Ten further apparent discrepancies were formatting variants or errors in the Crossref record. Five arXiv or Zenodo deposits carry DOIs "
        "registered with DataCite, and five works without a DOI are not indexed by Crossref and could not be verified externally. "
        f"For {61} of the {n} included studies the year recorded in the long-form extraction differs from the bibliographic year (18 by two "
        "years or more); the bibliographic year is used wherever a year appears, and no analysis of publication years is presented. Preprints "
        "and deposits without peer review are identified as such in the reference list.")
    B.h(2, '2.14 Use of AI tools')
    B.p("A large language model (Claude, Anthropic) assisted in this work. It was used to parse the extraction and bibliography files, to "
        "assist the screening and eligibility steps (Section 2.5) and the reading of the eleven full texts (Section 2.6), to write the keyword "
        "rules and scripts that produce the family labels, indicators, tables and figures, to carry out the record-level audit and the Crossref "
        "check during revision (Sections 2.7 and 2.13), and to draft and revise the text. The scripts and intermediate tables are supplied as "
        "Online Resources so that every count can be reproduced. Responsibility for the final text, the classification rules and the accuracy "
        "of the results rests with the authors.")
