# Compute every count reported in the revised manuscript from revised_studies.json
import json, sys
from collections import Counter
sys.stdout.reconfigure(encoding='utf-8')
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
R = json.load(open(W + r'\revised_studies.json', encoding='utf-8'))
S = {int(k): v for k, v in R['studies'].items()}
ARCH = ['MLP/DNN/ANN', 'CNN', 'RNN/LSTM/GRU', 'Transformer/attention', 'GAN-based', 'Autoencoder/VAE', 'Federated', 'Meta/few-shot/contrastive', 'GNN', 'Reinforcement learning', 'Other deep']
DS = ['UNSW-NB15', 'NSL-KDD', 'CIC-IDS2017', 'CSE-CIC-IDS2018', 'KDD Cup 99', 'ToN-IoT', 'Bot-IoT', 'Edge-IIoTset', 'CIC-IoT2023', 'CIC-DDoS2019', 'Other IoT/IIoT', 'In-vehicle',
      'ICS/SCADA/power', 'Other named', 'Other/custom/synthetic', 'Unnamed benchmark', 'Unnamed']
MIT = ['Loss/cost-sensitive', 'Random/other resampling', 'Generative synthesis', 'SMOTE family', 'Ensemble/boosting', 'Few-shot/contrastive', 'Federated-specific', 'Threshold/calibration', 'Explanation-guided']
EXP = ['SHAP', 'LIME', 'Model-derived FI', 'Attention', 'Rules/surrogate/intrinsic', 'Gradient-based', 'Counterfactual/anchors']
out = {}
n = len(S); out['n'] = n
fam = lambda key, names, pop: {f: sorted(r for r in pop if f in S[r][key]) for f in names}
allr = sorted(S)
out['arch'] = fam('arch', ARCH, allr)
out['multiarch'] = sorted(r for r in allr if len(S[r]['arch']) >= 2)
dsok = sorted(r for r in allr if not S[r]['dsConflict']); out['dsok'] = dsok
out['dsConflict'] = sorted(r for r in allr if S[r]['dsConflict'])
out['ds'] = fam('ds', DS, dsok)
NAMED = [d for d in DS if d not in ('Unnamed benchmark', 'Unnamed')]
out['named_ds'] = sorted(r for r in dsok if any(d in NAMED for d in S[r]['ds']))
out['kdd_any'] = sorted(r for r in dsok if set(S[r]['ds']) & {'KDD Cup 99', 'NSL-KDD'})
out['kdd_only'] = sorted(r for r in dsok if S[r]['ds'] and set(d for d in S[r]['ds'] if d in NAMED) and set(d for d in S[r]['ds'] if d in NAMED) <= {'KDD Cup 99', 'NSL-KDD'})
out['single_named'] = sorted(r for r in dsok if len([d for d in S[r]['ds'] if d in NAMED]) == 1)
out['unnamed'] = sorted(r for r in dsok if not [d for d in S[r]['ds'] if d in NAMED])
tiers = Counter(S[r]['mit_tier'] for r in allr); out['mit_tiers'] = dict(tiers)
M = sorted(r for r in allr if S[r]['mit_tier'] == 'M'); out['M'] = M
out['mit_tier_lists'] = {t: sorted(r for r in allr if S[r]['mit_tier'] == t) for t in 'MNWU'}
out['mit'] = fam('mit', MIT, M)
out['multimit'] = sorted(r for r in M if len(S[r]['mit']) >= 2)
et = Counter(S[r]['exp_tier'] for r in allr); out['exp_tiers'] = dict(et)
out['exp_tier_lists'] = {t: sorted(r for r in allr if S[r]['exp_tier'] == t) for t in ['A1', 'A2', 'B', 'U', 'none']}
EV = sorted(r for r in allr if S[r]['exp_tier'] in ('A1', 'A2', 'B')); out['EV'] = EV
A12 = sorted(r for r in allr if S[r]['exp_tier'] in ('A1', 'A2')); out['A12'] = A12
out['exp'] = fam('exp', EXP, EV)
both = sorted(r for r in M if S[r]['exp_tier'] in ('A1', 'A2')); out['both'] = both
out['bothA1'] = [r for r in both if S[r]['exp_tier'] == 'A1']; out['bothA2'] = [r for r in both if S[r]['exp_tier'] == 'A2']
mU = {r for r in allr if S[r]['mit_tier'] == 'U'}; eU = {r for r in allr if S[r]['exp_tier'] == 'U'}
cand1 = sorted((mU & set(A12)) | (eU & set(M))); cand2 = sorted(mU & eU)
out['cand_one'] = cand1; out['cand_both'] = cand2
fi = sorted(r for r in M if S[r]['exp_tier'] == 'B'); out['M_FIonly'] = fi
mno = sorted(r for r in M if S[r]['exp_tier'] == 'none'); out['M_noexp'] = mno
eno = sorted(r for r in EV if S[r]['mit_tier'] in ('N', 'W')); out['exp_noM'] = eno
used = set(both) | set(cand1) | set(cand2) | set(fi) | set(mno) | set(eno)
out['neither'] = sorted(set(allr) - used)
out['table12_sum'] = len(both) + len(cand1) + len(cand2) + len(fi) + len(mno) + len(eno) + len(out['neither'])
# pairings among both
pairs = {}
for a in MIT:
    for b in EXP:
        L = sorted(r for r in both if a in S[r]['mit'] and b in S[r]['exp'])
        if L: pairs[f'{a}|{b}'] = L
out['pairs'] = pairs
out['both_arch'] = {a: len([r for r in both if a in S[r]['arch']]) for a in ARCH}
bds = [r for r in both if not S[r]['dsConflict']]; out['both_dsok'] = len(bds)
out['both_ds'] = {d: len([r for r in bds if d in S[r]['ds']]) for d in DS}
out['both_unnamed'] = len([r for r in bds if not [d for d in S[r]['ds'] if d in NAMED]])
# explanation quality and minority
out['quality_A12'] = sorted(r for r in A12 if S[r]['quality']); out['quality_both'] = sorted(r for r in both if S[r]['quality'])
out['minority_explicit'] = sorted(r for r in both if S[r]['minority'] == 'explicit'); out['minority_indirect'] = sorted(r for r in both if S[r]['minority'] == 'indirect')
# indicators
ind = lambda k, pop: sorted(r for r in pop if S[r]['ind'][k])
for k in ('cross_dataset', 'zero_day', 'leakage', 'train_only_resampling', 'stat_rigor', 'cost_measured', 'edge_testbed', 'adversarial', 'code'):
    out['ind_' + k] = ind(k, allr)
out['cs_M'] = sorted(r for r in M if S[r]['ind']['class_sensitive'])
out['cs_M_by'] = {k: len([r for r in M if k in S[r]['ind']['class_sensitive']]) for k in ['macro-F1', 'per-class recall', 'MCC', 'G-mean', 'PR summary', 'kappa']}
out['cs_both'] = sorted(r for r in both if S[r]['ind']['class_sensitive'])
out['cs_all'] = sorted(r for r in allr if S[r]['ind']['class_sensitive'])
out['limitations'] = dict(Counter(l for r in allr for l in S[r]['ind']['limitations']).most_common())
out['noNumeric'] = sorted(r for r in allr if S[r]['noNumeric']); out['genOnly'] = sorted(r for r in allr if S[r]['genOnly'])
out['fulltext'] = sorted(r for r in allr if S[r]['fulltext'])
# pipeline stage view (Table 17/18)
stage = {'Data level': ['Random/other resampling', 'SMOTE family', 'Generative synthesis'], 'Training objective': ['Loss/cost-sensitive'],
         'Learning formulation': ['Few-shot/contrastive', 'Federated-specific'], 'Ensemble': ['Ensemble/boosting'], 'Decision rule': ['Threshold/calibration'],
         'Explanation-guided': ['Explanation-guided']}
st = {}
for k, fams in stage.items():
    L = [r for r in M if set(S[r]['mit']) & set(fams)]
    st[k] = dict(n=len(L), train_only=sum(S[r]['ind']['leak_safe_resampling'] for r in L), leakage=sum(S[r]['ind']['eval_leakage'] for r in L),
                 cost_lim=sum('cost/latency' in S[r]['ind']['limitations'] for r in L), cs=sum(bool(S[r]['ind']['class_sensitive']) for r in L))
out['stage'] = st
post = [r for r in EV if set(S[r]['exp']) & {'SHAP', 'LIME', 'Gradient-based', 'Counterfactual/anchors'}]
inmod = [r for r in EV if set(S[r]['exp']) & {'Attention', 'Model-derived FI', 'Rules/surrogate/intrinsic'}]
out['exp_app'] = {'post-hoc': dict(n=len(post), quality=sum(S[r]['quality'] for r in post), cost_lim=sum('cost/latency' in S[r]['ind']['limitations'] for r in post), edge=sum(S[r]['ind']['hardware_eval'] for r in post)),
                  'in-model': dict(n=len(inmod), quality=sum(S[r]['quality'] for r in inmod), cost_lim=sum('cost/latency' in S[r]['ind']['limitations'] for r in inmod), edge=sum(S[r]['ind']['hardware_eval'] for r in inmod))}
for k in ('transfer_eval', 'unseen_attack_eval', 'eval_leakage', 'leak_safe_resampling', 'adversarial_eval', 'hardware_eval', 'code_release'):
    out['h_' + k] = sorted(r for r in allr if S[r]['ind'][k])
out['multi_named'] = sorted(r for r in dsok if len([d for d in S[r]['ds'] if d in NAMED]) >= 2)
out['quality_cs_both'] = sorted(r for r in both if S[r]['quality'] and S[r]['ind']['class_sensitive'])
# second revision: cyber-physical subset, audit changes, sensitivity analysis and post-hoc coverage check
import re
IOT = {'ToN-IoT', 'Bot-IoT', 'Edge-IIoTset', 'CIC-IoT2023', 'Other IoT/IIoT'}
IND = {'ICS/SCADA/power', 'In-vehicle', 'Edge-IIoTset'}
out['cps_iot'] = sorted(r for r in dsok if set(S[r]['ds']) & IOT)
out['cps_ind'] = sorted(r for r in dsok if set(S[r]['ds']) & IND)
out['cps_any'] = sorted(set(out['cps_iot']) | set(out['cps_ind']))
out['both_cps'] = sorted(r for r in both if r in set(out['cps_any']))
out['audit_changed'] = sorted(r for r in allr if any('full-text reading' not in c for c in S[r]['corrections']))
out['audit_removed'] = sorted(int(k) for k in R['removed'])
out['audit_examined'] = n + len(R['removed'])
REFS = json.load(open(W + r'\refs_final.json', encoding='utf-8'))
TXT = {e['old']: e['text'] for e in REFS if e.get('old')}
out['preprints'] = sorted(r for r in allr if re.search(r'arXiv|Zenodo|SSRN|Research Square|TechRxiv|[Pp]reprint', TXT[r]))


def core(pop):
    Mp = [r for r in pop if S[r]['mit_tier'] == 'M']
    EVp = [r for r in pop if S[r]['exp_tier'] in ('A1', 'A2', 'B')]
    bp = [r for r in Mp if S[r]['exp_tier'] in ('A1', 'A2')]
    return dict(n=len(pop), M=len(Mp), EV=len(EVp), both=len(bp), quality=sum(S[r]['quality'] for r in bp),
                cs=sum(bool(S[r]['ind']['class_sensitive']) for r in bp), quality_cs=sum(S[r]['quality'] and bool(S[r]['ind']['class_sensitive']) for r in bp),
                loss=sum('Loss/cost-sensitive' in S[r]['mit'] for r in Mp), shap=sum('SHAP' in S[r]['exp'] for r in EVp))


out['sens'] = {'all': core(allr), 'no_preprints': core([r for r in allr if r not in out['preprints']]),
               'no_genOnly': core([r for r in allr if r not in out['genOnly']]),
               'neither': core([r for r in allr if r not in out['preprints'] and r not in out['genOnly']])}
COV = json.load(open(W + r'\openalex_coverage.json', encoding='utf-8-sig'))
DOI = json.load(open(W + r'\included_dois.json'))
idx, fnd = set(COV['indexed']), set(COV['found'])
out['cov'] = dict(hits=COV['hits'], run_at=COV['run_at'], query=COV['query'], with_doi=len(DOI), indexed=sum(1 for d in DOI.values() if d in idx),
                  found=sum(1 for d in DOI.values() if d in fnd), both_indexed=sum(1 for r in both if DOI.get(str(r)) in idx),
                  both_found=sum(1 for r in both if DOI.get(str(r)) in fnd))
json.dump(out, open(W + r'\stats_revised.json', 'w'), indent=0)


def p(k):
    v = out[k]
    return len(v) if isinstance(v, list) else v


print('n', n, '| multi-arch', p('multiarch'), '| dsok', p('dsok'), 'dsConflict', p('dsConflict'), '| named', p('named_ds'))
print('arch', {k: len(v) for k, v in out['arch'].items()})
print('ds', {k: len(v) for k, v in out['ds'].items()})
print('kdd any', p('kdd_any'), 'kdd only', p('kdd_only'), 'single named', p('single_named'), 'unnamed', p('unnamed'))
print('mit tiers', out['mit_tiers'], 'multi-mit', p('multimit'))
print('mit', {k: len(v) for k, v in out['mit'].items()})
print('exp tiers', out['exp_tiers'], 'EV', p('EV'), 'A12', p('A12'))
print('exp', {k: len(v) for k, v in out['exp'].items()})
print('both', p('both'), 'A1', len(out['bothA1']), 'A2', len(out['bothA2']), '| cand one', p('cand_one'), 'cand both', p('cand_both'), '| FI only', p('M_FIonly'), 'M no exp', p('M_noexp'), 'exp no M', p('exp_noM'), 'neither', p('neither'), 'sum', out['table12_sum'])
print('pairs', {k: len(v) for k, v in sorted(out['pairs'].items(), key=lambda x: -len(x[1]))})
print('both arch', out['both_arch']); print('both dsok', out['both_dsok'], out['both_ds'], 'unnamed', out['both_unnamed'])
print('quality A12', p('quality_A12'), out['quality_A12'], 'both', p('quality_both'), out['quality_both'])
print('minority explicit', out['minority_explicit'], 'indirect', out['minority_indirect'])
print('cs M', p('cs_M'), out['cs_M_by'], 'cs both', p('cs_both'), 'cs all', p('cs_all'))
for k in ('cross_dataset', 'zero_day', 'leakage', 'train_only_resampling', 'stat_rigor', 'cost_measured', 'edge_testbed', 'adversarial', 'code'):
    print('ind', k, p('ind_' + k), out['ind_' + k][:12])
print('limitations', out['limitations'])
print('noNumeric', p('noNumeric'), 'genOnly', p('genOnly'), out['genOnly'])
print('stage', out['stage']); print('exp_app', out['exp_app'])
