import re, json, difflib
W = r'C:\Users\tarun\AppData\Local\Temp\claude\C--Users-tarun-Desktop-MtechPurva\42de6222-d383-461d-b18f-f7a54cb9e033\scratchpad\work'
src = r'C:\Users\tarun\Desktop\MtechPurva\Combined_Literature_Analysis.md'
lines = open(src, encoding='utf-8').read().split('\n')
# re-parse records allowing letter suffix
pat = [re.compile(r'^#{2,3}\s*Paper\s+\d+\s*:\s*Paper\s+(\d+)([a-z]?)\b(.*)$'),
       re.compile(r'^#{2,3}\s*Paper\s+ID\s+(\d+)([a-z]?)\s*[—\-:–]+\s*(.*)$'),
       re.compile(r'^#{2,3}\s*Paper\s+(\d+)([a-z]?)\s*[:—\-–]\s*(.*)$')]
starts = []
for i, l in enumerate(lines):
    for p in pat:
        m = p.match(l)
        if m: starts.append((i, m.group(1) + m.group(2), m.group(3).strip())); break
ref_start = next(i for i, l in enumerate(lines) if l.startswith('# REFERENCES'))
bounds = sorted(set([s[0] for s in starts] + [i for i, l in enumerate(lines) if re.match(r'^#{1,2}\s', l)] + [len(lines)]))
recs = {}
for (i, pid, title) in starts:
    j = next(b for b in bounds if b > i)
    j = min(j, ref_start)
    body = '\n'.join(lines[i:j])
    if pid in recs: recs[pid]['body'] += '\n' + body; recs[pid]['dup_heading'] = True; continue
    recs[pid] = dict(mdid=pid, line=i + 1, title=title.strip(' *'), body=body)
for k in ('260', '261', '262', '263', '264'):
    m = re.search(r'Paper %s\s*\S+\s*\*([^*]+)\*' % k, recs[k]['body'])
    if m: recs[k]['title'] = m.group(1)
print('md records', len(recs))
bib = json.load(open(W + r'\bib.json', encoding='utf-8'))
def norm(s): return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', re.sub(r'(\w)- (\w)', r'\1\2', s.lower()))).strip()
def sim(a, b): return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()
# bib -> md: same pid, except 203->204a, 204->204b
bm = {}
for b in bib:
    pid = str(b['pid'])
    cand = {'203': '204a', '204': '204b'}.get(pid, pid)
    if cand in recs:
        s = sim(b.get('title', ''), recs[cand]['title'])
        bm[b['key']] = (cand, round(s, 2))
    else:
        bm[b['key']] = (None, 0)
mism = [(k, v) for k, v in bm.items() if v[1] < 0.85]
print('bib entries without md record:', [k for k, v in bm.items() if v[0] is None])
print('title mismatch bib vs md (same id):', len(mism))
bk = {b['key']: b for b in bib}
for k, v in mism:
    if v[0]: print(f'  {k}: BIB="{bk[k]["title"][:75]}" | MD{v[0]}="{recs[v[0]]["title"][:75]}" ({v[1]})')
used = {v[0] for v in bm.values() if v[0]}
print('md records not in bib:', [k for k in recs if k not in used])
json.dump(recs, open(W + r'\recs2.json', 'w', encoding='utf-8'), ensure_ascii=False)
json.dump(bm, open(W + r'\bib2md.json', 'w'), indent=0)
