# One-off text patch (17 Nov 2026): make every sentence that reports unresolved extraction conflicts read correctly when
# the full-text resolution leaves none. Each replacement keeps the original wording when conflicts remain.
import os
D = os.path.dirname(os.path.abspath(__file__))


def patch(fn, pairs):
    p = os.path.join(D, fn)
    s = open(p, encoding='utf-8').read()
    for a, b in pairs:
        assert s.count(a) == 1, (fn, s.count(a), a[:80])
        s = s.replace(a, b)
    open(p, 'w', encoding='utf-8').write(s)
    print('patched', fn, len(pairs))


patch('ms_common.py', [
    ("MT, ET = N['mit_tiers'], N['exp_tiers']",
     "MT, ET = N['mit_tiers'], N['exp_tiers']\nCU = len(N['cand_one']) + len(N['cand_both'])   # unresolved RQ4 candidates\n"
     "CONF = MT.get('U', 0) + ET.get('U', 0) + len(N['dsConflict'])   # remaining extraction conflicts"),
])

patch('c1_front.py', [
    ("""f"and an explicit explanation technique, and {ln('cand_one') + ln('cand_both')} remain unresolved. Among the confirmed, the extractions \"""",
     """f"and an explicit explanation technique" + ((', and ' + str(CU) + ' remain unresolved') if CU else '; no extraction conflict remains') + f". Among the confirmed, the extractions \""""),
    ("""Section 4.5 reports the unresolved conflicts that bound the central "
        f"counts.")""",
     """" + ("Section 4.5 reports the unresolved conflicts that bound the central counts." if CU else
              "Section 2.10 reports how often the extraction labels disagreed with the full text."))"""),
    ("""The remaining {len(CONFNOW)} "
        f"conflict records could not be read in full (no copy could be obtained, or no DOI) and stay unresolved. On the dimensions""",
     """" + (f" The remaining {len(CONFNOW)} conflict records could not be read in full (no copy could be obtained, or no DOI) and stay unresolved." if CONFNOW
              else " No conflict record remains unresolved.") + f" On the dimensions"""),
])

patch('c3_results.py', [
    ("""f"studies. Dataset counts use the {ln('dsok')} studies whose two extraction formats do not conflict on dataset identity; the "
        f"{ln('dsConflict')} studies in conflict are listed separately and are not counted in any dataset family.")""",
     """f"studies. " + (f"Dataset counts use the {ln('dsok')} studies whose two extraction formats do not conflict on dataset identity; the "
        f"{ln('dsConflict')} studies in conflict are listed separately and are not counted in any dataset family." if ln('dsConflict') else
        f"Dataset counts use all {ln('dsok')} studies; every dataset-identity conflict between the extraction formats was resolved on full text."))"""),
    ("""f"extracted; the {ln('dsConflict')} conflicting studies are excluded)",""",
     """"extracted; " + (f"the {ln('dsConflict')} conflicting studies are excluded)" if ln('dsConflict') else "dataset-identity conflicts resolved on full text)"),"""),
    ("""{ln('dsConflict')} studies are outside "
        "the dataset counts because their two formats name different datasets, so the counts could change if those conflicts were resolved.")""",
     """" + (f"{ln('dsConflict')} studies are outside the dataset counts because their two formats name different datasets, so the counts "
        "could change if those conflicts were resolved." if ln('dsConflict') else "For studies not read in full the dataset lists come from the "
        "extractions, and the full-text reading showed that dataset lists are the least reliable extraction item (Section 2.10)."))"""),
    ("""show none or evaluation-only handling; and "
        f"{MT['U']} are in conflict between extraction formats and are counted neither way (Fig. 5b; Tables 9 and 5). Family counts below use \"""",
     """show none or evaluation-only handling" + (f"; and {MT['U']} are in conflict between extraction formats and are counted neither way" if MT['U']
        else "; no study remains in conflict between the extraction formats") + f" (Fig. 5b; Tables 9 and 5). Family counts below use \""""),
    ("""f"{MT['U']} studies conflict on whether imbalance is handled; ensembles, few-shot or contrastive formulations, federated rebalancing and \"""",
     """(f"{MT['U']} studies conflict on whether imbalance is handled; ensembles" if MT['U'] else "Ensembles") + ", few-shot or contrastive formulations, federated rebalancing and \""""),
    ("""f"improved. If the {MT['U']} conflicts were settled in favour of mitigation, the explicit count would rise to at most {MT['M'] + MT['U']}.")""",
     """"improved." + (f" If the {MT['U']} conflicts were settled in favour of mitigation, the explicit count would rise to at most {MT['M'] + MT['U']}." if MT['U'] else ""))"""),
    ("""{ET['B']} B); {ET['U']} conflict "
        f"between extraction formats and are counted neither way; {ET['none']} carry""",
     """{ET['B']} B); " + (f"{ET['U']} conflict between extraction formats and are counted neither way; " if ET['U'] else "") + f"{ET['none']} carry"""),
    ("""curation, so further misses are possible. {ET['U']} studies conflict between formats and are not counted.")""",
     """curation, so further misses are possible." + (f" {ET['U']} studies conflict between formats and are not counted." if ET['U'] else ""))"""),
    ("""A2). {ln('cand_one') + ln('cand_both')} "
        f"further studies are candidates: {ln('cand_one')} conflict on one dimension while the other is positive, and {ln('cand_both')} conflict on "
        f"both. The central result is therefore {ln('both')} confirmed and {ln('cand_one') + ln('cand_both')} unresolved. The count is provisional: if every candidate conflict were resolved in favour of "
        f"inclusion it could rise to at most {ln('both') + ln('cand_one') + ln('cand_both')}, and it could also fall if tier assignments change.")""",
     """A2). " + (f"{CU} further studies are candidates: {ln('cand_one')} conflict on one dimension while the other is positive, and {ln('cand_both')} conflict on "
        f"both. The central result is therefore {ln('both')} confirmed and {CU} unresolved. The count is provisional: if every candidate conflict were resolved in favour of "
        f"inclusion it could rise to at most {ln('both') + CU}, and it could also fall if tier assignments change." if CU else
        "No candidate remains: every extraction conflict that affected this count was resolved on full text (Section 2.10). The count is still "
        f"provisional, because {n - ln('fulltext')} of the {n} studies were classified from their extractions, and it could rise or fall if tier assignments change."))"""),
    ("""f"tier (assigned from the extractions; the {ln('cand_one') + ln('cand_both')} unresolved candidates are listed in Table 12)",""",
     """"tier (assigned from the extractions" + (f"; the {CU} unresolved candidates are listed in Table 12)" if CU else ", or from the full text where the extractions conflicted)"),"""),
    ("""an explicit explanation technique; "
        f"{ln('cand_one') + ln('cand_both')} more are unresolved because their extraction formats conflict.",""",
     """an explicit explanation technique" + (f"; {CU} more are unresolved because their extraction formats conflict." if CU else "; no extraction conflict remains unresolved."),"""),
    (""""Section 2.7); an error of that order in either direction, together with the unresolved candidates, bounds how far the central counts \"""",
     """"Section 2.7); an error of that order in either direction" + (", together with the unresolved candidates," if CU else "") + " bounds how far the central counts \""""),
])

patch('c4_back.py', [
    ("""(iii) only a few studies were verified on full text; "
        "and (iv) extraction conflicts remain unresolved. Even after""",
     """(iii) only " + f"{ln('fulltext')} of the {n} studies were verified on full text; " + ("and (iv) extraction conflicts remain unresolved. " if CONF else
        "and (iv) the other studies rest on extraction labels, which the full-text reading found wrong in some cases, most often for dataset lists. ") + "Even after"""),
    ("""f"**Extraction conflicts, provenance and flags.** The two extraction formats conflict for {MT['U'] + ET['U'] - ln('cand_both')} included "
        f"studies on mitigation ({MT['U']}) or explanation ({ET['U']}); the formats name different dataset families for {ln('dsConflict')}; \"""",
     """(f"**Extraction conflicts, provenance and flags.** The two extraction formats conflict for {MT['U'] + ET['U'] - ln('cand_both')} included "
        f"studies on mitigation ({MT['U']}) or explanation ({ET['U']}); the formats name different dataset families for {ln('dsConflict')}; " if CONF else
        f"**Extraction conflicts, provenance and flags.** The two extraction formats conflicted for {ln('e1_resolved')} included studies, on "
        f"mitigation ({ln('e1_conf_mit')}), explanation ({ln('e1_conf_exp')}) or dataset identity ({ln('e1_conf_ds')}); all were resolved on full "
        "text (Section 2.10). Of the remaining flags, ") + f\""""),
    ("""These were retained, flagged and kept out of the affected counts, so the central counts could change if the "
        "conflicts were settled against the papers. The provenance""",
     """" + ("These were retained, flagged and kept out of the affected counts, so the central counts could change if the "
        "conflicts were settled against the papers. " if CONF else "These studies were retained and flagged. ") + "The provenance"""),
    ("""['Unresolved conflicts', 'The two extraction formats disagree', f"RQ4 count ({ln('both')} confirmed, {ln('cand_one') + ln('cand_both')} unresolved)", 'Count could rise or fall', 'Conflicts retained and counted neither way'],""",
     """(['Unresolved conflicts', 'The two extraction formats disagree', f"RQ4 count ({ln('both')} confirmed, {CU} unresolved)", 'Count could rise or fall', 'Conflicts retained and counted neither way']
         if CONF else ['Extraction conflicts', 'The two extraction formats disagreed', f"{ln('e1_resolved')} records", 'Labels changed for some of them', 'All resolved on full text (Section 2.10)']),"""),
    ("""an explicit explanation technique, and "
        f"{ln('cand_one') + ln('cand_both')} further studies are unresolved. Most join""",
     """an explicit explanation technique" + (f", and {CU} further studies are unresolved" if CU else "") + f". Most join"""),
    ("""no reported performance value was reproduced. Whether the "
        f"{ln('cand_one') + ln('cand_both')} unresolved studies belong to the explicit-both group, and whether full texts would change the "
        "extraction-level labels, remain open.")""",
     """no reported performance value was reproduced. " + (f"Whether the {CU} unresolved studies belong to the explicit-both group, and whether full "
        "texts would change the extraction-level labels, remain open." if CU else f"Whether full texts would change the extraction-level labels of the "
        f"{n - ln('fulltext')} studies not read in full remains open."))"""),
])

patch('figures.py', [
    ("""    ('RQ5 results', [(n - len(st['noNumeric']), 'Numeric result'), (len(st['noNumeric']), 'No numeric result')]),
]""",
     """    ('RQ5 results', [(n - len(st['noNumeric']), 'Numeric result'), (len(st['noNumeric']), 'No numeric result')]),
]
rq = [(t, [(v, l) for v, l in segs if v]) for t, segs in rq]   # drop empty segments (e.g. no conflicts left)"""),
    ("""tiers = [('Explicit (M)', mt['M']), ('Conflict (U)', mt['U']), ('None (N)', mt['N']), ('Indirect (W)', mt['W'])]""",
     """tiers = [x for x in [('Explicit (M)', mt['M']), ('Conflict (U)', mt.get('U', 0)), ('None (N)', mt['N']), ('Indirect (W)', mt['W'])] if x[1]]"""),
    ("""tiers = [('A1 established', et['A1']), ('A2 attention', et['A2']), ('B importance only', et['B']), ('Conflict (U)', et['U']), ('None', et['none'])]""",
     """tiers = [x for x in [('A1 established', et['A1']), ('A2 attention', et['A2']), ('B importance only', et['B']), ('Conflict (U)', et.get('U', 0)), ('None', et['none'])] if x[1]]"""),
])
