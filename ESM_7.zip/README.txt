Online Resource 7 for: Explainable Deep Learning for Imbalance-Robust Network Intrusion Detection: A Systematic Literature Review
Journal: Archives of Computational Methods in Engineering
Authors: Tarun Jangwal (corresponding), Purva Pathania (Lovely Professional University, Phagwara, Punjab, India)

scripts/ reproduce the classification, statistics, figures and manuscript tables. Run order: parse_bib.py, crossmap.py, ref2bib.py, rebuild_ms_data.py, build_revised.py, stats.py, figures.py, build_refs.py, build_manuscript.py. The extraction file (Combined_Literature_Analysis.md) is the input of crossmap.py and is not redistributed here; data/ holds the derived tables.
ms_data.json: classification reconstructed from the reference lists printed in the pre-revision manuscript tables.
revised_studies.json: the revised study-level dataset (Online Resource 1 in JSON form), including all corrections.
indicator_comparison.csv: original indicator values, the revised rules applied to the original 188 studies, and revised values.
